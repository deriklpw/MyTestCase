package com.ozmobi.coupons.baichuan;

import android.app.Application;

import com.ozmobi.coupons.base.BaseApplicationLike;
import com.alibaba.baichuan.android.trade.AlibcTradeSDK;
import com.alibaba.baichuan.android.trade.callback.AlibcTradeInitCallback;
import com.ozmobi.coupons.base.GlobalAppInfo;

public class BaiChuanApplicationLikeImpl implements BaseApplicationLike {
    @Override
    public void onCreate(Application application) {
        //百川SDk
        /**
         * 百川电商SDK初始化【异步】
         *
         * @param context 建议设置Application（必填）
         * @param initResultCallback  初始化状态信息回调（可以为null）
         */
        AlibcTradeSDK.asyncInit(application, new AlibcTradeInitCallback() {
            @Override
            public void onSuccess() {
                /**
                 * 设置渠道信息（如果有渠道专享价，需要设置）
                 * 注意：初始化完成后调用才能生效
                 *
                 * @param typeName    : 渠道类型（默认为：0）
                 * @param channelName : 渠道名称（默认为：null）
                 */
                AlibcTradeSDK.setChannel("0", GlobalAppInfo.channel);

                AlibcTradeSDK.setSyncForTaoke(true);
            }

            @Override
            public void onFailure(int code, String msg) {
                //初始化失败，可以根据code和msg判断失败原因，详情参见错误说明
            }
        });
    }

    @Override
    public void onLowMemory() {

    }
}
