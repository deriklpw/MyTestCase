package com.ozmobi.coupons.baichuan;

import android.app.Activity;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.alibaba.baichuan.android.trade.AlibcTradeSDK;
import com.alibaba.baichuan.android.trade.AlibcTrade;
import com.alibaba.baichuan.android.trade.callback.AlibcTradeCallback;
import com.alibaba.baichuan.android.trade.model.AlibcShowParams;
import com.alibaba.baichuan.android.trade.page.AlibcBasePage;
import com.alibaba.baichuan.android.trade.page.AlibcMyCartsPage;
import com.alibaba.baichuan.trade.biz.AlibcConstants;
import com.alibaba.baichuan.trade.biz.context.AlibcTradeResult;
import com.alibaba.baichuan.trade.biz.core.taoke.AlibcTaokeParams;
import com.alibaba.baichuan.trade.biz.login.AlibcLogin;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by xhkj on 2019/9/26.
 */

public class AlibaichManager {
    public static final String ALIBC_SCHEME = "alisdk://";

    public static boolean isTaobaoLogin() {
        return AlibcLogin.getInstance() != null && AlibcLogin.getInstance().isLogin();
    }

    public static void login(CustomAliLoginCallback callback) {
        AlibcLogin alibcLogin = AlibcLogin.getInstance();
        if (alibcLogin != null) {
            alibcLogin.showLogin(callback);
        }
    }

    public static String getOpenId() {
        String tbId = "";
        if (isTaobaoLogin()) {
            tbId = AlibcLogin.getInstance().getSession().openId;
        }
        return tbId;
    }

//    public static void logout(AlibcLoginCallback logoutCallback) {
//        AlibcLogin alibcLogin = AlibcLogin.getInstance();
//        if (alibcLogin != null) {
//            alibcLogin.logout(logoutCallback);
//        }
//    }

    public static void logout(CustomAliLoginCallback callback) {
        AlibcLogin alibcLogin = AlibcLogin.getInstance();
        if (alibcLogin != null) {
            alibcLogin.logout(callback);
        }
    }

    /**
     * 打开购物车
     * @param activity
     */
    public static void startMyCart(Activity activity) {
        AlibcBasePage ordersPage = new AlibcMyCartsPage();
        AlibcShowParams showParams = new AlibcShowParams();
        showParams.setBackUrl(AlibaichManager.ALIBC_SCHEME);
        AlibcTaokeParams taokeParams = new AlibcTaokeParams("", "", "");
        Map<String, String> trackParams = new HashMap<>();
        trackParams.put(AlibcConstants.ISV_CODE, "appisvcode");
        AlibcTrade.openByBizCode(activity, ordersPage, null, null, null, "cart",
                showParams, taokeParams, trackParams, new AlibcTradeCallback() {
                    @Override
                    public void onTradeSuccess(AlibcTradeResult alibcTradeResult) {

                    }

                    @Override
                    public void onFailure(int i, String s) {

                    }
                });
    }

    /**
     * 使用百川默认方式打开淘宝url
     *
     * @param activity
     * @param taokeUrl
     */
    public static void showUrlPage(Activity activity, String taokeUrl) {
        if (activity != null) {

            AlibcShowParams showParams = new AlibcShowParams();
//            showParams.setOpenType(openType);
//            showParams.setClientType(clientType);
            showParams.setBackUrl(AlibaichManager.ALIBC_SCHEME);
//            showParams.setNativeOpenFailedMode(AlibcNativeFailModeJumpH5);
            AlibcTaokeParams taokeParams = new AlibcTaokeParams("", "", "");
//            taokeParams.setPid("mm_112883640_11584347_72287650277");
//            //taokeParams.setAdzoneid("29932014");
//            //adzoneid是需要taokeAppkey参数才可以转链成功&店铺页面需要卖家id（sellerId），具体设置方式如下：
//            taokeParams.extraParams.put("taokeAppkey", "xxxxx");
//            taokeParams.extraParams.put("sellerId", "xxxxx");

            Map<String, String> trackParams = new HashMap<>();
            AlibcTrade.openByUrl(activity, "urldetail", taokeUrl, null, new WebViewClient(), new WebChromeClient(), showParams, taokeParams, trackParams, new AlibcTradeCallback() {
                @Override
                public void onTradeSuccess(AlibcTradeResult alibcTradeResult) {
                }

                @Override
                public void onFailure(int i, String s) {
                }
            });
        }
    }

    /**
     * 使用百川默认方式打开淘宝url，用于授权时
     *
     * @param activity
     * @param taokeUrl
     */
    public static void showUrlPage(Activity activity, WebView webView, WebViewClient webViewClient, WebChromeClient webChromeClient, String taokeUrl) {
        if (activity != null) {

            AlibcShowParams showParams = new AlibcShowParams();
//            showParams.setOpenType(openType);
//            showParams.setClientType(clientType);
            showParams.setBackUrl(AlibaichManager.ALIBC_SCHEME);
//            showParams.setNativeOpenFailedMode(AlibcNativeFailModeJumpH5);
            AlibcTaokeParams taokeParams = new AlibcTaokeParams("", "", "");
//            taokeParams.setPid("mm_112883640_11584347_72287650277");
//            //taokeParams.setAdzoneid("29932014");
//            //adzoneid是需要taokeAppkey参数才可以转链成功&店铺页面需要卖家id（sellerId），具体设置方式如下：
//            taokeParams.extraParams.put("taokeAppkey", "xxxxx");
//            taokeParams.extraParams.put("sellerId", "xxxxx");

            Map<String, String> trackParams = new HashMap<>();
            AlibcTrade.openByUrl(activity, "urldetail", taokeUrl, webView, webViewClient, webChromeClient, showParams, taokeParams, trackParams, new AlibcTradeCallback() {
                @Override
                public void onTradeSuccess(AlibcTradeResult alibcTradeResult) {
                }

                @Override
                public void onFailure(int i, String s) {
                }
            });
        }
    }

    public interface Callback {
        void onSuccess(int loginResult, String openId, String userNick);

        void onFailure(int i, String s);
    }

    public static void destroy() {
        AlibcTradeSDK.destory();
    }
}
