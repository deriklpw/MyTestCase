package com.ozmobi.coupons.baichuan;

import com.alibaba.baichuan.trade.biz.login.AlibcLoginCallback;

import java.lang.ref.SoftReference;

public class CustomAliLoginCallback implements AlibcLoginCallback {

    private SoftReference<AlibaichManager.Callback> mSoftReference;

    public CustomAliLoginCallback(SoftReference<AlibaichManager.Callback> softReference) {
        //解决淘宝授权内存泄露
        mSoftReference = softReference ;
    }

    @Override
    public void onSuccess(int loginResult, String openId, String userNick) {
        if (mSoftReference != null && mSoftReference.get() != null) {
            mSoftReference.get().onSuccess(loginResult, openId, userNick);
        }
    }

    @Override
    public void onFailure(int i, String s) {
        if (mSoftReference != null && mSoftReference.get() != null) {
            mSoftReference.get().onFailure(i, s);
        }
    }
}
