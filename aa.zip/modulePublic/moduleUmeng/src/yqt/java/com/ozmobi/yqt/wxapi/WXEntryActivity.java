package com.ozmobi.yqt.wxapi;

import com.umeng.socialize.weixin.view.WXCallbackActivity;

/**
 * Created by xhkj on 2019/3/29.
 */

public class WXEntryActivity extends WXCallbackActivity {
}
