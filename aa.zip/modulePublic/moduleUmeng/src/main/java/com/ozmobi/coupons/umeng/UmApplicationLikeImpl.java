package com.ozmobi.coupons.umeng;

import android.app.Application;
import android.content.Context;

import com.ozmobi.coupons.base.BaseApplicationLike;

import com.ozmobi.coupons.base.GlobalAppInfo;
import com.umeng.analytics.MobclickAgent;
import com.umeng.commonsdk.UMConfigure;
import com.umeng.socialize.PlatformConfig;

public class UmApplicationLikeImpl implements BaseApplicationLike {

    @Override
    public void onCreate(Application application) {

        //友盟移动统计，分享
        initUMeng(application.getApplicationContext());
    }

    @Override
    public void onLowMemory() {

    }

    private void initUMeng(Context context) {
        //初始化，APP KEY在清单文件中配置
//        UMConfigure.init(context, UMConfigure.DEVICE_TYPE_PHONE, ICustomShareConfig.UMENG_MESSAGE_SECRET);

        //直接初始化
        UMConfigure.init(context, BuildConfig.UMENG_APPKEY_VALUE, GlobalAppInfo.channel, UMConfigure.DEVICE_TYPE_PHONE, BuildConfig.UMENG_MESSAGE_SECRET);

        //分享平台
        PlatformConfig.setWeixin(BuildConfig.WECHAT_APP_KEY, BuildConfig.WECHAT_APP_SECRET);
        PlatformConfig.setSinaWeibo(BuildConfig.SINA_APP_KEY, BuildConfig.SINA_APP_SECRET, "http://www.ozmobi.com/");
        PlatformConfig.setQQZone(BuildConfig.QQ_APP_KEY, BuildConfig.QQ_APP_SECRET);

        //友盟统计
        MobclickAgent.setPageCollectionMode(MobclickAgent.PageMode.MANUAL);

        //关闭异常上报功能
        MobclickAgent.setCatchUncaughtExceptions(false);
        //统计SDK调试模式设置
        UMConfigure.setLogEnabled(GlobalAppInfo.isDebug);
    }
}
