package com.ozmobi.coupons.jiguang;

import android.app.Application;
import android.content.Context;

import com.ozmobi.coupons.base.BaseApplicationLike;
import com.ozmobi.coupons.base.GlobalAppInfo;
import com.ozmobi.coupons.base.utils.LogUtil;

import cn.jiguang.verifysdk.api.JVerificationInterface;

import static android.content.ContentValues.TAG;

public class JGApplicationLikeImpl implements BaseApplicationLike {
    @Override
    public void onCreate(Application application) {
        //初始化极光一键登录
        initJiGuang(application.getApplicationContext());
    }

    @Override
    public void onLowMemory() {

    }

    private void initJiGuang(Context context) {
        JVerificationInterface.init(context, (i, s) -> LogUtil.d(TAG, "onResult: code=" + i + ", msg=" + s));
        JVerificationInterface.setDebugMode(GlobalAppInfo.isDebug);
    }
}
