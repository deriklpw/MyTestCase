package com.ozmobi.coupons.common.bean;

import java.util.List;

public class RecommendLimitHomeBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private int left_time;
        private List<String> flash_time;
        private String start;
        private List<LimitDetailProduct> products;

        public void setLeft_time(int left_time) {
            this.left_time = left_time;
        }

        public void setFlash_time(List<String> flash_time) {
            this.flash_time = flash_time;
        }

        public void setStart(String start) {
            this.start = start;
        }

        public void setProducts(List<LimitDetailProduct> products) {
            this.products = products;
        }

        public int getLeft_time() {
            return left_time;
        }

        public List<String> getFlash_time() {
            return flash_time;
        }

        public String getStart() {
            return start;
        }

        public List<LimitDetailProduct> getProducts() {
            return products;
        }

        public class LimitDetailProduct extends CommonProductsEntity {
            private String subtitle;

            public String getSubtitle() {
                return subtitle;
            }

            public void setSubtitle(String subtitle) {
                this.subtitle = subtitle;
            }
        }
    }
}
