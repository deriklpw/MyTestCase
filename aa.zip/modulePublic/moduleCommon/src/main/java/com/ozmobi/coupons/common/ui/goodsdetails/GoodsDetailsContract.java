package com.ozmobi.coupons.common.ui.goodsdetails;

import com.ozmobi.coupons.common.AbsBasePresenter;
import com.ozmobi.coupons.common.BaseView;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.bean.GoodsBean;
import com.ozmobi.coupons.common.bean.GoodsDetailsPageBean;
import com.ozmobi.coupons.common.data.source.GoodsDataSource;

/**
 * Created by xhkj on 2019/6/11.
 */

public interface GoodsDetailsContract {
    interface Callback {
        void onResponse(String url);
    }

    interface View extends BaseView {

        void setRefresh(boolean enable);

        void setCollectState(boolean collectState);

        void showCollectFavorite(boolean result);

        void setGoodsDetailsPageBean(GoodsDetailsPageBean goodsDetailsPageBean);

        void showRelateGoods(CommonGoodsBean commonGoodsBean);

        void setShopCouponsGoods(CommonGoodsBean commonGoodsBean);
    }

    abstract class Presenter extends AbsBasePresenter<GoodsDetailsContract.View, GoodsDataSource> {
        public Presenter(GoodsDataSource goodsDataSource) {
            super(goodsDataSource);
        }

        abstract void queryCollectState(String id);

        abstract void addFavoriteGoods(GoodsBean goodsBean);

        abstract void deleteFavoriteGoods(String id);

        abstract void addCouponsGoods(GoodsBean goodsBean);

        abstract void addHistoryGoods(GoodsBean goodsBean);

        abstract void getGoodsDetailsImages(String numIId, String platType);

        abstract void getRelateGoods(String numIId);

        abstract void getShopCouponsGoods(String shopName);

        abstract void getTaobaoAuthUrl(Callback callback);
    }
}
