package com.ozmobi.coupons.common.bean;

/**
 * Created by xhkj on 2019/10/28.
 */

public class CommonPromoteBean {
    private String image;
    private CommonProductsEntity product;
    private String title;
    private String type;
    private String url;
    private int tb;
    private int id;
    private String cate;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public CommonProductsEntity getProduct() {
        return product;
    }

    public void setProduct(CommonProductsEntity product) {
        this.product = product;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getTb() {
        return tb;
    }

    public void setTb(int tb) {
        this.tb = tb;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCate() {
        return cate;
    }

    public void setCate(String cate) {
        this.cate = cate;
    }
}
