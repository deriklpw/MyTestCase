package com.ozmobi.coupons.common.bean;

/**
 * Created by xhkj on 2019/7/1.
 */

public class PresentIncomeBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private IncomeEntity income;

        public void setIncome(IncomeEntity income) {
            this.income = income;
        }

        public IncomeEntity getIncome() {
            return income;
        }

        public class IncomeEntity {
            private String today_estimated_income;
            private String last_month_estimated_income;
            private String this_month_estimated_income;
            private String last_month_settlement_income;

            public void setToday_estimated_income(String today_estimated_income) {
                this.today_estimated_income = today_estimated_income;
            }

            public void setLast_month_estimated_income(String last_month_estimated_income) {
                this.last_month_estimated_income = last_month_estimated_income;
            }

            public void setThis_month_estimated_income(String this_month_estimated_income) {
                this.this_month_estimated_income = this_month_estimated_income;
            }

            public void setLast_month_settlement_income(String last_month_settlement_income) {
                this.last_month_settlement_income = last_month_settlement_income;
            }

            public String getToday_estimated_income() {
                return today_estimated_income;
            }

            public String getLast_month_estimated_income() {
                return last_month_estimated_income;
            }

            public String getThis_month_estimated_income() {
                return this_month_estimated_income;
            }

            public String getLast_month_settlement_income() {
                return last_month_settlement_income;
            }
        }
    }
}
