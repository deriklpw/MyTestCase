package com.ozmobi.coupons.common.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.constraint.Group;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.bean.CommonProductsEntity;
import com.ozmobi.coupons.common.utils.GlideUtils;
import com.ozmobi.coupons.base.utils.IconTextUtil;
import com.ozmobi.coupons.base.utils.NumberUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

/**
 * Created by xhkj on 2019/5/15.
 */

public class ListGoodsAdapter extends CustomBaseAdapter<CommonProductsEntity> {
    //    R.layout.adapter_item_common_goods_list

    private LinkedList<ImageView> mListImageView;

    public ListGoodsAdapter(int layoutId, List<CommonProductsEntity> list) {
        super(layoutId, list);
        mListImageView = new LinkedList<>();
    }

    @Override
    public void onViewRecycled(@NonNull RecyclerView.ViewHolder viewHolder) {
        super.onViewRecycled(viewHolder);
        if (viewHolder instanceof GoodsHolderList) {
            GoodsHolderList holder = (GoodsHolderList) viewHolder;
            if (holder.icon != null) {
                GlideUtils.clearImageView(holder.icon);
                mListImageView.remove(holder.icon);
            }
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateCustomViewHolder(View view) {
        return new GoodsHolderList(view);
    }

    @Override
    public void onBindCustomViewHolder(RecyclerView.ViewHolder viewHolder, CommonProductsEntity goods, int position) {
        try {
            if (viewHolder instanceof GoodsHolderList) {

                Context context = viewHolder.itemView.getContext();

                GoodsHolderList holder = (GoodsHolderList) viewHolder;

                GlideUtils.initImageWithFileCache(goods.getPict_url(), R.mipmap.common_ic_image_place_holder, holder.icon);
                mListImageView.add(holder.icon);

                double originPrice = Double.valueOf(goods.getOriginal_price());
                String originPriceStr = NumberUtils.format(originPrice);

                if (!TextUtils.isEmpty(goods.getPlat_type())) {
                    if ("tmall".equals(goods.getPlat_type())) {
                        //设置天猫图标
                        IconTextUtil.setIconAndTextInTextView(context, holder.title, R.mipmap.common_ic_tianmao_logo, goods.getTitle());
                        holder.originPrice.setText(String.format(context.getString(R.string.common_goods_price_tianmao_format), originPriceStr));
                    } else if ("taobao".equals(goods.getPlat_type())) {
                        //设置淘宝图标
                        IconTextUtil.setIconAndTextInTextView(context, holder.title, R.mipmap.common_ic_taobao_logo, goods.getTitle());
                        holder.originPrice.setText(String.format(context.getString(R.string.common_goods_price_taobao_format), originPriceStr));
                    } else {
                        holder.title.setText(goods.getTitle());
                        holder.originPrice.setText(String.format(context.getString(R.string.common_goods_price_format), originPriceStr));
                    }
                } else {
                    holder.title.setText(goods.getTitle());
                    holder.originPrice.setText(String.format(context.getString(R.string.common_goods_price_format), originPriceStr));
                }

                double couponValue = Double.valueOf(goods.getCoupon_price());
                if (couponValue - 0 < 0.0001) {
                    holder.couponValue.setVisibility(View.GONE);
                } else {
                    holder.couponValue.setVisibility(View.VISIBLE);
                    holder.couponValue.setText(String.format(context.getString(R.string.common_goods_coupons_value_format), NumberUtils.format(couponValue)));
                }

                double currentPrice = Double.valueOf(goods.getCurrent_price());
                String currentPriceStr = NumberUtils.format(currentPrice);
                holder.currentPrice.setText(String.format(context.getString(R.string.common_goods_price_format), currentPriceStr));

                int volume = goods.getSales_volume();
                String formatString;
                if (10000 > volume) {
                    formatString = context.getString(R.string.common_already_sell_format); //%d
                    holder.sell.setText(String.format(formatString, volume));
                } else {
                    formatString = context.getString(R.string.common_already_sell_format2); //%s
                    float floatVolume = volume / 10000.0f;
                    holder.sell.setText(String.format(formatString, NumberUtils.format(floatVolume)));
                }

                double orderFee = Double.valueOf(goods.getCommission_fee());
                if (orderFee - 0.001 > 0) {
                    formatString = context.getString(R.string.common_forecast_earnings_format);
                    holder.orderRebate.setVisibility(View.VISIBLE);
                    holder.orderRebate.setText(String.format(Locale.getDefault(), formatString, NumberUtils.format(orderFee)));
                } else {
                    holder.orderRebate.setVisibility(View.GONE);
                }

                if (TextUtils.isEmpty(goods.getShop_title())) {
                    holder.groupShop.setVisibility(View.GONE);
                } else {
                    holder.groupShop.setVisibility(View.VISIBLE);
                    holder.shopName.setText(goods.getShop_title());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class GoodsHolderList extends CustomBaseHolder {
        private ImageView icon;
        private TextView title;
        private TextView couponValue;
        private TextView currentPrice;
        private TextView originPrice;
        private TextView sell;
        private TextView orderRebate;
        private TextView shopName;
        private Group groupShop;

        public GoodsHolderList(View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.iv_goods_list);
            title = itemView.findViewById(R.id.tv_goods_title_list);
            couponValue = itemView.findViewById(R.id.tv_goods_coupon_goods_list);
            currentPrice = itemView.findViewById(R.id.tv_goods_current_price_list);
            originPrice = itemView.findViewById(R.id.tv_origin_price_goods_list);
            sell = itemView.findViewById(R.id.tv_goods_sales_volume_list);
            orderRebate = itemView.findViewById(R.id.tv_goods_order_rebate_list);
            shopName = itemView.findViewById(R.id.tv_goods_shop_name_list);
            groupShop = itemView.findViewById(R.id.group_goods_shop_list);
        }
    }

    @Override
    public void clearImageViews() {
        for (ImageView view : mListImageView) {
            GlideUtils.clearImageView(view);
        }
    }

}
