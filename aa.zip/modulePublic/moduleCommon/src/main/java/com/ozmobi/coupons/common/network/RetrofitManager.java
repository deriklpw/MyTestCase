package com.ozmobi.coupons.common.network;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.support.retrofit.Retrofit2ConverterFactory;
import com.ozmobi.coupons.base.GlobalAppInfo;
import com.ozmobi.coupons.base.utils.DesUtil;
import com.ozmobi.coupons.base.utils.LogUtil;

import java.io.IOException;
import java.net.Proxy;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.Buffer;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

public class RetrofitManager {

    private static RetrofitManager instance;
    private Retrofit retrofit;

    private static final String TEST_HOST = "tbktest.free-eyepro.com";
    private static final String RELEASE_HOST = "tbk.free-eyepro.com";

    private static final String TEST_SERVER_URL = "http://" + TEST_HOST + "/";
    private static final String RELEASE_SERVER_URL = "http://" + RELEASE_HOST + "/";
    private String baseHost;

    private RetrofitManager() {
        String baseUrl;
        if (GlobalAppInfo.isDebug) {
            baseHost = TEST_HOST;
            baseUrl = TEST_SERVER_URL;
        } else {
            baseHost = RELEASE_HOST;
            baseUrl = RELEASE_SERVER_URL;
        }
        retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(httpClient())
                .addConverterFactory(new Retrofit2ConverterFactory())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .build();
    }

    public void destroy() {
        instance = null;
    }

    public static RetrofitManager getInstance() {
        if (instance == null) {
            synchronized (RetrofitManager.class) {
                instance = new RetrofitManager();
            }
        }
        return instance;
    }

    public <T> T create(Class<T> service) {
        return retrofit.create(service);
    }

    private OkHttpClient httpClient() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .addInterceptor(new EncryptInterceptor());

        //非debug时，不允许代理
        if (!GlobalAppInfo.isDebug) {
            builder.proxy(Proxy.NO_PROXY);
        }

        return builder.build();
    }

    public class EncryptInterceptor implements Interceptor {
        private static final String TAG = "EncryptInterceptor";
        private static final String CHARSET = "UTF-8";

        @Override
        public Response intercept(Chain chain) throws IOException, NullPointerException {
            Request originRequest = chain.request();
            Response response = null;

            try {
                String host = originRequest.url().host();
                LogUtil.d(TAG, "intercept: url= " + originRequest.url());
                //只针对自己的域名加密
                if (baseHost.equals(host)) {
                    //POST，对数据加密，GET无需走加密流程
                    if ("POST".equalsIgnoreCase(originRequest.method())) {
                        String originParamsStr = getParams(originRequest.body());

                        //加密
                        String url = originRequest.url().toString();
                        String encryptStr;
                        //更新头像
                        //特殊url处理，OKHttp把base64图片编码加号换成了空格，这里换回来再加密
                        if (url.endsWith("api.php?m=user&p=updateuserinfo")) {

                            JSONObject rootObject = JSON.parseObject(originParamsStr);
                            JSONObject paramsObj = rootObject.getJSONObject("param");
                            if (paramsObj.containsKey("icon")) {
                                String iconBase = paramsObj.getString("icon");
                                iconBase = iconBase.replace(" ", "+");
                                paramsObj.put("icon", iconBase);
                                rootObject.put("param", paramsObj);
                                originParamsStr = rootObject.toJSONString();
                            }
                        }
                        LogUtil.d(TAG, "intercept: origin json= " + originParamsStr);
                        encryptStr = DesUtil.encode(originParamsStr);
                        LogUtil.d(TAG, "intercept: encryptStr json = " + encryptStr);

                        JSONObject newRequestJsonObj = new JSONObject();
                        newRequestJsonObj.put("data", encryptStr);
                        String requestEncryptStr = newRequestJsonObj.toString();
                        LogUtil.d(TAG, "intercept: requestEncryptStr json = " + requestEncryptStr);

                        RequestBody newRequestBody = RequestBody.create(originRequest.body().contentType(), requestEncryptStr);
                        Request newRequest = originRequest.newBuilder()
                                .post(newRequestBody)
                                .build();
                        //响应
                        response = chain.proceed(newRequest);
                    } else {
                        //响应
                        response = chain.proceed(originRequest);
                    }

                    LogUtil.d(TAG, "intercept: response code =" + response.code());

                    //只有200的返回码才经过加密，才需要走解密的逻辑
                    if (response.code() == 200) {
                        //获取响应体
                        ResponseBody oldResponseBody = response.body();

                        String oldResponseBodyStr = oldResponseBody.string();
                        LogUtil.d(TAG, "intercept: response old " + oldResponseBodyStr);
                        JSONObject oldResponseJsonObj = JSONObject.parseObject(oldResponseBodyStr);

                        //获取已加密数据
                        String responseEncryptStr = oldResponseJsonObj.getString("data");
                        //解密
                        String responseDecryptStr = DesUtil.decode(responseEncryptStr);

                        LogUtil.d(TAG, "intercept: response new " + responseDecryptStr);
                        oldResponseBody.close();
                        //构造新的response
                        ResponseBody newResponseBody = ResponseBody.create(response.body().contentType(), responseDecryptStr);
                        response = response.newBuilder().body(newResponseBody).build();
                        newResponseBody.close();
                        response.close();
                    }

                } else {
                    response = chain.proceed(originRequest);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return response;
        }

        private String getParams(RequestBody requestBody) {
            Buffer buffer = new Buffer();
            String params = "";
            try {
                requestBody.writeTo(buffer);
                params = buffer.readUtf8();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                buffer.close();
            }
            return params;
        }
    }

}
