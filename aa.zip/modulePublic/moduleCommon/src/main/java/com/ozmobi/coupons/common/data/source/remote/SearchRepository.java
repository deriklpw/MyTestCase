package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.bean.QuerySugBean;
import com.ozmobi.coupons.common.data.source.SearchDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

public class SearchRepository implements SearchDataSource {

    private static final String TAG = "SearchRepository";

    @Override
    public Disposable getQuerySug(@NonNull String query, @NonNull Consumer<? super QuerySugBean> success, @NonNull Consumer<? super Throwable> error) {

        return ApiFactory.getYjlController().getQueryHint(query, "utf-8")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable getSearchGoods(@NonNull String query, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {

        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            if (!TextUtils.isEmpty(sort)) {
                params.put("sort", sort);
            }
            params.put("q", query);
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "search post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        return ApiFactory.getYjlController().getQueryGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable getUrlGoods(@NonNull String url, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {

        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            if (!TextUtils.isEmpty(sort)) {
                params.put("sort", sort);
            }
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "search post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        return ApiFactory.getYjlController().getUrlListGoods(url, requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

}
