package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;

import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.bean.GoodsDetailsPageBean;
import com.ozmobi.coupons.common.bean.ShareTextBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public interface GoodsDataSource extends BaseDataSource {
    /**
     * 获取店铺优惠券商品
     *
     * @param shopName
     * @param success
     * @param error
     * @return
     */
    Disposable getShopCouponsGoods(@NonNull String shopName, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取商品详情
     */
    Disposable getGoodsDetails(@NonNull String numIId, @NonNull String platType, @NonNull Consumer<? super GoodsDetailsPageBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取相关商品
     * @param numIId
     * @param success
     * @param error
     * @return
     */
    Disposable getRelatedGoods(@NonNull String numIId, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取分享的文本信息
     * @param numIId
     * @param success
     * @param error
     * @return
     */
    Disposable getGoodsShareText(@NonNull String numIId, @NonNull Consumer<? super ShareTextBean> success, @NonNull Consumer<? super Throwable> error);
}
