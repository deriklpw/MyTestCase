package com.ozmobi.coupons.common;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.design.widget.AppBarLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ozmobi.coupons.base.GlobalAppInfo;
import com.ozmobi.coupons.common.dialog.LoadingDialogFragment;
import com.ozmobi.coupons.common.dialog.SearchReminderDialogFragment;
import com.ozmobi.coupons.common.ui.search.result.SearchResultActivity;
import com.ozmobi.coupons.common.utils.ClipBoardUtil;
import com.ozmobi.coupons.base.Constants;

import com.ozmobi.coupons.base.utils.LanguageUtil;
import com.ozmobi.coupons.base.utils.NetworkUtil;
import com.ozmobi.coupons.base.utils.PrefUtils;
import com.ozmobi.coupons.base.utils.StatusBarUtil;
import com.umeng.analytics.MobclickAgent;

import java.util.ArrayList;

public abstract class BaseActivity extends AppCompatActivity implements SearchReminderDialogFragment.OnConfirmClickCallback, BaseView {

    private static final String TAG_SEARCH_DIALOG = "SearchReminderDialog";

    private static final String TAG_LOADING_DIALOG = "LoadingDialog";

    /**
     * 通用标题
     */
    private TextView mTvTitleBase;

    /**
     * 通用Appbar
     */
    private AppBarLayout mAppBarLayoutBase;

    /**
     * 通用Toolbar
     */
    private Toolbar mToolbarBase;

    /**
     * 通用提示
     */
    private Toast mToast;

    /**
     * 设置布局Id
     *
     * @return
     */
    protected abstract
    @LayoutRes
    int getLayoutId();

    protected abstract void initViews();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //字体不随系统缩放
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        displayMetrics.scaledDensity = displayMetrics.density;

        setContentView(R.layout.common_activity_base);

        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

        if (Build.VERSION.SDK_INT < 19) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }

        if (savedInstanceState != null) {
            LoadingDialogFragment loadingDialog = (LoadingDialogFragment) getSupportFragmentManager().findFragmentByTag(TAG_LOADING_DIALOG);
            if (loadingDialog != null) {
                loadingDialog.dismissAllowingStateLoss();
            }
        }

        initCommonAppbar();
        setContentLayout();

        initViews();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        LoadingDialogFragment loadingDialog = (LoadingDialogFragment) getSupportFragmentManager().findFragmentByTag(TAG_LOADING_DIALOG);
        if (loadingDialog != null) {
            loadingDialog.dismissAllowingStateLoss();
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //限制字体设置
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        displayMetrics.scaledDensity = displayMetrics.density;
    }

    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);
        //除启动页，其他均检测剪贴板
        if (!getClass().getSimpleName().equals("SplashActivity") &&
                !getClass().getSimpleName().equals("GuideActivity")) {
            checkClipBoard();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }

    /**
     * 设置内容区域
     */
    private void setContentLayout() {
        FrameLayout contentRootView = findViewById(R.id.fl_content_base);
        contentRootView.removeAllViews();
        getLayoutInflater().inflate(getLayoutId(), contentRootView, true);
    }

    /**
     * 初始化Appbar，包含状态栏和Toolbar
     */
    private void initCommonAppbar() {
        mAppBarLayoutBase = findViewById(R.id.appbar_base);
        mToolbarBase = findViewById(R.id.toolbar_base);
        mTvTitleBase = findViewById(R.id.tv_toolbar_title_base);

        mAppBarLayoutBase.setPadding(0, GlobalAppInfo.statusHeight, 0, 0);
        setSupportActionBar(mToolbarBase);
        mTvTitleBase.setText("");

        //默认ToolBar黑色主题，可返回
        setAppbarToolbarBlack(true);
    }

    /**
     * 设置Toolbar标题
     *
     * @param title
     */
    public void setToolbarTitle(String title) {
        mTvTitleBase.setText(title);
    }

    /**
     * 设置Toolbar标题颜色
     *
     * @param color
     */
    public void setToolbarTitleColor(int color) {
        mTvTitleBase.setTextColor(color);
    }

    /**
     * 设置Appbar背景色，包括状态栏和toolbar区域
     *
     * @param color
     */
    public void setAppbarBackgroundColor(int color) {
        mAppBarLayoutBase.setBackgroundColor(color);
    }

    /**
     * 设置Appbar背景图，包括状态栏和toolbar区域
     *
     * @param resId
     */
    public void setAppbarBackgroundResource(int resId) {
        mAppBarLayoutBase.setBackgroundResource(resId);
    }

    /**
     * 隐藏Appbar
     */
    public void hideAppbar() {
        mAppBarLayoutBase.setVisibility(View.GONE);
    }

    /**
     * 显示Appbar
     */
    public void showAppbar() {
        mAppBarLayoutBase.setVisibility(View.VISIBLE);
    }

    /**
     * 设置黑色背景，黑色字体和按钮
     *
     * @param enableBack 返回按钮使能
     */
    public void setAppbarToolbarBlack(boolean enableBack) {
        //背景需是白色
        setAppbarBackgroundColor(Color.WHITE);

        setStatusToolbarBlack(enableBack);
    }

    /**
     * 设置默认红背景，白色字体和按钮
     *
     * @param enableBack 返回按钮使能
     */
    public void setAppbarToolbarWhite(boolean enableBack) {
        //背景默认红色渐变
        setAppbarBackgroundResource(R.drawable.common_shape_statusbar);

        setStatusToolbarWhite(enableBack);
    }

    /**
     * 设置状态栏，toolbar黑色字体和按钮
     *
     * @param enableBack
     */
    public void setStatusToolbarBlack(boolean enableBack) {
        //黑色返回按钮
        setToolbarBackButton(false, enableBack);
        //黑色标题
        setToolbarTitleColor(getResources().getColor(R.color.common_color_black));
        //黑色状态栏文字
        StatusBarUtil.setStatusBar(this, false, false);
        StatusBarUtil.setStatusTextColor(true, this);
    }

    /**
     * 设置状态栏，toolbar白色字体和按钮
     *
     * @param enableBack
     */
    public void setStatusToolbarWhite(boolean enableBack) {
        //白色返回按钮
        setToolbarBackButton(true, enableBack);
        //白色标题
        setToolbarTitleColor(Color.WHITE);
        //白色状态栏文字
        StatusBarUtil.setStatusBar(this, false, false);
        StatusBarUtil.setStatusTextColor(false, this);
    }

    /**
     * 设置返回按钮颜色，黑色或白色
     *
     * @param isWhite
     * @param enableBack
     */
    public void setToolbarBackButton(boolean isWhite, boolean enableBack) {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.setDisplayHomeAsUpEnabled(enableBack);
            Drawable backDrawable = getResources().getDrawable(R.mipmap.common_ic_back_black);

            if (isWhite) {
                backDrawable.mutate();
                backDrawable.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
            }
            actionBar.setHomeAsUpIndicator(backDrawable);
        }
    }

    /**
     * 设置Appbar
     *
     * @param appBarLayout
     */
    public void setAppBar(AppBarLayout appBarLayout) {
        //隐藏通用Toolbar
        hideAppbar();
        mAppBarLayoutBase = appBarLayout;
        mAppBarLayoutBase.setPadding(0, GlobalAppInfo.statusHeight, 0, 0);
    }

    /**
     * 获取AppBar
     *
     * @return
     */
    public AppBarLayout getAppBar() {
        return mAppBarLayoutBase;
    }

    /**
     * 如果只需用到Toolbar，须调用hideAppbar
     *
     * @param toolbar
     */
    public void setToolbar(Toolbar toolbar) {
        setSupportActionBar(toolbar);
        mToolbarBase = toolbar;
    }

    /**
     * 获取Toolbar
     *
     * @return
     */
    public Toolbar getToolbar() {
        return mToolbarBase;
    }

    /**
     * 设置新的Appbar，Toolbar，及Title
     *
     * @param appBarLayout
     * @param toolbar
     * @param tvTitle
     */
    public void setAppBarAndToolbar(AppBarLayout appBarLayout, Toolbar toolbar, TextView tvTitle) {
        setAppBar(appBarLayout);
        setToolbar(toolbar);

        mTvTitleBase = tvTitle;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    /**
     * 默认返回按钮，结束页面
     *
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * 登录注册流程中用到
     */
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //如果按返回键，移除当前Activity
//        CouponsApplication.getInstance().getActivities().remove(this);
    }

    private void checkClipBoard() {
        if (!ClipBoardUtil.isSelfAppCopyText(this)) {
            String clipText = ClipBoardUtil.getClipText(this);

            if (!TextUtils.isEmpty(clipText)) {
                String text = clipText.trim();
                if (!TextUtils.isEmpty(text) && text.length() > Constants.CLIP_DATA_LENGTH_MIN && LanguageUtil.isChinese(text)) {
                    SearchReminderDialogFragment searchDialog = (SearchReminderDialogFragment) getSupportFragmentManager().findFragmentByTag(TAG_SEARCH_DIALOG);
                    if (searchDialog == null) {
                        searchDialog = SearchReminderDialogFragment.newInstance(text);
                        searchDialog.show(getSupportFragmentManager(), TAG_SEARCH_DIALOG);
                    } else {
                        searchDialog.updateSearchText(text);
                    }
                }
            }
        }
    }

    @Override
    public void onConfirmClick(SearchReminderDialogFragment dialogFragment, String text) {
        dialogFragment.dismissAllowingStateLoss();
        SearchResultActivity.startForSearchResult(this, text);

        saveHistory(text);
    }

    @Override
    public void onCancelClick(SearchReminderDialogFragment dialogFragment) {
        dialogFragment.dismissAllowingStateLoss();
    }

    public void saveHistory(String text) {
        try {
            if (TextUtils.isEmpty(text)) {
                return;
            }
            ArrayList<String> historyWords = PrefUtils.getCurrentObject(this.getApplication().getApplicationContext(), PrefUtils.SEARCH_HISTORY, ArrayList.class);
            if (historyWords != null) {
                if (historyWords.contains(text)) {
                    historyWords.remove(text);
                }
            } else {
                historyWords = new ArrayList<>();
            }

            if (historyWords.size() >= Constants.SEARCH_HISTORY_SAVE_MAX) {
                historyWords.remove(0);
            }

            historyWords.add(text);
            PrefUtils.setCurrentObject(this.getApplication().getApplicationContext(), PrefUtils.SEARCH_HISTORY, historyWords);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void toastNetError() {
        toastLongBase(getString(R.string.common_network_error));
    }

    @Override
    public void toastGetDataFail() {
        toastShortBase(getString(R.string.common_get_data_error));
    }

    @Override
    public void toastServerBusiness() {
        toastLongBase(getString(R.string.common_server_business));
    }

    @Override
    public void toastMsg(String msg) {
        toastShortBase(msg);
    }

    @Override
    public void showError() {
        if (NetworkUtil.isNetworkAvailable()) {
            toastGetDataFail();
        } else {
            toastNetError();
        }
    }

    @Override
    public boolean isLoading() {
        LoadingDialogFragment loadingDialog = (LoadingDialogFragment) getSupportFragmentManager().findFragmentByTag(TAG_LOADING_DIALOG);
        return loadingDialog != null && loadingDialog.isAdded();
    }

    @Override
    public void showLoading() {
        LoadingDialogFragment loadingDialog = (LoadingDialogFragment) getSupportFragmentManager().findFragmentByTag(TAG_LOADING_DIALOG);
        if (loadingDialog == null) {
            loadingDialog = LoadingDialogFragment.newInstance();
            loadingDialog.show(getSupportFragmentManager(), TAG_LOADING_DIALOG);
        } else {
            if (!loadingDialog.isAdded()) {
                loadingDialog.show(getSupportFragmentManager(), TAG_LOADING_DIALOG);
            }
        }
    }

    @Override
    public void hideLoading() {
        LoadingDialogFragment loadingDialog = (LoadingDialogFragment) getSupportFragmentManager().findFragmentByTag(TAG_LOADING_DIALOG);
        if (loadingDialog != null && loadingDialog.isAdded()) {
            loadingDialog.dismissAllowingStateLoss();
        }
    }

    private void toastShortBase(String msg) {
        if (TextUtils.isEmpty(msg)) {
            return;
        }
        if (mToast != null) {
            mToast.cancel();
            mToast = null;
        }
        mToast = Toast.makeText(this, msg, Toast.LENGTH_SHORT);
        mToast.show();
    }

    private void toastLongBase(String msg) {
        if (TextUtils.isEmpty(msg)) {
            return;
        }
        if (mToast != null) {
            mToast.cancel();
            mToast = null;
        }
        mToast = Toast.makeText(this, msg, Toast.LENGTH_LONG);
        mToast.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mToast != null) {
            mToast.cancel();
            mToast = null;
        }
    }
}
