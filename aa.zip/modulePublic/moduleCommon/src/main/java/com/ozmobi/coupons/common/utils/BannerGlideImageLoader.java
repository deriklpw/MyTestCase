package com.ozmobi.coupons.common.utils;

import android.content.Context;
import android.widget.ImageView;

import com.ozmobi.coupons.common.R;
import com.youth.banner.loader.ImageLoader;

/**
 * Created by xhkj on 2019/7/15.
 */

public class BannerGlideImageLoader extends ImageLoader {
    @Override
    public void displayImage(Context context, Object path, ImageView imageView) {
        imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        GlideUtils.initImageWithFileCache((String) path, R.mipmap.common_ic_image_place_holder, imageView);
    }

}
