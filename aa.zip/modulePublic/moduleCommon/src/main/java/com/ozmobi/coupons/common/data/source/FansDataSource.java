package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.common.bean.FansFilterBean;
import com.ozmobi.coupons.common.bean.IndirectDirectFansBean;
import com.ozmobi.coupons.common.bean.MyFansBean;
import com.ozmobi.coupons.common.bean.FansRankBean;
import com.ozmobi.coupons.common.bean.SearchFansBean;
import com.ozmobi.coupons.common.bean.SmsDetailBean;
import com.ozmobi.coupons.common.bean.StatusFansBean;
import com.ozmobi.coupons.common.bean.TodayOrdersBean;
import com.ozmobi.coupons.common.bean.WakeupFansBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public interface FansDataSource extends BaseDataSource {

    /**
     * 获取粉丝概况数据
     * @return
     */
    Disposable getMyFans(@NonNull Consumer<? super MyFansBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取直接或间接，粉丝列表详情
     * @return
     */
    Disposable getMyFansDetail(int level, int pageSize, int page, @NonNull Consumer<? super IndirectDirectFansBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取直接或间接粉丝，贡献排行榜
     * @param level
     * @param pageSize
     * @param page
     * @param success
     * @param error
     * @return
     */
    Disposable getFansRank(int level, int pageSize, int page, @NonNull Consumer<? super FansRankBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取直接或间接粉丝中，指定状态的粉丝列表
     * @param level
     * @param status
     * @param pageSize
     * @param page
     * @param success
     * @param error
     * @return
     */
    Disposable getStatusFansList(int level, int status, int pageSize, int page, @NonNull Consumer<? super StatusFansBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 查询粉丝，前提，已登陆
     * @param keyword
     * @param success
     * @param error
     * @return
     */
    Disposable searchFans(String keyword, @NonNull Consumer<? super SearchFansBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取直接或间接粉丝，今日已出订单
     * @param level
     * @param pageSize
     * @param page
     * @param success
     * @param error
     * @return
     */
    Disposable getTodayOrders(int level, int pageSize, int page, @NonNull Consumer<? super TodayOrdersBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 唤醒粉丝
     */
    Disposable wakeupFans(@NonNull Consumer<? super WakeupFansBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 粉丝刷选
     */
    Disposable getFansWithFilter(String day, String type, @NonNull Consumer<? super FansFilterBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 发送召回短信
     */
    Disposable sendSmsToWakeupFans(JSONArray uIds, String smsId, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 短信余额明细
     */
    Disposable getSmsMoneyDetail(int pageSize, int page, @NonNull Consumer<? super SmsDetailBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 券当家余额充值到短信余额
     */
    Disposable topUpBalance(String money, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 提现短信余额到券当家余额
     */
    Disposable withdrawSmsMoney(String money, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 支付宝充值到短信余额
     */
    Disposable topUpBalanceWithAlipay(String money, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

}
