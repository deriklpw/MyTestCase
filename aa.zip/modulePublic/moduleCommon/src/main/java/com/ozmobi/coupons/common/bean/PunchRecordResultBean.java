package com.ozmobi.coupons.common.bean;

/**
 * Created by xhkj on 2019/9/25.
 */

public class PunchRecordResultBean {
    private int error;
    private String msg;
    private DataBean data;
    private int time;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public static class DataBean {
        private int input_integral;
        private int reward_integral;
        private int success_times;

        public int getInput_integral() {
            return input_integral;
        }

        public void setInput_integral(int input_integral) {
            this.input_integral = input_integral;
        }

        public int getReward_integral() {
            return reward_integral;
        }

        public void setReward_integral(int reward_integral) {
            this.reward_integral = reward_integral;
        }

        public int getSuccess_times() {
            return success_times;
        }

        public void setSuccess_times(int success_times) {
            this.success_times = success_times;
        }
    }
}
