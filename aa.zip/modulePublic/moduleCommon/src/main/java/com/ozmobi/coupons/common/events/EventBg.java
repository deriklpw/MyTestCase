package com.ozmobi.coupons.common.events;

/**
 * Created by xhkj on 2019/5/14.
 */

public class EventBg {
    private String color;
    private String cate;

    public EventBg (String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getCate() {
        return cate;
    }

    public void setCate(String cate) {
        this.cate = cate;
    }
}
