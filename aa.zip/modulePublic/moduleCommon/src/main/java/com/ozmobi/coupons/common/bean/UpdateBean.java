package com.ozmobi.coupons.common.bean;

/**
 * Created by xhkj on 2019/8/5.
 */

public class UpdateBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private VerEntity ver;

        public void setVer(VerEntity ver) {
            this.ver = ver;
        }

        public VerEntity getVer() {
            return ver;
        }

        public class VerEntity {
            private String is_force;
            private String addtime;
            private String app_ver;
            private String type;
            private String tips;
            private String url;

            public void setIs_force(String is_force) {
                this.is_force = is_force;
            }

            public void setAddtime(String addtime) {
                this.addtime = addtime;
            }

            public void setApp_ver(String app_ver) {
                this.app_ver = app_ver;
            }

            public void setType(String type) {
                this.type = type;
            }

            public void setTips(String tips) {
                this.tips = tips;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public String getIs_force() {
                return is_force;
            }

            public String getAddtime() {
                return addtime;
            }

            public String getApp_ver() {
                return app_ver;
            }

            public String getType() {
                return type;
            }

            public String getTips() {
                return tips;
            }

            public String getUrl() {
                return url;
            }
        }
    }
}
