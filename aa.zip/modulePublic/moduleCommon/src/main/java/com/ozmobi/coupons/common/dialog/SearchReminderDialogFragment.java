package com.ozmobi.coupons.common.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.utils.ClipBoardUtil;
import com.umeng.analytics.MobclickAgent;

/**
 * Created by xhkj on 2019/3/19.
 */

public class SearchReminderDialogFragment extends BaseDialogFragment {

    private static final String TAG = "SearchDialogFragment";

    private static final String ARG_PARAM_TEXT = "param_text";

    private OnConfirmClickCallback mCallback;

    private String mContent;

    private TextView mTvSearchText;

    public interface OnConfirmClickCallback {
        void onConfirmClick(SearchReminderDialogFragment dialog, String text);

        void onCancelClick(SearchReminderDialogFragment dialog);
    }

    public SearchReminderDialogFragment() {
        // Required empty public constructor
    }

    public static SearchReminderDialogFragment newInstance(String text) {
        SearchReminderDialogFragment fragment = new SearchReminderDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }

    public void updateSearchText(String text) {
        mContent = text;
        if (mTvSearchText != null) {
            mTvSearchText.setText(mContent);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mContent = getArguments().getString(ARG_PARAM_TEXT);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.d(TAG, "onResume: ");
        MobclickAgent.onPageStart(TAG);
    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.d(TAG, "onPause: ");
        MobclickAgent.onPageEnd(TAG);
    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtil.d(TAG, "onStop: ");
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateDialog: ");
        AlertDialog dialog = new AlertDialog.Builder(mContext).create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.CENTER);
        window.setContentView(R.layout.common_dialog_fragment_search_reminder);

        mTvSearchText = window.findViewById(R.id.tv_search_dialog_content);
        mTvSearchText.setText(mContent);

        TextView btnCancel = window.findViewById(R.id.btn_search_dialog_cancel);

        TextView btnConfirm = window.findViewById(R.id.btn_search_dialog_confirm);

        btnCancel.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                if (mCallback != null) {
                    mCallback.onCancelClick(SearchReminderDialogFragment.this);
                }
            }
        });

        btnConfirm.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                if (mCallback != null) {
                    mCallback.onConfirmClick(SearchReminderDialogFragment.this, mContent);
                }
            }
        });

        return dialog;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateView: ");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        LogUtil.d(TAG, "onAttach: ");
        if (context instanceof OnConfirmClickCallback) {
            mCallback = (OnConfirmClickCallback) context;
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        LogUtil.d(TAG, "onDetach: ");
        mCallback = null;
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (mContext != null) {
            ClipBoardUtil.clearClip(mContext);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtil.d(TAG, "onDestroy: ");
    }

}
