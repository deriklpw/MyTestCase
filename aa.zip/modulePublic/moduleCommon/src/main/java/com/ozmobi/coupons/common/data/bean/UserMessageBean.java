package com.ozmobi.coupons.common.data.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by xhkj on 2019/7/18.
 */

public class UserMessageBean implements Parcelable {
    private String nick;
    private String icon;
    private String content;
    private String time;

    public UserMessageBean(String nick, String icon, String content, String time) {
        this.nick = nick;
        this.icon = icon;
        this.content = content;
        this.time = time;
    }

    protected UserMessageBean(Parcel in) {
        nick = in.readString();
        icon = in.readString();
        content = in.readString();
        time = in.readString();
    }

    public static final Creator<UserMessageBean> CREATOR = new Creator<UserMessageBean>() {
        @Override
        public UserMessageBean createFromParcel(Parcel in) {
            return new UserMessageBean(in);
        }

        @Override
        public UserMessageBean[] newArray(int size) {
            return new UserMessageBean[size];
        }
    };

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nick);
        dest.writeString(icon);
        dest.writeString(content);
        dest.writeString(time);
    }
}
