package com.ozmobi.coupons.common;

public interface BaseView {

    void toastNetError();

    void toastServerBusiness();

    void toastGetDataFail();

    void toastMsg(String msg);

    boolean isLoading();

    void showLoading();

    void hideLoading();

    void showError();

}
