package com.ozmobi.coupons.common.events;

/**
 * Created by xhkj on 2019/5/14.
 */

public class EventCollapse {
    private boolean collapse;

    public EventCollapse(boolean collapse){
        this.collapse = collapse;
    }

    public boolean isCollapse() {
        return collapse;
    }

    public void setCollapse(boolean collapse) {
        this.collapse = collapse;
    }
}
