package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/6/12.
 */

public class GoodsDetailsPageBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private String share_text;
        private List<String> detail_images;
        private ShopEntity shop;
        private String share_label;
        private String tkl_text;

        public void setShare_text(String share_text) {
            this.share_text = share_text;
        }

        public void setDetail_images(List<String> detail_images) {
            this.detail_images = detail_images;
        }

        public void setShop(ShopEntity shop) {
            this.shop = shop;
        }

        public void setShare_label(String share_label) {
            this.share_label = share_label;
        }

        public void setTkl_text(String tkl_text) {
            this.tkl_text = tkl_text;
        }

        public String getShare_text() {
            return share_text;
        }

        public List<String> getDetail_images() {
            return detail_images;
        }

        public ShopEntity getShop() {
            return shop;
        }

        public String getShare_label() {
            return share_label;
        }

        public String getTkl_text() {
            return tkl_text;
        }

        public class ShopEntity {
            private String name;
            private String icon;
            private String shopid;
            private List<EvaluatesEntity> evaluates;

            public void setName(String name) {
                this.name = name;
            }

            public void setIcon(String icon) {
                this.icon = icon;
            }

            public void setShopid(String shopid) {
                this.shopid = shopid;
            }

            public void setEvaluates(List<EvaluatesEntity> evaluates) {
                this.evaluates = evaluates;
            }

            public String getName() {
                return name;
            }

            public String getIcon() {
                return icon;
            }

            public String getShopid() {
                return shopid;
            }

            public List<EvaluatesEntity> getEvaluates() {
                return evaluates;
            }

            public class EvaluatesEntity {
                private String score;
                private String tmallLevelTextColor;
                private String level;
                private String levelText;
                private String levelBackgroundColor;
                private String levelTextColor;
                private String title;
                private String type;
                private String tmallLevelBackgroundColor;

                public void setScore(String score) {
                    this.score = score;
                }

                public void setTmallLevelTextColor(String tmallLevelTextColor) {
                    this.tmallLevelTextColor = tmallLevelTextColor;
                }

                public void setLevel(String level) {
                    this.level = level;
                }

                public void setLevelText(String levelText) {
                    this.levelText = levelText;
                }

                public void setLevelBackgroundColor(String levelBackgroundColor) {
                    this.levelBackgroundColor = levelBackgroundColor;
                }

                public void setLevelTextColor(String levelTextColor) {
                    this.levelTextColor = levelTextColor;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public void setTmallLevelBackgroundColor(String tmallLevelBackgroundColor) {
                    this.tmallLevelBackgroundColor = tmallLevelBackgroundColor;
                }

                public String getScore() {
                    return score;
                }

                public String getTmallLevelTextColor() {
                    return tmallLevelTextColor;
                }

                public String getLevel() {
                    return level;
                }

                public String getLevelText() {
                    return levelText;
                }

                public String getLevelBackgroundColor() {
                    return levelBackgroundColor;
                }

                public String getLevelTextColor() {
                    return levelTextColor;
                }

                public String getTitle() {
                    return title;
                }

                public String getType() {
                    return type;
                }

                public String getTmallLevelBackgroundColor() {
                    return tmallLevelBackgroundColor;
                }
            }
        }
    }
}
