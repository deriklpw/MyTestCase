package com.ozmobi.coupons.common.utils;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.WorkerThread;
import android.support.v4.app.Fragment;

import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.ozmobi.coupons.base.Constants;
import com.ozmobi.coupons.base.utils.SDCardTest;
import com.ozmobi.coupons.common.CommonApplicationLikeImpl;
import com.ozmobi.coupons.common.module.GlideApp;

import java.io.File;
import java.lang.ref.WeakReference;
import java.math.BigDecimal;


/**
 * Created by xhkj on 2019/3/16.
 * <p>
 * 默认CenterCrop裁剪
 */

public class GlideUtils {

    public static void initImageWithFileCache(String url, int placeHolder, ImageView imageView) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        Context context = CommonApplicationLikeImpl.getContext();
        WeakReference<ImageView> imageViewWeakReference = new WeakReference<>(imageView);

        GlideApp.with(context)
                .load(url)
                .placeholder(placeHolder)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageViewWeakReference.get());
    }

    public static void initImageWithNoHolder(String url, ImageView imageView) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        Context context = CommonApplicationLikeImpl.getContext();
        WeakReference<ImageView> imageViewWeakReference = new WeakReference<>(imageView);

        GlideApp.with(context)
                .load(url)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageViewWeakReference.get());
    }

    /**
     * 强引用，带占位图
     *
     * @param activity
     * @param url
     * @param placeHolder
     * @param imageView
     */
    public static void initImageWithActivity(Activity activity, String url, int placeHolder, ImageView imageView) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        GlideApp.with(activity)
                .load(url)
                .placeholder(placeHolder)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageView);
    }

    /**
     * 强引用
     *
     * @param activity
     * @param url
     * @param imageView
     */
    public static void initImageWithActivity(Activity activity, String url, ImageView imageView) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        GlideApp.with(activity)
                .load(url)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageView);
    }

    /**
     * 强引用，带占位图
     *
     * @param activity
     * @param url
     * @param placeHolder
     * @param imageView
     */
    public static void initImageWithActivityFitCenter(Activity activity, String url, int placeHolder, ImageView imageView) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        GlideApp.with(activity)
                .load(url)
                .placeholder(placeHolder)
                .fitCenter()
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(imageView);
    }

    /**
     * 自适应宽度加载图片。保持图片的长宽比例不变，通过修改imageView的高度来完全显示图片。
     */
    public static void loadIntoUseFitWidth(String imageUrl, ImageView imageView) {
        if (TextUtils.isEmpty(imageUrl)) {
            return;
        }
        Context context = CommonApplicationLikeImpl.getContext();
        WeakReference<ImageView> imageViewWeakReference = new WeakReference<>(imageView);

        GlideApp.with(context)
                .load(imageUrl)
                .into(new SimpleTarget<Drawable>(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL) {
                    @Override
                    public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                        ImageView view = imageViewWeakReference.get();

                        if (view != null) {
                            int imageWidth = resource.getIntrinsicWidth();
                            int imageHeight = resource.getIntrinsicHeight();

                            int height = view.getWidth() * imageHeight / imageWidth;
                            ViewGroup.LayoutParams para = view.getLayoutParams();
                            if (para != null) {
                                para.height = height;
                                view.setLayoutParams(para);
                            }
                            GlideApp.with(context)
                                    .load(imageUrl)
                                    .transition(DrawableTransitionOptions.withCrossFade())
                                    .into(view);
                        }
                    }
                });
    }

    /**
     * 加载到指定Target
     *
     * @param activity
     * @param imageUrl
     * @param simpleTarget
     */
    public static void loadIntoUseTarget(Activity activity, final String imageUrl, SimpleTarget<Bitmap> simpleTarget) {
        if (TextUtils.isEmpty(imageUrl)) {
            return;
        }
        GlideApp.with(activity)
                .asBitmap()
                .load(imageUrl)
                .into(simpleTarget);
    }

    public static void loadIntoUseTarget(Context context, final String imageUrl, SimpleTarget<Drawable> simpleTarget) {
        if (TextUtils.isEmpty(imageUrl)) {
            return;
        }
        GlideApp.with(context)
                .load(imageUrl)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(simpleTarget);
    }

    /**
     * 加载到指定Target
     *
     * @param fragment
     * @param imageUrl
     * @param simpleTarget
     */
    public static void loadIntoUseTarget(Fragment fragment, final String imageUrl, SimpleTarget<Drawable> simpleTarget) {
        if (TextUtils.isEmpty(imageUrl)) {
            return;
        }
        GlideApp.with(fragment)
                .load(imageUrl)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(simpleTarget);
    }

    public static void loadIntoUseTargetDrawable(Activity activity, final String imageUrl, SimpleTarget<Drawable> simpleTarget) {
        if (TextUtils.isEmpty(imageUrl)) {
            return;
        }
        GlideApp.with(activity)
                .load(imageUrl)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(simpleTarget);
    }

    public static void clearImageView(Fragment fragment, ImageView imageView) {
        GlideApp.with(fragment).clear(imageView);
    }

    public static void clearImageView(ImageView imageView) {
        GlideApp.with(CommonApplicationLikeImpl.getContext()).clear(imageView);
    }

    public static void clearMemoryCache(Context context) {
        GlideApp.get(context.getApplicationContext()).clearMemory();
    }

    /**
     * 需放在子线程中清理，否则可能阻塞主线程
     *
     * @param context
     */
    @WorkerThread
    public static void clearFileCache(Context context) {
        GlideApp.get(context.getApplicationContext()).clearDiskCache();
    }

    public static String getCacheSize(Context context) {
        try {
            if (SDCardTest.sdcardState() == 1) {
                return getExternalCacheSize(context);
            } else {
                return getInternalCacheSize(context);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 需放在子线程中，否则可能阻塞主线程
     * <p>
     * 获取Glide造成的缓存大小
     *
     * @return CacheSize
     */
    @WorkerThread
    public static String getExternalCacheSize(Context context) {
        try {
            return getFormatSize(getFolderSize(new File(context.getApplicationContext().getExternalCacheDir(), Constants.DIRS_PICTURES)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 需放在子线程中，否则可能阻塞主线程
     * <p>
     * 获取Glide造成的缓存大小
     *
     * @return CacheSize
     */
    @WorkerThread
    public static String getInternalCacheSize(Context context) {
        try {
            return getFormatSize(getFolderSize(new File(context.getApplicationContext().getCacheDir(), Constants.DIRS_PICTURES)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 获取指定文件夹内所有文件大小的和
     *
     * @param file file
     * @return size
     * @throws Exception
     */
    private static long getFolderSize(File file) throws Exception {
        long size = 0;
        try {
            if (file == null) {
                return 0;
            }
            File[] fileList = file.listFiles();
            if (fileList != null && fileList.length > 0) {
                for (File aFileList : fileList) {
                    if (aFileList.isDirectory()) {
                        size = size + getFolderSize(aFileList);
                    } else {
                        size = size + aFileList.length();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return size;
    }

    /**
     * 格式化单位
     *
     * @param size size
     * @return size
     */
    private static String getFormatSize(double size) {

        double kiloByte = size / 1024;
        double megaByte = kiloByte / 1024;

        BigDecimal result2 = new BigDecimal(Double.toString(megaByte));
        return result2.setScale(0, BigDecimal.ROUND_HALF_UP).toPlainString() + "M";
    }
}