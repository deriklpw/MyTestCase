package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.DouYinCateBean;
import com.ozmobi.coupons.common.bean.VideoGoodsBean;
import com.ozmobi.coupons.common.data.source.DouQuanDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

public class DouQuanRepository implements DouQuanDataSource {

    private static final String TAG = "DouQuanRepository";

    @Override
    public Disposable getDouYinKindList(@NonNull Consumer<? super DouYinCateBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "getDouYinKindList post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        Observable<DouYinCateBean> observable = ApiFactory.getYjlController().
                getDouYinKindList(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getDouYinGoodsList(int cate, int page, @NonNull Consumer<? super VideoGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("kind", cate);
            params.put("page", page);
            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getDouYinGoodsList post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<VideoGoodsBean> observable = ApiFactory.getYjlController()
                .getDouYinGoodsList(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }
}
