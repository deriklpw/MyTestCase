package com.ozmobi.coupons.common;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;

import com.ozmobi.coupons.base.Constants;
import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.base.utils.NetworkUtil;
import com.ozmobi.coupons.base.utils.SortUtil;
import com.ozmobi.coupons.common.adapter.LoadMoreWrapper;

import java.util.List;

/**
 * 抽象Fragment
 * 用于分页加载数据
 *
 * @param <B> 集合中元素类型
 */
public abstract class AbsMoreFragment<B> extends BaseFragment implements IMoreContract.IMoreView<B>, SwipeRefreshLayout.OnRefreshListener {

    private static final String TAG = "AbsMoreFragment";

    private IMoreContract.AbsMorePresenter mPresenter;

    private SwipeRefreshLayout mRefreshView;

    private boolean isLoading = false;

    private int mMoreGoodsPage = 1;

    private List<B> mListData;

    private LoadMoreWrapper mAdapter;

    private boolean isNoMoreData = false;

    private RecyclerView mRecyclerView;

    private FloatingActionButton mFab;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mPresenter != null) {
            mPresenter.cancel();
        }
        if (mAdapter != null) {
            if (isNoMoreData) {
                mAdapter.setLoadState(LoadMoreWrapper.LOADING_NO_MORE);
            } else {
                mAdapter.setLoadState(LoadMoreWrapper.LOADING_COMPLETE);
            }
        }
    }

    protected void setMoreFragmentViewsAndData(SwipeRefreshLayout swipeRefreshLayout, RecyclerView recyclerView, FloatingActionButton fab,
                                               IMoreContract.AbsMorePresenter presenter, LoadMoreWrapper adapter, List<B> list) {
        mRefreshView = swipeRefreshLayout;
        mRecyclerView = recyclerView;
        mFab = fab;
        mPresenter = presenter;
        mAdapter = adapter;
        mListData = list;

        if (mRefreshView != null) {
            mRefreshView.setOnRefreshListener(this);
        }

        if (mRecyclerView != null) {
            mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                    super.onScrollStateChanged(recyclerView, newState);
                    if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                        RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
                        int currentPosition = -1;
                        if (layoutManager instanceof LinearLayoutManager) {
                            LinearLayoutManager linearLayoutManager = (LinearLayoutManager) layoutManager;
                            currentPosition = linearLayoutManager.findFirstVisibleItemPosition();
                        } else if (layoutManager instanceof StaggeredGridLayoutManager) {
                            StaggeredGridLayoutManager staggeredGridLayoutManager = (StaggeredGridLayoutManager) layoutManager;
                            int[] firstVisiblePositions = staggeredGridLayoutManager.findFirstVisibleItemPositions(new int[staggeredGridLayoutManager.getSpanCount()]);
                            currentPosition = SortUtil.maoPaoSortExt(firstVisiblePositions)[0];
                        }

                        if (mFab != null) {
                            if (currentPosition == 0) {
                                mFab.hide();
                            } else {
                                mFab.show();
                            }
                        }

                        if (!recyclerView.canScrollVertically(1) && !isLoading && !isNoMoreData) {
                            if (mAdapter != null) {
                                mAdapter.setLoadState(LoadMoreWrapper.LOADING);
                            }
                            if (mPresenter != null) {
                                isLoading = true;
                                mPresenter.loadMoreData(mMoreGoodsPage);
                            }
                            LogUtil.d(TAG, "loading more goods, page=" + mMoreGoodsPage);
                        }
                    }
                }
            });
        }

        if (mFab != null) {
            mFab.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    if (mFab != null) {
                        mFab.hide();
                    }
                    if (mRecyclerView != null) {
                        mRecyclerView.scrollToPosition(0);
                    }
                }
            });
        }
    }

    @Override
    public void showData(List<B> list) {
        try {
            isNoMoreData = false;
            mMoreGoodsPage = 1;

            if (mListData != null && mAdapter != null) {
                if (list != null && list.size() > 0) {
                    mListData.clear();
                    mListData.addAll(list);
                    mMoreGoodsPage = 2;

                    if (list.size() < Constants.PAGE_SIZE_LOAD_DEFAULT) {
                        isNoMoreData = true;
                        mAdapter.setLoadState(LoadMoreWrapper.LOADING_NO_MORE);
                    } else {
                        mAdapter.setLoadState(LoadMoreWrapper.LOADING_COMPLETE);
                    }
                } else {
                    //返回空，将显示空布局
                    mListData.clear();
                    isNoMoreData = true;
                    mAdapter.setLoadState(LoadMoreWrapper.LOADING_COMPLETE);
                }
            }

            isLoading = false;
            LogUtil.d(TAG, "showGoods: isNoMoreData=" + isNoMoreData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void showMoreData(List<B> list) {
        try {
            if (list != null && list.size() > 0) {
                if (mListData != null && mAdapter != null) {
                    mListData.addAll(list);
                    mAdapter.setLoadState(LoadMoreWrapper.LOADING_COMPLETE);
                    mMoreGoodsPage++;
                }
            } else {
                isNoMoreData = true;
                if (mRecyclerView != null && !mRecyclerView.canScrollVertically(1) && mAdapter != null) {
                    mAdapter.setLoadState(LoadMoreWrapper.LOADING_NO_MORE);
                }
            }

            isLoading = false;
            LogUtil.d(TAG, "showMoreGoods: isNoMoreData=" + isNoMoreData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void showGetDataError() {
        try {
            if (NetworkUtil.isNetworkAvailable()) {
                toastGetDataFail();
                if (mAdapter != null) {
                    mAdapter.setLoadState(LoadMoreWrapper.LOADING_COMPLETE);
                }
            } else {
                if (mListData != null && mListData.size() > 0) {
                    if (mAdapter != null) {
                        mAdapter.setLoadState(LoadMoreWrapper.LOADING_COMPLETE);
                    }
                    toastNetError();
                } else {
                    if (mAdapter != null) {
                        mAdapter.setNetError();
                    }
                }
            }
            isLoading = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void showError() {
        super.showError();
        if (mAdapter != null) {
            mAdapter.setLoadState(LoadMoreWrapper.LOADING_COMPLETE);
        }
        isLoading = false;
    }

    @Override
    public void showLoading() {
        super.showLoading();
        isLoading = true;
    }

    @Override
    public void hideLoading() {
        super.hideLoading();
        isLoading = false;
    }

    @Override
    public void setRefresh(boolean enable) {
        if (mRefreshView != null) {
            mRefreshView.setRefreshing(enable);
            isLoading = enable;
        }
    }

    @Override
    public void onRefresh() {
        if (mPresenter != null) {
            if (isLoading) {
                if (mRefreshView != null) {
                    mRefreshView.setRefreshing(false);
                }
                return;
            }
            isLoading = true;
            isNoMoreData = false;
            mMoreGoodsPage = 1;
            mPresenter.loadData(mMoreGoodsPage);
        }
    }

    @Override
    public boolean isActive() {
        return isAdded();
    }

    public int getCurrentGoodsPage() {
        return mMoreGoodsPage;
    }

    public void setCurrentGoodsPage(int page) {
        mMoreGoodsPage = page;
    }

    public void resetIsNoMore() {
        isNoMoreData = false;
    }

    public boolean isNoMoreData() {
        return isNoMoreData;
    }
}
