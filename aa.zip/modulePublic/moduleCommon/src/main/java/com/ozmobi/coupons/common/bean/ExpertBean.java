package com.ozmobi.coupons.common.bean;

import java.util.List;

public class ExpertBean {
    private int error;
    private String msg;
    private DataBean data;
    private int time;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public static class DataBean {
        private List<TopdataBean> topdata;
        private List<NewdataBean> newdata;
        private List<ClickdataBean> clickdata;
        private List<CategoryBean> category;

        public List<TopdataBean> getTopdata() {
            return topdata;
        }

        public void setTopdata(List<TopdataBean> topdata) {
            this.topdata = topdata;
        }

        public List<NewdataBean> getNewdata() {
            return newdata;
        }

        public void setNewdata(List<NewdataBean> newdata) {
            this.newdata = newdata;
        }

        public List<ClickdataBean> getClickdata() {
            return clickdata;
        }

        public void setClickdata(List<ClickdataBean> clickdata) {
            this.clickdata = clickdata;
        }

        public List<CategoryBean> getCategory() {
            return category;
        }

        public void setCategory(List<CategoryBean> category) {
            this.category = category;
        }

        public static class TopdataBean {
            private String title;
            private String image;
            private CommonPromoteBean action;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }

            public CommonPromoteBean getAction() {
                return action;
            }

            public void setAction(CommonPromoteBean action) {
                this.action = action;
            }

        }

        public static class NewdataBean {
            private String title;
            private String image;
            private String talent_name;
            private String head_img;
            private CommonPromoteBean action;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }

            public String getTalent_name() {
                return talent_name;
            }

            public void setTalent_name(String talent_name) {
                this.talent_name = talent_name;
            }

            public String getHead_img() {
                return head_img;
            }

            public void setHead_img(String head_img) {
                this.head_img = head_img;
            }

            public CommonPromoteBean getAction() {
                return action;
            }

            public void setAction(CommonPromoteBean action) {
                this.action = action;
            }
        }

        public static class ClickdataBean {
            private String title;
            private String image;
            private String talent_category;
            private String itemnum;
            private String article;
            private CommonPromoteBean action;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }

            public String getTalent_category() {
                return talent_category;
            }

            public void setTalent_category(String talent_category) {
                this.talent_category = talent_category;
            }

            public String getItemnum() {
                return itemnum;
            }

            public void setItemnum(String itemnum) {
                this.itemnum = itemnum;
            }

            public String getArticle() {
                return article;
            }

            public void setArticle(String article) {
                this.article = article;
            }

            public CommonPromoteBean getAction() {
                return action;
            }

            public void setAction(CommonPromoteBean action) {
                this.action = action;
            }
        }

        public static class CategoryBean {
            private int id;
            private String name;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }
        }
    }
}
