package com.ozmobi.coupons.common.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;


public class CustomLevelView extends View {
    private static final String TAG = "CustomLevelView";

    private int mColorBg = Color.parseColor("#353535");

    public enum PartnerLevel {
        PARTNER,
        SUPER_PARTNER,
        FOREVER_PARTNER
    }

    private Paint mPaint;

    private PartnerLevel mLevel;

    public CustomLevelView(Context context) {
        this(context, null);
    }

    public CustomLevelView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CustomLevelView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initPaint();
    }

    public void setLevel(PartnerLevel partnerLevel) {
        mLevel = partnerLevel;
        invalidate();
    }

    private void initPaint() {
        mPaint = new Paint();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getMeasuredWidth();
        int height = getMeasuredHeight();

        float leftRingRadius = height * (7 / 12.0f) / 2;
        float middleRingRadius = height * (9 / 12.0f) / 2;
        float rightRingRadius = height * (10 / 12.0f) / 2;
        float stroke = height * (1 / 12.0f);

        float leftCircleRadius = height * (4 / 12.0f) / 2;
        float middleCircleRadius = height * (6 / 12.0f) / 2;
        float rightCircleRadius = height * (7 / 12.0f) / 2;

        float rectTop = height * (5 / 12.0f);
        float rectBottom = height * (7 / 12.0f);

        mPaint.setColor(mColorBg);
        mPaint.setAntiAlias(true);

        canvas.drawRect(leftRingRadius, rectTop, width - rightRingRadius, rectBottom, mPaint);

        mPaint.setColor(Color.WHITE);
        mPaint.setStrokeWidth(stroke);
        mPaint.setStyle(Paint.Style.STROKE);

        if (mLevel == PartnerLevel.PARTNER) {
            canvas.drawCircle(leftRingRadius + stroke, height / 2, leftRingRadius, mPaint);
            mPaint.setStyle(Paint.Style.FILL);
        } else if (mLevel == PartnerLevel.SUPER_PARTNER) {
            canvas.drawCircle(width / 2, height / 2, middleRingRadius, mPaint);
            mPaint.setStyle(Paint.Style.FILL);
            canvas.drawRect(leftRingRadius, rectTop, width / 2, rectBottom, mPaint);
        } else if (mLevel == PartnerLevel.FOREVER_PARTNER) {
            canvas.drawCircle(width - rightRingRadius - stroke, height / 2, rightRingRadius, mPaint);
            mPaint.setStyle(Paint.Style.FILL);
            canvas.drawRect(leftRingRadius + stroke, rectTop, width - rightRingRadius, rectBottom, mPaint);
        }

        canvas.drawCircle(leftCircleRadius + (leftRingRadius - leftCircleRadius) + stroke, height / 2, leftCircleRadius, mPaint);
        canvas.drawCircle(width / 2, height / 2, middleCircleRadius, mPaint);
        canvas.drawCircle(width - rightCircleRadius - (rightRingRadius - rightCircleRadius) - stroke, height / 2, rightCircleRadius, mPaint);
    }
}
