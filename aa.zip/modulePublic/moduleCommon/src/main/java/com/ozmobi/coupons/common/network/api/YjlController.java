package com.ozmobi.coupons.common.network.api;


import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.common.bean.CateBannerBean;
import com.ozmobi.coupons.common.bean.NavCateDetailBean;
import com.ozmobi.coupons.common.bean.PunchRecordResultBean;
import com.ozmobi.coupons.common.bean.PunchRecordDetailBean;
import com.ozmobi.coupons.common.bean.BrandBean;
import com.ozmobi.coupons.common.bean.CommunityKindBean;
import com.ozmobi.coupons.common.bean.ContactQrBean;
import com.ozmobi.coupons.common.bean.DouYinCateBean;
import com.ozmobi.coupons.common.bean.ExchangeGoodsBean;
import com.ozmobi.coupons.common.bean.ExchangeRecordBean;
import com.ozmobi.coupons.common.bean.FansFilterBean;
import com.ozmobi.coupons.common.bean.FansRankBean;
import com.ozmobi.coupons.common.bean.IntegralCenterBean;
import com.ozmobi.coupons.common.bean.IntegralDetailBean;
import com.ozmobi.coupons.common.bean.PunchIntegralBean;
import com.ozmobi.coupons.common.bean.SignInResultBean;
import com.ozmobi.coupons.common.bean.SmsDetailBean;
import com.ozmobi.coupons.common.bean.StatusFansBean;
import com.ozmobi.coupons.common.bean.GoodsDetailsPageBean;
import com.ozmobi.coupons.common.bean.CategoryBean;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.bean.CouponsGoodsBean;
import com.ozmobi.coupons.common.bean.FavoriteGoodsBean;
import com.ozmobi.coupons.common.bean.FavoriteListBean;
import com.ozmobi.coupons.common.bean.FeedbackBean;
import com.ozmobi.coupons.common.bean.IncomeBean;
import com.ozmobi.coupons.common.bean.IncomeDetailBean;
import com.ozmobi.coupons.common.bean.IndirectDirectFansBean;
import com.ozmobi.coupons.common.bean.MyFansBean;
import com.ozmobi.coupons.common.bean.PresentIncomeBean;
import com.ozmobi.coupons.common.bean.QueryStateBean;
import com.ozmobi.coupons.common.bean.QuerySugBean;
import com.ozmobi.coupons.common.bean.RecommendLimitHomeBean;
import com.ozmobi.coupons.common.bean.RecommendNavBean;
import com.ozmobi.coupons.common.bean.RecordBean;
import com.ozmobi.coupons.common.bean.SearchFansBean;
import com.ozmobi.coupons.common.bean.ShareTextBean;
import com.ozmobi.coupons.common.bean.TKLBean;
import com.ozmobi.coupons.common.bean.TodayOrdersBean;
import com.ozmobi.coupons.common.bean.UpdateBean;
import com.ozmobi.coupons.common.bean.VideoGoodsBean;
import com.ozmobi.coupons.common.bean.WakeupFansBean;

import io.reactivex.Observable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.Url;

public interface YjlController {

    // 分类
    @POST("api.php?m=product&p=cates")
    Observable<CategoryBean> getCategory(@Body RequestBody body);

    // Banner(兼容旧版)、促销图（兼容旧版）、热门搜索词、导航商品类别
    @POST("api.php?m=product&p=index")
    Observable<RecommendNavBean> getRecommendNav(@Body RequestBody body);

    // 促销商品
    @POST("api.php?m=product&p=promotion")
    Observable<CommonGoodsBean> getPromotionGoods(@Body RequestBody body);

    // 限时抢购
    @POST("api.php?m=product&p=flash")
    Observable<RecommendLimitHomeBean> getRecommendLimitHomeGoods(@Body RequestBody body);

    // 今日热卖榜
    @POST("api.php?m=product&p=todayhot")
    Observable<CommonGoodsBean> getRecommendHotHomeGoods(@Body RequestBody body);

    // 9.9包邮专区
    @POST("api.php?m=product&p=special")
    Observable<CommonGoodsBean> getRecommendNinePointHomeGoods(@Body RequestBody body);

    // 精选好物
    @POST("api.php?m=product&p=recommend")
    Observable<CommonGoodsBean> getRecommendChoiceHomeGoods(@Body RequestBody body);

    // 一级类别，热卖商品
    @POST("api.php?m=product&p=hot")
    Observable<CommonGoodsBean> getOtherCategoryHotGoods(@Body RequestBody body);

    // 一级类别，一般商品
    @POST("api.php?m=product&p=catrecommend")
    Observable<CommonGoodsBean> getOtherCategoryGoods(@Body RequestBody body);

    // 搜索商品
    // 一级，二级商品，均可通过类别名搜索
    @POST("api.php?m=product&p=search")
    Observable<CommonGoodsBean> getQueryGoods(@Body RequestBody body);

    @GET("https://suggest.taobao.com/sug")
    Observable<QuerySugBean> getQueryHint(@Query("q") String query, @Query("code") String code);

    // 优选商品
    @POST("api.php?m=product&p=guesslike")
    Observable<CommonGoodsBean> getGuessLikeGoods(@Body RequestBody body);

    // 用户反馈
    @POST("api.php?m=user&p=feed")
    Observable<FeedbackBean> feedbackContent(@Body RequestBody body);

    //添加收藏
    @POST("api.php?m=user&p=collect")
    Observable<JSONObject> addFavoriteGoods(@Body RequestBody body);

    //删除收藏
    @POST("api.php?m=user&p=delcollect")
    Observable<JSONObject> deleteFavoriteGoods(@Body RequestBody body);

    //查询收藏的商品列表
    @POST("api.php?m=user&p=mycollect")
    Observable<FavoriteGoodsBean> queryFavoriteGoods(@Body RequestBody body);

    //查询某个商品的收藏状态
    @POST("api.php?m=product&p=collectstate")
    Observable<QueryStateBean> queryCollectStateGoods(@Body RequestBody body);

    //添加我的优惠券
    @POST("api.php?m=user&p=coupon")
    Observable<JSONObject> addCouponsGoods(@Body RequestBody body);

    //删除我的优惠券
    @POST("api.php?m=user&p=delcoupon")
    Observable<JSONObject> deleteCouponsGoods(@Body RequestBody body);

    //查询我的优惠券列表
    @POST("api.php?m=user&p=mycoupon")
    Observable<CouponsGoodsBean> queryCouponsGoods(@Body RequestBody body);

    //获取淘口令
    @POST("api.php?m=user&p=tkl")
    Observable<TKLBean> getTKL(@Body RequestBody body);

    //首次安装时，偏好设置
    @POST("api.php?m=user&p=favoritelist")
    Observable<FavoriteListBean> requestFavoriteList(@Body RequestBody body);

    //首页推荐，今日优选
    @POST("api.php?m=product&p=todayoptimal")
    Observable<CommonGoodsBean> requestTodayOptimal(@Body RequestBody body);

    //首页类别中的新版banner，(推荐，第一个banner，第二个文字banner，第三个促销banner)
    //title=空时，默认为推荐banner，title=类别名（适用所有类别），为类别名banner
    @POST("api.php?m=product&p=banner")
    Observable<CateBannerBean> requestBannerUrls(@Body RequestBody body);

    //我的粉丝，旧粉丝接口
//    @POST("api.php?m=user&p=myfans")
//    Observable<FansBean> getMyFans(@Body RequestBody body);

    //我的收益
    @POST("api.php?m=user&p=myincome")
    Observable<IncomeBean> getMyIncome(@Body RequestBody body);

    //我的收益明细
    @POST("api.php?m=user&p=incomedetail")
    Observable<IncomeDetailBean> getMyIncomeDetail(@Body RequestBody body);

    //绑定支付宝
    @POST("api.php?m=user&p=bindalipay")
    Observable<JSONObject> bindAlipayAccount(@Body RequestBody body);

    //提现
    @POST("api.php?m=user&p=withdraw")
    Observable<JSONObject> withdraw(@Body RequestBody body);

    //提现详情
    @POST("api.php?m=user&p=withdrawrecord")
    Observable<RecordBean> withdrawRecord(@Body RequestBody body);

    //粉丝邀请页
    @POST("api.php?m=user&p=invitefans")
    Observable<JSONObject> getMyInvitePages(@Body RequestBody body);

    //绑定订单
    @POST("api.php?m=user&p=bindorder")
    Observable<JSONObject> bindOrders(@Body RequestBody body);

    //我的订单记录
    @POST("api.php?m=user&p=myorders")
    Observable<JSONObject> queryMyOrders(@Body RequestBody body);

    //用户信息，展示用户信息时请求
    @POST("api.php?m=user&p=userinfo")
    Observable<JSONObject> queryUserInfo(@Body RequestBody body);

    //系统开关
    @POST("api.php?m=system&p=open")
    Observable<JSONObject> querySystemSwitch(@Body RequestBody body);

    //商务合作
    @POST("api.php?m=user&p=businesscooperate")
    Observable<JSONObject> submitBusiness(@Body RequestBody body);

//    //商品详情
//    @GET("api.php?m=product&p=productdetail&num_iid={num_iid}&plat_type={plat_type}")
//    Observable<JSONObject> queryGoodsById(@Path("num_iid") String num_iid, @Path("plat_type") String platType);

    //商品详情
    @POST("api.php?m=product&p=productdetail")
    Observable<GoodsDetailsPageBean> getGoodsDetails(@Body RequestBody body);

    //相关推荐商品
    @POST("api.php?m=product&p=relaterecommend")
    Observable<CommonGoodsBean> getRelatedGoods(@Body RequestBody body);

    //店铺优惠券商品
    @POST("api.php?m=product&p=getshopcoupon")
    Observable<CommonGoodsBean> getShopCouponsGoods(@Body RequestBody body);

    //社区分组
    @POST("api.php?m=comm&p=commkind")
    Observable<CommunityKindBean> getCommunityKind(@Body RequestBody body);

    //获取社区内容
    @POST("api.php?m=comm&p=commlist")
    Observable<JSONObject> getCommunity(@Body RequestBody body);

    //社区分享时，统计调用
    @POST("api.php?m=comm&p=addsharenum")
    Observable<JSONObject> shareCommunityContent(@Body RequestBody body);

    //品牌闪购
    @POST("api.php?m=product&p=brand")
    Observable<BrandBean> getBrandGoods(@Body RequestBody body);

    //参数指定url，活动专区，动态返回
    @POST
    Observable<CommonGoodsBean> getUrlListGoods(@Url String url, @Body RequestBody body);

    //用户收益汇总
    @POST("api.php?m=user&p=incomestat")
    Observable<PresentIncomeBean> getUserPresentIncome(@Body RequestBody body);

    //获取客服微信信息
    @POST("api.php?m=system&p=service")
    Observable<ContactQrBean> getCustomerWeChatInfo(@Body RequestBody body);

    //获取商品分享的文案
    @POST("api.php?m=product&p=sharedetail")
    Observable<ShareTextBean> getShareText(@Body RequestBody body);

    //更多品牌商品
    @POST("api.php?m=product&p=brandproducts")
    Observable<CommonGoodsBean> getBrandDetailGoods(@Body RequestBody body);

    //版本检测
    @POST("api.php?m=system&p=ver")
    Observable<UpdateBean> checkUpdate(@Body RequestBody body);

    //我的粉丝
    @POST("api.php?m=fans&p=fansdetail")
    Observable<MyFansBean> getMyFans(@Body RequestBody body);

    //粉丝贡献排行
    @POST("api.php?m=fans&p=earnrank")
    Observable<FansRankBean> getFansRank(@Body RequestBody body);

    //出单/未出单，七天登录/未登录粉丝列表
    @POST("api.php?m=fans&p=fanslist")
    Observable<StatusFansBean> getFansStatusList(@Body RequestBody body);

    //搜索粉丝
    @POST("api.php?m=fans&p=searchfans")
    Observable<SearchFansBean> searchFans(@Body RequestBody body);

    //获取直接粉丝或者间接粉丝数据
    @POST("api.php?m=fans&p=myfans")
    Observable<IndirectDirectFansBean> getMyFansDetail(@Body RequestBody body);

    //粉丝的今日订单
    @POST("api.php?m=fans&p=todayorders")
    Observable<TodayOrdersBean> getFansTodayOrders(@Body RequestBody body);

    //通过商品Id，获取商品详细信息
    @POST("api.php?m=product&p=getproduct")
    Observable<JSONObject> getGoodsWithId(@Body RequestBody body);

    //唤醒粉丝
    @POST("api.php?m=fans&p=wakenfans")
    Observable<WakeupFansBean> wakeupFans(@Body RequestBody body);

    //粉丝刷选
    @POST("api.php?m=fans&p=fansfilter")
    Observable<FansFilterBean> getFansWithFilter(@Body RequestBody body);

    //短信余额明细
    @POST("api.php?m=fans&p=smsmoneydetail")
    Observable<SmsDetailBean> getSmsMoneyDetail(@Body RequestBody body);

    //首页弹窗
    @POST("api.php?m=product&p=dialog")
    Observable<JSONObject> getWelcomeDialogInfo(@Body RequestBody body);

    //获取抖音类别列表
    @POST("api.php?m=douyin&p=douyinkind")
    Observable<DouYinCateBean> getDouYinKindList(@Body RequestBody body);

    //获取抖音商品列表
    @POST("api.php?m=douyin&p=douyinlist")
    Observable<VideoGoodsBean> getDouYinGoodsList(@Body RequestBody body);

    //积分中心首页
    @POST("api.php?m=integral&p=center")
    Observable<IntegralCenterBean> getIntegralCenterData(@Body RequestBody body);

    //积分明细
    @POST("api.php?m=integral&p=integraldetail")
    Observable<IntegralDetailBean> getIntegralDetail(@Body RequestBody body);

    //积分商品
    @POST("api.php?m=integral&p=product")
    Observable<ExchangeGoodsBean> getExchangeGoodsDetail(@Body RequestBody body);

    //积分商品兑换
    @POST("api.php?m=integral&p=exchange")
    Observable<JSONObject> exchangeGoods(@Body RequestBody body);

    //积分兑换记录
    @POST("api.php?m=integral&p=exchangedetail")
    Observable<ExchangeRecordBean> getExchangeRecord(@Body RequestBody body);

    //签到
    @POST("api.php?m=integral&p=checkin")
    Observable<SignInResultBean> signInNow(@Body RequestBody body);

    //每日打卡积分
    @POST("api.php?m=integral&p=clockintegral")
    Observable<PunchIntegralBean> getPunchIntegral(@Body RequestBody body);

    //打卡报名
    @POST("api.php?m=integral&p=clockinapply")
    Observable<PunchIntegralBean> applyPunch(@Body RequestBody body);

    //打卡
    @POST("api.php?m=integral&p=clockin")
    Observable<PunchIntegralBean> punchNow(@Body RequestBody body);

    //打卡记录，我的战绩
    @POST("api.php?m=integral&p=clockinrecord")
    Observable<PunchRecordResultBean> getPunchRecordMyResult(@Body RequestBody body);

    //打卡记录，活动明细
    @POST("api.php?m=integral&p=clockindetail")
    Observable<PunchRecordDetailBean> getPunchRecordDetail(@Body RequestBody body);

    //首页Nav中的详细页
    @POST("api.php?m=product&p=homecate")
    Observable<NavCateDetailBean> getHomeCateDetail(@Body RequestBody body);

    //首页Nav中的详细页，推荐数据
    @POST("api.php?m=product&p=homesubcate")
    Observable<CommonGoodsBean> getHomeCateDetailRecommend(@Body RequestBody body);

    //达人说
    @POST("api.php?m=comm&p=darenshuo")
    Observable<CommonGoodsBean> getExpertData(@Body RequestBody body);
}
