package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.ozmobi.coupons.common.bean.CateBannerBean;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public interface OtherCategoryDataSource extends BaseDataSource {

    Disposable getOtherCategoryHotGoods(@NonNull String categoryName, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getOtherCategoryGoods(@NonNull String categoryName, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable requestOtherBannerData(@NonNull String subCate, @NonNull Consumer<? super CateBannerBean> success, @NonNull Consumer<? super Throwable> error);
}
