package com.ozmobi.coupons.common.ui.goodsdetails.shop;

import com.alibaba.fastjson.JSON;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.data.source.remote.GoodsDataRepository;

/**
 * Created by xhkj on 2019/6/15.
 */

public class ShopCouponsPresenter extends ShopCouponsContract.Presenter {

    private static final String TAG = "ShopCouponsPresenter";

    private String mShopName;

    ShopCouponsPresenter(String shopName) {
        super(new GoodsDataRepository());
        mShopName = shopName;
    }

    @Override
    public void start() {
        if (getBaseView() != null) {
            getBaseView().showLoading();
        }
        getShopCouponsGoods();
    }

    @Override
    public void getShopCouponsGoods() {
        if (getBaseRepository() == null) {
            if (getBaseView() != null && getBaseView().isLoading()) {
                getBaseView().hideLoading();
            }
            return;
        }
        addOperatorDisposable(getBaseRepository().getShopCouponsGoods(mShopName, commonGoodsBean -> {
            LogUtil.d(TAG, "getShopCouponsGoods: " + JSON.toJSONString(commonGoodsBean));
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
                getBaseView().setShopCouponsGoods(commonGoodsBean);
            }

        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
                getBaseView().showError();
            }
        }));
    }
}
