package com.ozmobi.coupons.common;


/**
 * Created by xhkj on 2019/9/21.
 */

import com.ozmobi.coupons.common.data.source.BaseDataSource;

import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

/**
 * 实现部分公共属性和方法
 * @param <V> View UI范型
 * @param <R> Repository 数据仓库范型
 */
public abstract class AbsBasePresenter<V extends BaseView, R extends BaseDataSource> implements BasePresenter<V> {
    //view
    private V mBaseView;

    //data
    private R mBaseRepository;

    //操作管理
    private CompositeDisposable mCompositeDisposable = new CompositeDisposable();

    public AbsBasePresenter(R r) {
        mBaseRepository = r;
    }

    @Override
    public void attach(V baseView) {
        mBaseView = baseView;
    }

    @Override
    public void cancel() {
        if (mBaseView != null && mBaseView.isLoading()) {
            mBaseView.hideLoading();
        }
        if (mCompositeDisposable != null) {
            mCompositeDisposable.clear();
        }
    }

    protected V getBaseView() {
        return mBaseView;
    }

    protected R getBaseRepository() {
        return mBaseRepository;
    }

    protected void addOperatorDisposable(Disposable disposable) {
        mCompositeDisposable.add(disposable);
    }

    @Override
    public void detach() {
        mBaseView = null;
    }

    @Override
    public void destroy() {
        cancel();
        detach();
        mCompositeDisposable = null;
        mBaseRepository = null;
    }
}
