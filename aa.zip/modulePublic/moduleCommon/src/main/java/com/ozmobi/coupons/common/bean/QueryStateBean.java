package com.ozmobi.coupons.common.bean;

/**
 * Created by xhkj on 2019/3/26.
 */

public class QueryStateBean {

    /**
     * msg :
     * data : {"collect":"0"}
     * time : 1553655743
     * error : 0
     */
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        /**
         * collect : 0
         */
        private String collect;

        public void setCollect(String collect) {
            this.collect = collect;
        }

        public String getCollect() {
            return collect;
        }
    }
}
