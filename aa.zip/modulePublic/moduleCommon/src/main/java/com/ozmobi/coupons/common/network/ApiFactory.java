package com.ozmobi.coupons.common.network;

import com.ozmobi.coupons.common.network.api.AccountController;
import com.ozmobi.coupons.common.network.api.YjlController;

public class ApiFactory {

    private static YjlController yjlController;

    private static AccountController accountController;

    public static YjlController getYjlController() {
        if (yjlController == null) {
            synchronized (ApiFactory.class) {
                if (yjlController == null) {
                    yjlController = RetrofitManager.getInstance().create(YjlController.class);
                }
            }
        }

        return yjlController;
    }

    public static AccountController getAccountController() {
        if (accountController == null) {
            synchronized (ApiFactory.class) {
                if (accountController == null) {
                    accountController = RetrofitManager.getInstance().create(AccountController.class);
                }
            }
        }

        return accountController;
    }

    public static void destroy() {
        yjlController = null;
        accountController = null;
    }

}
