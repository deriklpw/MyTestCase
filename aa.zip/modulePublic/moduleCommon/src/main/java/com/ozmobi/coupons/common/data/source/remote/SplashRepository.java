package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;

import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.FavoriteListBean;
import com.ozmobi.coupons.common.data.source.SplashDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

/**
 * Created by xhkj on 2019/5/10.
 */

public class SplashRepository implements SplashDataSource {

    private static final String TAG = "SplashRepository";

    @Override
    public Disposable requestFavoriteList(@NonNull Consumer<? super FavoriteListBean> success, @NonNull Consumer<? super Throwable> error) {

        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "favorite post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<FavoriteListBean> observable = ApiFactory.getYjlController().requestFavoriteList(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }
}
