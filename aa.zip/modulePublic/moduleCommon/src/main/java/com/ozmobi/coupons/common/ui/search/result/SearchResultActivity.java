package com.ozmobi.coupons.common.ui.search.result;


import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;

import com.ozmobi.coupons.common.BaseActivity;
import com.ozmobi.coupons.common.IMoreContract;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.ui.search.branddetail.BrandDetailPresenter;
import com.ozmobi.coupons.common.ui.search.otherhotdetail.OtherHotDetailPresenter;
import com.ozmobi.coupons.common.ui.search.urlgoods.UrlGoodsPresenter;
import com.ozmobi.coupons.common.utils.ActivityUtils;

public class SearchResultActivity extends BaseActivity {

    private static final String EXTRA_KEY_TARGET = "key_target";

    private static final String EXTRA_KEY_TITLE = "key_title";

    private static final String EXTRA_KEY_PARAMS = "key_params";

    private static final String TARGET_VALUE_SEARCH_RESULT = "target_value_search_result";

    private static final String TARGET_VALUE_BRAND_DETAIL = "target_value_brand_detail";

    private static final String TARGET_VALUE_URL_GOODS = "target_value_url_goods";

    private static final String TARGET_VALUE_OTHER_CATEGORY_HOT = "target_value_other_category_hot";

    @Override
    protected int getLayoutId() {
        return R.layout.common_activity_search_result;
    }

    @Override
    protected void initViews() {
        String target = getIntent().getStringExtra(EXTRA_KEY_TARGET);
        String title = getIntent().getStringExtra(EXTRA_KEY_TITLE);
        String params = getIntent().getStringExtra(EXTRA_KEY_PARAMS);
        setToolbarTitle(title);

        SearchResultFragment searchResultFragment = SearchResultFragment.newInstance(params);
        IMoreContract.AbsMorePresenter absMorePresenter = null;
        switch (target) {
            case TARGET_VALUE_SEARCH_RESULT:
                absMorePresenter = new SearchResultPresenter(searchResultFragment, params);
                break;
            case TARGET_VALUE_BRAND_DETAIL:
                absMorePresenter = new BrandDetailPresenter(searchResultFragment, params);
                break;
            case TARGET_VALUE_URL_GOODS:
                absMorePresenter = new UrlGoodsPresenter(searchResultFragment, params);
                break;
            case TARGET_VALUE_OTHER_CATEGORY_HOT:
                absMorePresenter = new OtherHotDetailPresenter(searchResultFragment, params);
            default:
                break;
        }
        if (absMorePresenter != null) {
            ActivityUtils.addFragmentToActivity(getSupportFragmentManager(), searchResultFragment, R.id.fl_search_result_container);
        }
    }

    private static void startWithParams(Context context, String target, String title, String params) {
        if (context != null && !TextUtils.isEmpty(params)) {
            Intent intent = new Intent(context, SearchResultActivity.class);
            intent.putExtra(EXTRA_KEY_TARGET, target);
            intent.putExtra(EXTRA_KEY_TITLE, title);
            intent.putExtra(EXTRA_KEY_PARAMS, params);
            context.startActivity(intent);
        }
    }

    public static void startForSearchResult(Context context, String searchName) {
        startWithParams(context, TARGET_VALUE_SEARCH_RESULT, searchName, searchName);
    }

    public static void startForBrandDetails(Context context, String title, String brandId) {
        startWithParams(context, TARGET_VALUE_BRAND_DETAIL, title, brandId);
    }

    public static void startActivityForUrlGoods(Context context, String title, String url) {
        startWithParams(context, TARGET_VALUE_URL_GOODS, title, url);
    }

    public static void startActivityForOtherCategoryHotGoods(Context context, String title, String categoryName) {
        startWithParams(context, TARGET_VALUE_OTHER_CATEGORY_HOT, title, categoryName);
    }

}
