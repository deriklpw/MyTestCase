package com.ozmobi.coupons.common.module;

import android.content.Context;
import android.support.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.Registry;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.load.engine.cache.ExternalPreferredCacheDiskCacheFactory;
import com.bumptech.glide.load.engine.cache.InternalCacheDiskCacheFactory;
import com.bumptech.glide.load.engine.cache.LruResourceCache;
import com.bumptech.glide.module.AppGlideModule;
import com.bumptech.glide.request.RequestOptions;
import com.ozmobi.coupons.base.Constants;
import com.ozmobi.coupons.base.utils.SDCardTest;

/**
 * Created by xhkj on 2019/3/16.
 */

@GlideModule
public class CouponGlideModule extends AppGlideModule {

    @Override
    public void registerComponents(@NonNull Context context, @NonNull Glide glide, @NonNull Registry registry) {
        super.registerComponents(context, glide, registry);
        // 替换底层网络框架为okhttp3，这步很重要！
        // 如果您的app中已经存在了自定义的GlideModule，您只需要把这一行代码，添加到对应的重载方法中即可。
//        registry.replace(GlideUrl.class, InputStream.class, new OkHttpUrlLoader.Factory(ProgressManager.getOkHttpClient()));
    }

    @Override
    public void applyOptions(@NonNull Context context, @NonNull GlideBuilder builder) {
        int maxMemory = (int) Runtime.getRuntime().maxMemory(); //获取系统分配给应用的总内存大小
        int memoryCacheSize = maxMemory / 12;//设置图片内存缓存占用十二分之一
        // 设置内存缓存大小
        builder.setMemoryCache(new LruResourceCache(memoryCacheSize));

        // 根据SD卡是否可用选择是在内部缓存还是SD卡缓存
        if (SDCardTest.sdcardState() == 1) {
            int diskCacheSize = 1024 * 1024 * 300; //最多可以缓存300M的数据
            builder.setDiskCache(new ExternalPreferredCacheDiskCacheFactory(context, Constants.DIRS_PICTURES, diskCacheSize));
        } else {
            int diskCacheSize = 1024 * 1024 * 50; //最多可以缓存50M的数据
            builder.setDiskCache(new InternalCacheDiskCacheFactory(context, Constants.DIRS_PICTURES, diskCacheSize));
        }

        builder.setDefaultRequestOptions(RequestOptions.fitCenterTransform());

    }

    @Override
    public boolean isManifestParsingEnabled() {
        return false;
    }
}
