package com.ozmobi.coupons.common.data.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 一级和二级类目，可序列化Bean
 * Created by xhkj on 2019/7/13.
 */

public class CategoryParcelableBean implements Parcelable {
    private String title;
    private String image;
    private String keyWords = "";

    public CategoryParcelableBean(String title, String image) {
        this.title = title;
        this.image = image;
    }

    public CategoryParcelableBean(String title, String image, String keyWords) {
        this.title = title;
        this.image = image;
        this.keyWords = keyWords;
    }

    protected CategoryParcelableBean(Parcel in) {
        title = in.readString();
        image = in.readString();
        keyWords = in.readString();
    }

    public static final Creator<CategoryParcelableBean> CREATOR = new Creator<CategoryParcelableBean>() {
        @Override
        public CategoryParcelableBean createFromParcel(Parcel in) {
            return new CategoryParcelableBean(in);
        }

        @Override
        public CategoryParcelableBean[] newArray(int size) {
            return new CategoryParcelableBean[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setKeyWords(String keyWords) {
        this.keyWords = keyWords;
    }

    public String getKeyWords() {
        return keyWords;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(image);
        dest.writeString(keyWords);
    }
}
