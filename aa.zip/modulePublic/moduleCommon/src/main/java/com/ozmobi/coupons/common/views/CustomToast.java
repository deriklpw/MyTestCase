package com.ozmobi.coupons.common.views;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.ozmobi.coupons.common.R;

/**
 * Created by xhkj on 2019/3/26.
 */

public class CustomToast {

    private ImageView mIcon;
    private TextView mMsg;

    private Context mContext;
    private Toast mToast;

    public CustomToast(Context context) {
        mContext = context.getApplicationContext();
    }

    public void showCancel() {
        if (mToast != null) {
            mToast.cancel();
            mToast = null;
        }
        mToast = Toast.makeText(mContext, R.string.common_add_favorite, Toast.LENGTH_SHORT);
        mToast.setGravity(Gravity.CENTER, 0, 0);

        View view = View.inflate(mContext, R.layout.common_toast_custom_collection, null);
        mIcon = view.findViewById(R.id.toast_custom_collection_icon);
        mMsg = view.findViewById(R.id.toast_custom_collection_msg);
        mToast.setView(view);

        mIcon.setImageResource(R.drawable.common_icon_unselected);
        mMsg.setText(mContext.getResources().getString(R.string.common_delete_favorite));
        mToast.show();
    }

    public void showAddSuccess() {
        if (mToast != null) {
            mToast.cancel();
            mToast = null;
        }
        mToast = Toast.makeText(mContext, R.string.common_add_favorite, Toast.LENGTH_SHORT);
        mToast.setGravity(Gravity.CENTER, 0, 0);

        View view = View.inflate(mContext, R.layout.common_toast_custom_collection, null);
        mIcon = view.findViewById(R.id.toast_custom_collection_icon);
        mMsg = view.findViewById(R.id.toast_custom_collection_msg);
        mToast.setView(view);

        mIcon.setImageResource(R.drawable.common_icon_selected);
        mMsg.setText(mContext.getResources().getString(R.string.common_add_favorite));
        mToast.show();
    }

    public void destroy() {
        if (mToast != null) {
            mToast.cancel();
        }
        mToast = null;
        mContext = null;
        mIcon = null;
        mMsg = null;
    }
}
