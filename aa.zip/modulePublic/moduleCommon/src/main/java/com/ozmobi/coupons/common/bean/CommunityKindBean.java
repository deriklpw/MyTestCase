package com.ozmobi.coupons.common.bean;

import java.util.List;


public class CommunityKindBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {

        private List<KindlistEntity> kindlist;

        public void setKindlist(List<KindlistEntity> kindlist) {
            this.kindlist = kindlist;
        }


        public List<KindlistEntity> getKindlist() {
            return kindlist;
        }

        public class KindlistEntity {

            private String kind;
            private String title;

            public void setKind(String kind) {
                this.kind = kind;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getKind() {
                return kind;
            }

            public String getTitle() {
                return title;
            }
        }
    }
}
