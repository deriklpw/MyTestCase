package com.ozmobi.coupons.common.ui.qrcode;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.AppBarLayout;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.ozmobi.coupons.common.BaseActivity;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.base.utils.SDCardTest;
import com.ozmobi.coupons.common.utils.GetPathFromUri;
import com.ozmobi.coupons.common.utils.QRCodeDecoder;
import com.uuzuche.lib_zxing.activity.CaptureFragment;
import com.uuzuche.lib_zxing.activity.CodeUtils;

import java.io.File;

import io.reactivex.Observable;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class QrCodeActivity extends BaseActivity {
    private static final String TAG = "QrCodeActivity";
    private static final int REQUEST_CODE_SELECT_PICTURE = 0x001;

    private boolean mLight;

    private Disposable mDisposable;

    @Override
    protected int getLayoutId() {
        return R.layout.common_activity_qr_code;
    }

    @Override
    protected void initViews() {
        AppBarLayout appBarLayout = findViewById(R.id.appbar);
        Toolbar toolbar = findViewById(R.id.toolbar);
        TextView title = findViewById(R.id.tv_toolbar_title);
        setAppBarAndToolbar(appBarLayout, toolbar, title);
        setStatusToolbarWhite(true);

        setToolbarTitle(getString(R.string.common_scan_qr));

        TextView tvAlbum = findViewById(R.id.tv_qr_code_album);
        TextView tvFlash = findViewById(R.id.tv_qr_code_flash);

        /**
         * 执行扫面Fragment的初始化操作
         */
        CaptureFragment captureFragment = new CaptureFragment();
        // 为二维码扫描界面设置定制化界面
        CodeUtils.setFragmentArgs(captureFragment, R.layout.common_layout_qr_code_camera);

        captureFragment.setAnalyzeCallback(analyzeCallback);
        /**
         * 替换我们的扫描控件
         */
        getSupportFragmentManager().beginTransaction().replace(R.id.fl_qr_code_my_container, captureFragment).commit();

        tvAlbum.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                if (SDCardTest.sdcardState() == 1) {
                    Intent intent;
                    if (Build.VERSION.SDK_INT < 19) {
                        intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("image/*");
                    } else {
                        intent = new Intent(Intent.ACTION_PICK,
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    }
                    startActivityForResult(intent, REQUEST_CODE_SELECT_PICTURE);
                } else {
                    toastMsg(getString(R.string.common_sdcard_no_exist));
                }
            }
        });

        mLight = false;
        tvFlash.setOnClickListener(v -> {
            mLight = !mLight;
            CodeUtils.isLightEnable(mLight);
        });

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    CodeUtils.AnalyzeCallback analyzeCallback = new CodeUtils.AnalyzeCallback() {
        @Override
        public void onAnalyzeSuccess(Bitmap mBitmap, String result) {
            Intent resultIntent = new Intent();
            Bundle bundle = new Bundle();
            bundle.putInt(CodeUtils.RESULT_TYPE, CodeUtils.RESULT_SUCCESS);
            bundle.putString(CodeUtils.RESULT_STRING, result);
            resultIntent.putExtras(bundle);
            QrCodeActivity.this.setResult(RESULT_OK, resultIntent);
            QrCodeActivity.this.finish();
        }

        @Override
        public void onAnalyzeFailed() {
            Intent resultIntent = new Intent();
            Bundle bundle = new Bundle();
            bundle.putInt(CodeUtils.RESULT_TYPE, CodeUtils.RESULT_FAILED);
            bundle.putString(CodeUtils.RESULT_STRING, "");
            resultIntent.putExtras(bundle);
            QrCodeActivity.this.setResult(RESULT_OK, resultIntent);
            QrCodeActivity.this.finish();
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //识别相册二维码结果
        if (requestCode == REQUEST_CODE_SELECT_PICTURE) {
            if (data != null) {
                Uri uri = data.getData();
                if (uri != null) {
                    String path = GetPathFromUri.getInstance().getPath(QrCodeActivity.this, uri);

                    if (!TextUtils.isEmpty(path)) {
                        File file = new File(path);
                        if (file.isFile()) {
                            mDisposable = Observable.create((ObservableOnSubscribe<String>) emitter -> {
                                String result = QRCodeDecoder.syncDecodeQRCode(BitmapFactory.decodeFile(path));
                                if (result != null) {
                                    emitter.onNext(result);
                                }
                            }).subscribeOn(Schedulers.newThread())
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(s -> {
                                        if (!TextUtils.isEmpty(s)) {
                                            Intent intent = new Intent();
                                            intent.putExtra(CodeUtils.RESULT_TYPE, CodeUtils.RESULT_SUCCESS);
                                            intent.putExtra(CodeUtils.RESULT_STRING, s);
                                            setResult(Activity.RESULT_OK, intent);
                                        }
                                        finish();
                                    });

                        }
                    }
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mDisposable != null && !mDisposable.isDisposed()) {
            mDisposable.dispose();
        }
        mDisposable = null;
    }

}
