package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.common.bean.CommunityKindBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public interface CommunityDataSource extends BaseDataSource {

    /**
     * 获取社区内容
     *
     * @param success
     * @param error
     * @return
     */
    Disposable getCommunityKind(@NonNull Consumer<? super CommunityKindBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取社区内容
     *
     * @param kind
     * @param success
     * @param error
     * @return
     */
    Disposable getCommunity(@NonNull String kind, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 分享社区内容
     * @param id
     * @param success
     * @param error
     * @return
     */
    Disposable shareCommunityContent(@NonNull String id, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);
}
