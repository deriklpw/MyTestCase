package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.BrandBean;
import com.ozmobi.coupons.common.bean.CateBannerBean;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.bean.NavCateDetailBean;
import com.ozmobi.coupons.common.bean.RecommendLimitHomeBean;
import com.ozmobi.coupons.common.bean.RecommendNavBean;
import com.ozmobi.coupons.common.data.source.RecommendDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;


public class RecommendRepository implements RecommendDataSource {
    private static final String TAG = "RecommendRepository";

    @Override
    public Disposable getRecommendNavData(@NonNull Consumer<? super RecommendNavBean> success, @NonNull Consumer<? super Throwable> error) {

        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "Banner post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        return ApiFactory.getYjlController().getRecommendNav(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable getRecommendPromotionGoods(int pageSize, int page, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "Promotion post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().getPromotionGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable getRecommendLimitHomeGoods(int pageSize, int page, @Nullable String start, @NonNull Consumer<? super RecommendLimitHomeBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            if (!TextUtils.isEmpty(start)) {
                params.put("start", start);
            }
            params.put("pagesize", pageSize);
            params.put("page", page);
            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "Limit post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        return ApiFactory.getYjlController().getRecommendLimitHomeGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable getRecommendHotHomeGoods(int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            if (!TextUtils.isEmpty(sort)) {
                params.put("sort", sort);
            }
            params.put("pagesize", pageSize);
            params.put("page", page);
            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "Hot post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        return ApiFactory.getYjlController().getRecommendHotHomeGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable getRecommendNinePointHomeGoods(int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            if (!TextUtils.isEmpty(sort)) {
                params.put("sort", sort);
            }
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "Nine post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        return ApiFactory.getYjlController().getRecommendNinePointHomeGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable getRecommendChoiceHomeGoods(int pageSize, int page, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "Choice post json=" + json);
        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        return ApiFactory.getYjlController().getRecommendChoiceHomeGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable requestRecommendBannerData(@NonNull Consumer<? super CateBannerBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            //传人title为空，代表请求首页推荐的Banner
            params.put("title", "");
            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "recommend banner post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<CateBannerBean> observable = ApiFactory.getYjlController().requestBannerUrls(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable requestTodayOptimalGoods(@NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "today optimal post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        Observable<CommonGoodsBean> observable = ApiFactory.getYjlController().requestTodayOptimal(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getBrandGoods(@NonNull Consumer<? super BrandBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "get brands post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        Observable<BrandBean> observable = ApiFactory.getYjlController().getBrandGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getBrandDetailGoods(@NonNull String brandId, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("brand_id", brandId);

            if (!TextUtils.isEmpty(sort)) {
                params.put("sort", sort);
            }
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getBrandDetailGoods post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<CommonGoodsBean> observable = ApiFactory.getYjlController().getBrandDetailGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getHomeCateDetail(@NonNull String id, String title, String cate, @NonNull Consumer<? super NavCateDetailBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("id", id);
            params.put("title", title);
            params.put("cate", cate);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getHomeCateDetail post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<NavCateDetailBean> observable = ApiFactory.getYjlController().getHomeCateDetail(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getHomeCateDetailRecommend(@NonNull String id, String title, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("id", id);
            params.put("title", title);

            if (!TextUtils.isEmpty(sort)) {
                params.put("sort", sort);
            }
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getHomeCateDetailRecommend post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<CommonGoodsBean> observable = ApiFactory.getYjlController().getHomeCateDetailRecommend(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }
}
