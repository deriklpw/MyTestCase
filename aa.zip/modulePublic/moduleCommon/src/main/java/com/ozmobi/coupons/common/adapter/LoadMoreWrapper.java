package com.ozmobi.coupons.common.adapter;

import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.R;

/**
 * 可设置：头布局
 * 支持脚部：加载更多，加载完成，加载到底
 * <p>
 * 头布局，点击事件在onCreateView中实现时，需要在响应事件处，position-1。若在onBindViewHolder设置点击事件，则不需要减1(在此类中已处理)
 * 脚布局，无需其他操作
 * Created by xhkj on 2019/4/2.
 */

public class LoadMoreWrapper extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final String TAG = "LoadMoreWrapper";

    private static final int VIEW_TYPE_HEADER = 0x10000003; //头布局

    private static final int VIEW_TYPE_FOOTER = 0x10000004; //脚布局

    //当前加载状态，默认为加载完成
    private int loadState = 2;
    //正在加载
    public static final int LOADING = 1;
    //加载完成
    public static final int LOADING_COMPLETE = 2;
    //加载到底
    public static final int LOADING_NO_MORE = 3;

    //适配器
    private RecyclerView.Adapter mAdapter;

    @LayoutRes
    private int mHeaderLayout = -1;

    public LoadMoreWrapper(RecyclerView.Adapter adapter) {
        mAdapter = adapter;
    }

    public void setHeaderLayout(@LayoutRes int resId) {
        mHeaderLayout = resId;
    }

    //分布局
    @Override
    public int getItemViewType(int position) {
        if (position == 0 && mHeaderLayout != -1) {
            return VIEW_TYPE_HEADER;
        }

        if (position + 1 == getItemCount()) {
            return VIEW_TYPE_FOOTER;
        } else {
            return mAdapter.getItemViewType(position); //返回position，方便被装饰对象添加不同的ViewType，如果设置了Header，则被装饰对象viewType不能使用0
        }
    }

    @Override
    @NonNull
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //进行判断显示类型，来创建还回不同的View
        if (viewType == VIEW_TYPE_FOOTER) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.common_layout_load_footer, parent, false);
            //还回脚布局
            return new FootViewHolder(view);
        } else if (viewType == VIEW_TYPE_HEADER) {
            View view = LayoutInflater.from(parent.getContext()).inflate(mHeaderLayout, parent, false);
            return new HeaderViewHolder(view);
        } else {
            //还回内容的布局
            return mAdapter.onCreateViewHolder(parent, viewType);
        }
    }


    //绑定数据
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof FootViewHolder) {
            FootViewHolder footViewHolder = (FootViewHolder) holder;
            switch (loadState) {
                //表示正在加载
                case LOADING:
                    LogUtil.d(TAG, "onBindViewHolder: loading");
                    if (footViewHolder.loading.getVisibility() != View.VISIBLE) {
                        footViewHolder.loading.setVisibility(View.VISIBLE);
                    }
                    if (footViewHolder.loadNoMore.getVisibility() == View.VISIBLE) {
                        footViewHolder.loadNoMore.setVisibility(View.GONE);
                    }
                    break;

                //表示加载完成
                case LOADING_COMPLETE:
                    LogUtil.d(TAG, "onBindViewHolder: complete");
                    if (footViewHolder.loading.getVisibility() == View.VISIBLE) {
                        footViewHolder.loading.setVisibility(View.GONE);
                    }
                    if (footViewHolder.loadNoMore.getVisibility() == View.VISIBLE) {
                        footViewHolder.loadNoMore.setVisibility(View.GONE);
                    }
                    break;

                //表示加载到底
                case LOADING_NO_MORE:
                    LogUtil.d(TAG, "onBindViewHolder: end");
                    if (footViewHolder.loading.getVisibility() == View.VISIBLE) {
                        footViewHolder.loading.setVisibility(View.GONE);
                    }
                    if (footViewHolder.loadNoMore.getVisibility() != View.VISIBLE) {
                        footViewHolder.loadNoMore.setVisibility(View.VISIBLE);
                    }
                    break;
                default:
                    break;
            }
        } else if (holder instanceof HeaderViewHolder) {
            //头布局，显示即可，无需数据绑定
            LogUtil.d(TAG, "onBindViewHolder: HeaderViewHolder");
        } else {
            if (mHeaderLayout == -1) {
                mAdapter.onBindViewHolder(holder, position);
            } else {
                //如果有头布局，需要给被装饰的adapter，索引减1
                mAdapter.onBindViewHolder(holder, position - 1);
            }
        }

    }

    //总的条目数量
    @Override
    public int getItemCount() {
        if (mHeaderLayout == -1) {
            return mAdapter != null ? mAdapter.getItemCount() > 0 ? mAdapter.getItemCount() + 1 : 0 : 0;
        } else {
            return mAdapter != null ? mAdapter.getItemCount() > 0 ? mAdapter.getItemCount() + 2 : 0 : 0;
        }

    }

    @Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        LogUtil.d(TAG, "onAttachedToRecyclerView: ");
        RecyclerView.LayoutManager manager = recyclerView.getLayoutManager();
        if (manager instanceof GridLayoutManager) {
            final GridLayoutManager gridLayoutManager = (GridLayoutManager) manager;
            gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override
                public int getSpanSize(int position) {
                    //如果是脚布局或者头布局,返回合并的列数，否则返回1，表示不合并
                    if (getItemViewType(position) == VIEW_TYPE_FOOTER ||
                            getItemViewType(position) == VIEW_TYPE_HEADER ||
                            getItemViewType(position) == CustomBaseAdapter.VIEW_TYPE_EMPTY ||
                            getItemViewType(position) == CustomBaseAdapter.VIEW_TYPE_ERROR) {
                        return gridLayoutManager.getSpanCount();
                    } else {
                        return 1;
                    }
                }
            });
        }
    }

    // 解决StaggeredGridLayoutManager占满一行
    @Override
    public void onViewAttachedToWindow(@NonNull RecyclerView.ViewHolder holder) {
        super.onViewAttachedToWindow(holder);
        int index = holder.getLayoutPosition();
        if (getItemViewType(index) == VIEW_TYPE_FOOTER ||
                getItemViewType(index) == VIEW_TYPE_HEADER ||
                getItemViewType(index) == CustomBaseAdapter.VIEW_TYPE_EMPTY ||
                getItemViewType(index) == CustomBaseAdapter.VIEW_TYPE_ERROR) {
            ViewGroup.LayoutParams lp = holder.itemView.getLayoutParams();
            if (lp != null && lp instanceof StaggeredGridLayoutManager.LayoutParams) {
                StaggeredGridLayoutManager.LayoutParams p =
                        (StaggeredGridLayoutManager.LayoutParams) lp;
                p.setFullSpan(true);
            }
        }
    }

    //头布局
    private class HeaderViewHolder extends RecyclerView.ViewHolder {
        public HeaderViewHolder(View itemView) {
            super(itemView);
        }

    }

    //脚布局
    private class FootViewHolder extends RecyclerView.ViewHolder {
        private ViewGroup loading;

        private AppCompatTextView loadNoMore;

        public FootViewHolder(View itemView) {
            super(itemView);
            loading = itemView.findViewById(R.id.ll_load_more_container);
            loadNoMore = itemView.findViewById(R.id.tv_load_no_more_data);
        }

    }

    public void setLoadState(int loadState) {
        if (mAdapter != null && (mAdapter instanceof CustomBaseAdapter)) {
            ((CustomBaseAdapter) mAdapter).updateDataChanged();
        }
        this.loadState = loadState;
        this.notifyDataSetChanged();
    }

    public void setNetError() {
        if (mAdapter != null && (mAdapter instanceof CustomBaseAdapter)) {
            ((CustomBaseAdapter) mAdapter).updateNetError();
        }
        this.loadState = LOADING_COMPLETE;
        this.notifyDataSetChanged();
    }

    public void clearImageViews() {
        if (mAdapter != null && (mAdapter instanceof CustomBaseAdapter)) {
            ((CustomBaseAdapter) mAdapter).clearImageViews();
        }
    }
}
