package com.ozmobi.coupons.common.bean;

public class IncomeBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private IncomeEntity income;

        public void setIncome(IncomeEntity income) {
            this.income = income;
        }

        public IncomeEntity getIncome() {
            return income;
        }

        public class IncomeEntity {
            private String last_month_estimated_income;
            private String today_estimated_income;
            private String money;
            private String today_payment_number;
            private String this_month_estimated_income;
            private String yesterday_payment_number;
            private String settlement_income;
            private String yesterday_estimated_income;
            private String last_month_settlement_income;

            public void setLast_month_estimated_income(String last_month_estimated_income) {
                this.last_month_estimated_income = last_month_estimated_income;
            }

            public void setToday_estimated_income(String today_estimated_income) {
                this.today_estimated_income = today_estimated_income;
            }

            public void setMoney(String money) {
                this.money = money;
            }

            public void setToday_payment_number(String today_payment_number) {
                this.today_payment_number = today_payment_number;
            }

            public void setThis_month_estimated_income(String this_month_estimated_income) {
                this.this_month_estimated_income = this_month_estimated_income;
            }

            public void setYesterday_payment_number(String yesterday_payment_number) {
                this.yesterday_payment_number = yesterday_payment_number;
            }

            public void setSettlement_income(String settlement_income) {
                this.settlement_income = settlement_income;
            }

            public void setYesterday_estimated_income(String yesterday_estimated_income) {
                this.yesterday_estimated_income = yesterday_estimated_income;
            }

            public void setLast_month_settlement_income(String last_month_settlement_income) {
                this.last_month_settlement_income = last_month_settlement_income;
            }

            public String getLast_month_estimated_income() {
                return last_month_estimated_income;
            }

            public String getToday_estimated_income() {
                return today_estimated_income;
            }

            public String getMoney() {
                return money;
            }

            public String getToday_payment_number() {
                return today_payment_number;
            }

            public String getThis_month_estimated_income() {
                return this_month_estimated_income;
            }

            public String getYesterday_payment_number() {
                return yesterday_payment_number;
            }

            public String getSettlement_income() {
                return settlement_income;
            }

            public String getYesterday_estimated_income() {
                return yesterday_estimated_income;
            }

            public String getLast_month_settlement_income() {
                return last_month_settlement_income;
            }
        }
    }
}
