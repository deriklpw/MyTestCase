package com.ozmobi.coupons.common.ui.imageviewer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.ozmobi.coupons.common.BaseFragment;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.module.GlideApp;
import com.ozmobi.coupons.common.utils.GlideUtils;
import com.ozmobi.coupons.base.listener.OnSingleClickListener;

public class PictureViewerFragment extends BaseFragment {

    private static final String ARG_IMAGE_PATH = "arg_image_path";

    private static final String ARG_IMAGE_URL = "arg_image_url";

    private String mImagePath;

    private String mImageUrl;

    private ClickCallback mClickCallback;

    public PictureViewerFragment() {
        // Required empty public constructor
    }

    public static PictureViewerFragment newInstance(String imagePath, String imageUrl) {
        PictureViewerFragment fragment = new PictureViewerFragment();
        Bundle args = new Bundle();
        args.putString(ARG_IMAGE_PATH, imagePath);
        args.putString(ARG_IMAGE_URL, imageUrl);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.common_fragment_picture_viewer;
    }

    @Override
    protected void initViews() {
        ImageView imageView = findView(R.id.iv_picture);
        try {
            if (!TextUtils.isEmpty(mImagePath)) {
                Bitmap srcBitmap = BitmapFactory.decodeFile(mImagePath);
                imageView.setImageBitmap(srcBitmap);
            } else if (!TextUtils.isEmpty(mImageUrl)) {
                imageView.setImageResource(R.mipmap.common_ic_image_place_holder_middle);
                imageView.post(new Runnable() {
                    @Override
                    public void run() {
                        if (PictureViewerFragment.this.isDetached()) {
                            return;
                        }
                        GlideUtils.loadIntoUseTarget(PictureViewerFragment.this, mImageUrl, new SimpleTarget<Drawable>() {
                            @Override
                            public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                                int imageWidth = resource.getIntrinsicWidth();
                                int imageHeight = resource.getIntrinsicHeight();

                                int height = imageView.getWidth() * imageHeight / imageWidth;
                                ViewGroup.LayoutParams para = imageView.getLayoutParams();
                                if (para != null) {
                                    para.height = height;
                                    imageView.setLayoutParams(para);
                                }
                                GlideApp.with(PictureViewerFragment.this)
                                        .load(mImageUrl)
                                        .into(imageView);
                            }
                        });
                    }
                });
            }

            imageView.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    if (mClickCallback != null) {
                        mClickCallback.onImageClicked(v);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void lazyFetchData() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mImagePath = getArguments().getString(ARG_IMAGE_PATH);
            mImageUrl = getArguments().getString(ARG_IMAGE_URL);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClickCallback) {
            mClickCallback = (ClickCallback) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mClickCallback = null;
    }

    public interface ClickCallback {
        void onImageClicked(View v);
    }
}
