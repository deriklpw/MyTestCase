package com.ozmobi.coupons.common.bean;

import com.ozmobi.coupons.common.utils.StringConverterForGreenDao;

import org.greenrobot.greendao.annotation.Convert;
import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;

import java.io.Serializable;
import java.util.List;

/**
 * 序列化，及存储数据库时使用
 */
@Entity(
        nameInDb = "history_goods"
)
public class GoodsBean implements Serializable {

    static final long serialVersionUID = -15515456L;

//    @Id(autoincrement = true)
//    private Long id;

    @Id
    private long goodsId;

    //商品详情链接
    private String goodsUrl;

    //商品图片
    private String iconUrl;

    //商品名
    private String title;

    //商品优惠券，券值
    private String couponValue;

    //商品现价
    private String currentPrice;

    //商品原价
    private String originPrice;

    //商品优惠券链接
    private String couponUrl;

    //商品折扣率
    private double discountRate;

    //商品活动结束时间
    private String endTime;

    //优惠券信息
    private String couponInfo;

    //商品销量
    private int goodsVolume;

    //优惠券结束时间
    private String couponEndTime;

    //商品总量
    private int totalAmount;

    //没用到
    private String reservePrice;

    //优惠券开始时间
    private String couponStartTime;

    //店铺名
    private String shopTitle;

    //开始时间
    private String startTime;

    //平台类型
    private String platType;

    //优惠率
    private double couponRate;

    //产品链接，短链
    private String productUrl;

    //店铺分
    private double shopScore;

    //下单返率
    private double commissionRate;

    //下单返现
    private String commissionFee;

    //分享链接
    private String share;

    //升级赚
    private String upCommissionFee;

    //分享赚
    private String shareFree;

    //商品详情图组
    @Convert(columnType = String.class, converter = StringConverterForGreenDao.class)
    private List<String> smallImages;

    //商品浏览时间戳
    private long browserTime;

    @Generated(hash = 602916650)
    public GoodsBean(long goodsId, String goodsUrl, String iconUrl, String title,
            String couponValue, String currentPrice, String originPrice, String couponUrl,
            double discountRate, String endTime, String couponInfo, int goodsVolume,
            String couponEndTime, int totalAmount, String reservePrice,
            String couponStartTime, String shopTitle, String startTime, String platType,
            double couponRate, String productUrl, double shopScore, double commissionRate,
            String commissionFee, String share, String upCommissionFee, String shareFree,
            List<String> smallImages, long browserTime) {
        this.goodsId = goodsId;
        this.goodsUrl = goodsUrl;
        this.iconUrl = iconUrl;
        this.title = title;
        this.couponValue = couponValue;
        this.currentPrice = currentPrice;
        this.originPrice = originPrice;
        this.couponUrl = couponUrl;
        this.discountRate = discountRate;
        this.endTime = endTime;
        this.couponInfo = couponInfo;
        this.goodsVolume = goodsVolume;
        this.couponEndTime = couponEndTime;
        this.totalAmount = totalAmount;
        this.reservePrice = reservePrice;
        this.couponStartTime = couponStartTime;
        this.shopTitle = shopTitle;
        this.startTime = startTime;
        this.platType = platType;
        this.couponRate = couponRate;
        this.productUrl = productUrl;
        this.shopScore = shopScore;
        this.commissionRate = commissionRate;
        this.commissionFee = commissionFee;
        this.share = share;
        this.upCommissionFee = upCommissionFee;
        this.shareFree = shareFree;
        this.smallImages = smallImages;
        this.browserTime = browserTime;
    }

    @Generated(hash = 1806305570)
    public GoodsBean() {
    }

    public long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(long goodsId) {
        this.goodsId = goodsId;
    }

    public String getGoodsUrl() {
        return goodsUrl;
    }

    public void setGoodsUrl(String goodsUrl) {
        this.goodsUrl = goodsUrl;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCouponValue() {
        return couponValue;
    }

    public void setCouponValue(String couponValue) {
        this.couponValue = couponValue;
    }

    public String getCurrentPrice() {
        return currentPrice;
    }

    public void setCurrentPrice(String currentPrice) {
        this.currentPrice = currentPrice;
    }

    public String getOriginPrice() {
        return originPrice;
    }

    public void setOriginPrice(String originPrice) {
        this.originPrice = originPrice;
    }

    public String getCouponUrl() {
        return couponUrl;
    }

    public void setCouponUrl(String couponUrl) {
        this.couponUrl = couponUrl;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getCouponInfo() {
        return couponInfo;
    }

    public void setCouponInfo(String couponInfo) {
        this.couponInfo = couponInfo;
    }

    public int getGoodsVolume() {
        return goodsVolume;
    }

    public void setGoodsVolume(int goodsVolume) {
        this.goodsVolume = goodsVolume;
    }

    public String getCouponEndTime() {
        return couponEndTime;
    }

    public void setCouponEndTime(String couponEndTime) {
        this.couponEndTime = couponEndTime;
    }

    public long getBrowserTime() {
        return browserTime;
    }

    public void setBrowserTime(long browserTime) {
        this.browserTime = browserTime;
    }

    public int getTotalAmount() {
        return this.totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getReservePrice() {
        return this.reservePrice;
    }

    public void setReservePrice(String reservePrice) {
        this.reservePrice = reservePrice;
    }

    public String getCouponStartTime() {
        return this.couponStartTime;
    }

    public void setCouponStartTime(String couponStartTime) {
        this.couponStartTime = couponStartTime;
    }

    public String getShopTitle() {
        return this.shopTitle;
    }

    public void setShopTitle(String shopTitle) {
        this.shopTitle = shopTitle;
    }

    public String getStartTime() {
        return this.startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getPlatType() {
        return this.platType;
    }

    public void setPlatType(String platType) {
        this.platType = platType;
    }

    public double getCouponRate() {
        return this.couponRate;
    }

    public void setCouponRate(double couponRate) {
        this.couponRate = couponRate;
    }

    public String getProductUrl() {
        return this.productUrl;
    }

    public void setProductUrl(String productUrl) {
        this.productUrl = productUrl;
    }

    public double getShopScore() {
        return this.shopScore;
    }

    public void setShopScore(double shopScore) {
        this.shopScore = shopScore;
    }

    public List<String> getSmallImages() {
        return this.smallImages;
    }

    public void setSmallImages(List<String> smallImages) {
        this.smallImages = smallImages;
    }

    public String getShareFree() {
        return this.shareFree;
    }

    public void setShareFree(String shareFree) {
        this.shareFree = shareFree;
    }

    public double getCommissionRate() {
        return this.commissionRate;
    }

    public void setCommissionRate(double commissionRate) {
        this.commissionRate = commissionRate;
    }

    public String getCommissionFee() {
        return this.commissionFee;
    }

    public void setCommissionFee(String commissionFee) {
        this.commissionFee = commissionFee;
    }

    public String getShare() {
        return this.share;
    }

    public void setShare(String share) {
        this.share = share;
    }

    public String getUpCommissionFee() {
        return this.upCommissionFee;
    }

    public void setUpCommissionFee(String upCommissionFee) {
        this.upCommissionFee = upCommissionFee;
    }

}
