package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.FansFilterBean;
import com.ozmobi.coupons.common.bean.IndirectDirectFansBean;
import com.ozmobi.coupons.common.bean.MyFansBean;
import com.ozmobi.coupons.common.bean.FansRankBean;
import com.ozmobi.coupons.common.bean.SearchFansBean;
import com.ozmobi.coupons.common.bean.SmsDetailBean;
import com.ozmobi.coupons.common.bean.StatusFansBean;
import com.ozmobi.coupons.common.bean.TodayOrdersBean;
import com.ozmobi.coupons.common.bean.WakeupFansBean;
import com.ozmobi.coupons.common.data.source.FansDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

public class FansRepository implements FansDataSource {
    private static final String TAG = "FansRepository";

    @Override
    public Disposable getMyFans(@NonNull Consumer<? super MyFansBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "getMyFans post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<MyFansBean> observable = ApiFactory.getYjlController()
                .getMyFans(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getMyFansDetail(int level, int pageSize, int page, @NonNull Consumer<? super IndirectDirectFansBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("level", level);
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getMyfansDetail post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<IndirectDirectFansBean> observable = ApiFactory.getYjlController()
                .getMyFansDetail(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getFansRank(int level, int pageSize, int page, @NonNull Consumer<? super FansRankBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("level", level);
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getFansRank post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<FansRankBean> observable = ApiFactory.getYjlController()
                .getFansRank(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getStatusFansList(int level, int status, int pageSize, int page, @NonNull Consumer<? super StatusFansBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("level", level);
            params.put("type", status);
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getStatusFansList post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<StatusFansBean> observable = ApiFactory.getYjlController()
                .getFansStatusList(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable searchFans(String keyword, @NonNull Consumer<? super SearchFansBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("keyword", keyword);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "searchFans post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<SearchFansBean> observable = ApiFactory.getYjlController()
                .searchFans(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getTodayOrders(int level, int pageSize, int page, @NonNull Consumer<? super TodayOrdersBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("level", level);
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getVideos post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<TodayOrdersBean> observable = ApiFactory.getYjlController()
                .getFansTodayOrders(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable wakeupFans(@NonNull Consumer<? super WakeupFansBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "wakeupFans post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<WakeupFansBean> observable = ApiFactory.getYjlController()
                .wakeupFans(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getFansWithFilter(String day, String type, @NonNull Consumer<? super FansFilterBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());

            if (!TextUtils.isEmpty(day) || !TextUtils.isEmpty(type)) {
                JSONObject params = new JSONObject();

                if (!TextUtils.isEmpty(day)) {
                    params.put("day", day);
                }
                if (!TextUtils.isEmpty(type)) {
                    params.put("type", type);
                }
                rootJson.put("param", params);
            }

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getVideos post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<FansFilterBean> observable = ApiFactory.getYjlController()
                .getFansWithFilter(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable sendSmsToWakeupFans(JSONArray uIds, String smsId, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());

            JSONObject params = new JSONObject();

            params.put("fans_uid", uIds);
            params.put("id", smsId);

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "sendSmsToWakeupFans post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController()
                .sendSmsToWakeupFans(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getSmsMoneyDetail(int pageSize, int page, @NonNull Consumer<? super SmsDetailBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getSmsMoneyDetail post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<SmsDetailBean> observable = ApiFactory.getYjlController()
                .getSmsMoneyDetail(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable topUpBalance(String money, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("sms_money", money);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "topupBalance post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController()
                .topUpBalance(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable withdrawSmsMoney(String money, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("sms_money", money);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "withdrawSmsMoney post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController()
                .withdrawSmsMoney(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable topUpBalanceWithAlipay(String money, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("total_amount", money);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "topUpBalanceWithAlipay post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController()
                .topUpBalanceWithAlipay(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }
}
