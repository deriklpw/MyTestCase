package com.ozmobi.coupons.common.bean;

/**
 * Created by xhkj on 2019/3/26.
 */

public class TKLBean {

    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private String tkl;

        public void setTkl(String tkl) {
            this.tkl = tkl;
        }

        public String getTkl() {
            return tkl;
        }
    }
}
