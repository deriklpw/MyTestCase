package com.ozmobi.coupons.common.utils;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class GridItemDivider extends RecyclerView.ItemDecoration {
    private static final String TAG = "GridItemDivider";

    private int mDividerWidth;

    private int mFirstRowWidth;

    private int mLastRowWidth;

    private int mLeftRightWidth;

    private boolean isFirstRowTopEnable = true;

    private boolean isLastRowBottomEnable = true;

    private boolean isLeftEnable = true;

    private boolean isRightEnable = true;

    private Paint mPaint;

    private RecyclerView.LayoutManager mLayoutManager;

    public GridItemDivider(int dividerWidth, int color) {
        mPaint = new Paint();
        mPaint.setColor(color);

        setDividerWidth(dividerWidth);
    }

    public void setDividerWidth(int dividerWidth) {
        this.mDividerWidth = dividerWidth;
        this.mLeftRightWidth = dividerWidth;
        this.mFirstRowWidth = dividerWidth;
        this.mLastRowWidth = dividerWidth;
    }

    public void setDividersEnable(boolean left, boolean firstRow, boolean right, boolean lastRow) {
        this.isLeftEnable = left;
        this.isFirstRowTopEnable = firstRow;
        this.isRightEnable = right;
        this.isLastRowBottomEnable = lastRow;
    }

    public void setDividersWidth(int firstRowWidth, int lastRowWidth, int leftRightWidth) {
        this.mFirstRowWidth = firstRowWidth;
        this.mLastRowWidth = lastRowWidth;
        this.mLeftRightWidth = leftRightWidth;
    }

    @Override
    public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        if (mLayoutManager == null) {
            mLayoutManager = parent.getLayoutManager();
        }

        int itemPosition = parent.getChildLayoutPosition(view);
        int childCount = parent.getAdapter().getItemCount();

        if (mLayoutManager instanceof GridLayoutManager) {
            GridLayoutManager gridLayoutManager = (GridLayoutManager) mLayoutManager;
            if (gridLayoutManager.getOrientation() == GridLayoutManager.VERTICAL) {
                setGridVerticalRect(outRect, itemPosition, childCount);
            }
        }

    }

    private void setGridVerticalRect(@NonNull Rect outRect, int itemPosition, int childCount) {
        int left = 0;
        int top = 0;
        int right = 0;
        int bottom = mDividerWidth;

        int eachWidth = mDividerWidth / 2;

        //竖直方向
        if (isRowItemFirst(itemPosition) && isRowItemLast(itemPosition)) {
            //特殊情况，只有一个item
            if (isLeftEnable) {
                left = mLeftRightWidth;
            }
            if (isRightEnable) {
                right = mLeftRightWidth;
            }
        } else if (isRowItemFirst(itemPosition)) {
            if (isLeftEnable) {
                left = mLeftRightWidth;
            }
            right = eachWidth;
        } else if (isRowItemLast(itemPosition)) {
            left = eachWidth;
            if (isRightEnable) {
                right = mLeftRightWidth;
            }
        } else {
            left = eachWidth;
            right = eachWidth;
        }

        //水平方向
        if (isFirstRow(itemPosition)) {
            if (isFirstRowTopEnable) {
                top = mFirstRowWidth;
            }
        }

        if (isLastRow(itemPosition, childCount)) {
            if (isLastRowBottomEnable) {
                bottom = mLastRowWidth;
            } else {
                bottom = 0;
            }
            //一行未显示全，最后一个特殊处理
//            if (isNounAndLastItem(itemPosition, childCount)) {
//                right = mDividerWidth;
//            }
        }

        outRect.set(left, top, right, bottom);
    }

    @Override
    public void onDraw(@NonNull Canvas canvas, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        super.onDraw(canvas, parent, state);
        if (mLayoutManager instanceof GridLayoutManager) {
            GridLayoutManager gridLayoutManager = (GridLayoutManager) mLayoutManager;
            if (gridLayoutManager.getOrientation() == GridLayoutManager.VERTICAL) {
                drawGridVertical(canvas, parent);
            }
        }
    }

    private void drawGridVertical(Canvas canvas, RecyclerView parent) {
        int childCount = parent.getChildCount();
        int left;
        int top;
        int right;
        int bottom;
        int eachWidth = mDividerWidth / 2;

        for (int i = 0; i < childCount; i++) {
            View view = parent.getChildAt(i);

            //竖直方向
            if (isRowItemFirst(i) && isRowItemLast(i)) {
                //特殊情况，只有一个item
                if (isLeftEnable) {
                    left = view.getLeft() - mLeftRightWidth;
                } else {
                    left = view.getLeft();
                }
                if (isRightEnable) {
                    right = view.getRight() + mLeftRightWidth;
                } else {
                    right = view.getRight();
                }
            } else if (isRowItemFirst(i)) {
                if (isLeftEnable) {
                    left = view.getLeft() - mLeftRightWidth;
                } else {
                    left = view.getLeft();
                }
                right = view.getRight() + eachWidth;
            } else if (isRowItemLast(i)) {
                left = view.getLeft() - eachWidth;
                if (isRightEnable) {
                    right = view.getRight() + mLeftRightWidth;
                } else {
                    right = view.getRight();
                }
            } else {
                left = view.getLeft() - eachWidth;
                right = view.getRight() + eachWidth;
            }

            //水平方向
            if (isFirstRow(i) && isFirstRowTopEnable) {
                top = view.getTop() - mFirstRowWidth;
            } else {
                top = view.getTop();
            }

            if (isLastRow(i, childCount)) {
                if (isLastRowBottomEnable) {
                    bottom = view.getBottom() + mLastRowWidth;
                } else {
                    bottom = view.getBottom();
                }
                //未显示全时，最后一个补差绘制
                if (isNounAndLastItem(i, childCount)) {
                    int left1 = view.getRight();
                    int top1 = view.getTop();
                    int right1 = view.getRight() + mDividerWidth;
                    int bottom1 = view.getBottom() + mLastRowWidth;
                    canvas.drawRect(left1, top1, right1, bottom1, mPaint);
                }
            } else {
                bottom = view.getBottom() + mDividerWidth;
            }
            canvas.drawRect(left, top, right, bottom, mPaint);
        }
    }

    private boolean isFirstRow(int itemPosition) {
        boolean result = false;
        if (mLayoutManager instanceof GridLayoutManager) {
            GridLayoutManager gridLayoutManager = (GridLayoutManager) mLayoutManager;
            int spanCount = gridLayoutManager.getSpanCount();

            result = (itemPosition / spanCount + 1) == 1;
        }
        return result;
    }

    private boolean isLastRow(int itemPosition, int childCount) {
        boolean result = false;
        if (mLayoutManager instanceof GridLayoutManager) {
            GridLayoutManager gridLayoutManager = (GridLayoutManager) mLayoutManager;
            int spanCount = gridLayoutManager.getSpanCount();

            int lines = childCount % spanCount == 0 ? childCount / spanCount : (childCount / spanCount) + 1;
            result = lines == (itemPosition / spanCount) + 1;
        }
        return result;
    }

    private boolean isRowItemFirst(int itemPosition) {
        boolean result = false;
        if (mLayoutManager instanceof GridLayoutManager) {
            GridLayoutManager gridLayoutManager = (GridLayoutManager) mLayoutManager;
            int spanCount = gridLayoutManager.getSpanCount();
            result = itemPosition % spanCount == 0;
        }
        return result;
    }

    private boolean isRowItemLast(int itemPosition) {
        boolean result = false;
        if (mLayoutManager instanceof GridLayoutManager) {
            GridLayoutManager gridLayoutManager = (GridLayoutManager) mLayoutManager;
            int spanCount = gridLayoutManager.getSpanCount();

            result = itemPosition % spanCount == spanCount - 1;
//            if (!isLastRow(itemPosition, childCount)) {
//                result = itemPosition % spanCount == spanCount - 1;
//            } else {
//                if (childCount % spanCount == 0) {
//                    result = itemPosition % spanCount == spanCount - 1;
//                } else {
//                    result = (itemPosition + 1) % spanCount == childCount % spanCount;
//                }
//            }
        }
        return result;
    }


    private boolean isNounAndLastItem(int itemPosition, int childCount) {
        boolean result = false;
        if (mLayoutManager instanceof GridLayoutManager) {
            GridLayoutManager gridLayoutManager = (GridLayoutManager) mLayoutManager;
            int spanCount = gridLayoutManager.getSpanCount();

            if (childCount % spanCount != 0) {
                result = (itemPosition + 1) % spanCount == childCount % spanCount;
            }
        }
        return result;
    }
}
