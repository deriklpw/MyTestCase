package com.ozmobi.coupons.common;

public interface BasePresenter<V> {

    void start();

    void cancel();

    void attach(V v);

    void detach();

    void destroy();

}
