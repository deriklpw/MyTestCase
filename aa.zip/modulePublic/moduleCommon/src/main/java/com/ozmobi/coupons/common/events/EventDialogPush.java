package com.ozmobi.coupons.common.events;

import android.os.Parcel;
import android.os.Parcelable;

public class EventDialogPush implements Parcelable {
    public static final int OPEN_DIALOG_CONFIRM = 1;
    public static final int OPEN_DIALOG_CONFIRM_CANCEL = 2;
    public static final int OPEN_DIALOG_FOR_IMAGE = 3;

    private int target;
    private String title;
    private String ext;
    private String desc;

    public EventDialogPush(int target, String title, String ext, String desc) {
        this.target = target;
        this.title = title;
        this.ext = ext;
        this.desc = desc;
    }

    protected EventDialogPush(Parcel in) {
        target = in.readInt();
        title = in.readString();
        ext = in.readString();
        desc = in.readString();
    }

    public static final Creator<EventDialogPush> CREATOR = new Creator<EventDialogPush>() {
        @Override
        public EventDialogPush createFromParcel(Parcel in) {
            return new EventDialogPush(in);
        }

        @Override
        public EventDialogPush[] newArray(int size) {
            return new EventDialogPush[size];
        }
    };

    public int getTarget() {
        return target;
    }

    public void setTarget(int target) {
        this.target = target;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(target);
        dest.writeString(title);
        dest.writeString(ext);
        dest.writeString(desc);
    }
}
