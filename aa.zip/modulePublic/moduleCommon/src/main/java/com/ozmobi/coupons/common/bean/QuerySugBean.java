package com.ozmobi.coupons.common.bean;

import java.util.List;

public class QuerySugBean {

    private List<List<String>> result;

    public List<List<String>> getResult() {
        return result;
    }

    public void setResult(List<List<String>> result) {
        this.result = result;
    }
}
