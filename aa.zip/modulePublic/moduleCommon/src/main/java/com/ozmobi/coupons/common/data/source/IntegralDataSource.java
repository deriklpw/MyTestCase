package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.common.bean.ExchangeGoodsBean;
import com.ozmobi.coupons.common.bean.ExchangeRecordBean;
import com.ozmobi.coupons.common.bean.IntegralCenterBean;
import com.ozmobi.coupons.common.bean.IntegralDetailBean;
import com.ozmobi.coupons.common.bean.PunchRecordDetailBean;
import com.ozmobi.coupons.common.bean.PunchRecordResultBean;
import com.ozmobi.coupons.common.bean.PunchIntegralBean;
import com.ozmobi.coupons.common.bean.SignInResultBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

/**
 * Created by xhkj on 2019/5/10.
 */

public interface IntegralDataSource extends BaseDataSource {
    Disposable getIntegralCenterData(@NonNull Consumer<? super IntegralCenterBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getIntegralDetail(int page, int pageSize, @NonNull Consumer<? super IntegralDetailBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getExchangeGoodsDetail(int id, @NonNull Consumer<? super ExchangeGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable exchangeGoods(int id, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    Disposable getExchangeRecord(int page, int pageSize, @NonNull Consumer<? super ExchangeRecordBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable signInNow(@NonNull Consumer<? super SignInResultBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getPunchIntegral(@NonNull Consumer<? super PunchIntegralBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable applyPunch(@NonNull Consumer<? super PunchIntegralBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable punchNow(@NonNull Consumer<? super PunchIntegralBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getPunchRecordMyResult(@NonNull Consumer<? super PunchRecordResultBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getPunchRecordDetail(int page, int pageSize, @NonNull Consumer<? super PunchRecordDetailBean> success, @NonNull Consumer<? super Throwable> error);
}
