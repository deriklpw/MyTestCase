package com.ozmobi.coupons.common.bean;

/**
 * Created by xhkj on 2019/9/25.
 */

public class PunchIntegralBean {
    private int error;
    private String msg;
    private DataBean data;
    private int time;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public static class DataBean {
        private int clockin_status;
        private int clockin_left_time;
        private int apply_integral;
        private int yesterday_avg_reward;
        private int apply_users;
        private int total_integral;
        private String last_apply_nick;
        private String clockin_time;
        private String clockin_rule;

        public int getClockin_status() {
            return clockin_status;
        }

        public void setClockin_status(int clockin_status) {
            this.clockin_status = clockin_status;
        }

        public int getClockin_left_time() {
            return clockin_left_time;
        }

        public void setClockin_left_time(int clockin_left_time) {
            this.clockin_left_time = clockin_left_time;
        }

        public int getApply_integral() {
            return apply_integral;
        }

        public void setApply_integral(int apply_integral) {
            this.apply_integral = apply_integral;
        }

        public int getYesterday_avg_reward() {
            return yesterday_avg_reward;
        }

        public void setYesterday_avg_reward(int yesterday_avg_reward) {
            this.yesterday_avg_reward = yesterday_avg_reward;
        }

        public int getApply_users() {
            return apply_users;
        }

        public void setApply_users(int apply_users) {
            this.apply_users = apply_users;
        }

        public int getTotal_integral() {
            return total_integral;
        }

        public void setTotal_integral(int total_integral) {
            this.total_integral = total_integral;
        }

        public String getLast_apply_nick() {
            return last_apply_nick;
        }

        public void setLast_apply_nick(String last_apply_nick) {
            this.last_apply_nick = last_apply_nick;
        }

        public String getClockin_time() {
            return clockin_time;
        }

        public void setClockin_time(String clockin_time) {
            this.clockin_time = clockin_time;
        }

        public String getClockin_rule() {
            return clockin_rule;
        }

        public void setClockin_rule(String clockin_rule) {
            this.clockin_rule = clockin_rule;
        }
    }
}
