package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.CategoryBean;
import com.ozmobi.coupons.common.bean.UpdateBean;
import com.ozmobi.coupons.common.data.source.CategoryDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;
import com.ozmobi.coupons.base.utils.PrefUtils;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

public class CategoryRepository implements CategoryDataSource {

    private static final String TAG = "CategoryRepository";

    @Override
    public Disposable getCategory(@NonNull Consumer<? super CategoryBean> success, @NonNull Consumer<? super Throwable> error) {
        Observable<CategoryBean> diskObservable = getDiskCateObservable();

        Observable<CategoryBean> netObservable = getNetCateObservable();

        return Observable.concat(diskObservable, netObservable)
                .subscribeOn(Schedulers.io())
                .firstElement()
                .map(categoryBean -> {
                    String json = PrefUtils.readString(PrefUtils.KEY_GOODS_CATEGORY);
                    //只是判断是否需要存储
                    if (TextUtils.isEmpty(json)) {
                        PrefUtils.writeString(PrefUtils.KEY_GOODS_CATEGORY, JSON.toJSONString(categoryBean));
                    }
                    return categoryBean;
                })
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    private Observable<CategoryBean> getDiskCateObservable() {
        return Observable.create(emitter -> {
            String json = PrefUtils.readString(PrefUtils.KEY_GOODS_CATEGORY);
            CategoryBean categoryBean = JSON.parseObject(json, CategoryBean.class);
            if (categoryBean != null) {
                emitter.onNext(categoryBean);
            }
            emitter.onComplete();
        });
    }

    private Observable<CategoryBean> getNetCateObservable() {
        String json = DeviceUtil.getJsonDeviceInfo();
        LogUtil.d(TAG, "get cate post json=" + json);
        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().getCategory(requestBody);
    }

    @Override
    public Disposable checkUpdate(@NonNull Consumer<? super UpdateBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "checkUpdate post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        Observable<UpdateBean> observable = ApiFactory.getYjlController().checkUpdate(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getWelcomeDialogInfo(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "getWelcomeDialogInfo post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        Observable<JSONObject> observable = ApiFactory.getYjlController().
                getWelcomeDialogInfo(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }
}
