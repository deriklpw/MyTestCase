package com.ozmobi.coupons.common.data.bean;

/**
 * Created by xhkj on 2019/7/3.
 */

public class AccountSafeItemBean {
    private int index;
    private String name;
    private String desc;
    private boolean indicatorEnable = true;

    public AccountSafeItemBean(int index, String name) {
        this.index = index;
        this.name = name;
    }

    public AccountSafeItemBean(int index, String name, String desc) {
        this.index = index;
        this.name = name;
        this.desc = desc;
    }

    public AccountSafeItemBean(int index, String name, String desc, boolean indicatorEnable) {
        this.index = index;
        this.name = name;
        this.desc = desc;
        this.indicatorEnable = indicatorEnable;
    }

    public int getIndex() {
        return index;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public boolean isIndicatorEnable() {
        return indicatorEnable;
    }

    public void setIndicatorEnable(boolean indicatorEnable) {
        this.indicatorEnable = indicatorEnable;
    }
}
