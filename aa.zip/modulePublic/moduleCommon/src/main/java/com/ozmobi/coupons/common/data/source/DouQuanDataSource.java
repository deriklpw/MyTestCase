package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;

import com.ozmobi.coupons.common.bean.DouYinCateBean;
import com.ozmobi.coupons.common.bean.VideoGoodsBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public interface DouQuanDataSource extends BaseDataSource {

    /**
     * 获取抖券类别类表
     * @param success
     * @param error
     * @return
     */
    Disposable getDouYinKindList(@NonNull Consumer<? super DouYinCateBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取抖音商品视频列表，支持分页，不支持请求数量
     * @param cate
     * @param page
     * @param success
     * @param error
     * @return
     */
    Disposable getDouYinGoodsList(int cate, int page, @NonNull Consumer<? super VideoGoodsBean> success, @NonNull Consumer<? super Throwable> error);
}
