package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/6/28.
 */

public class BrandBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private List<CommonProductsEntity> brand_hot;
        private List<CommonPromoteBean> banner;
        private List<BrandEntity> brand;

        public void setBrand_hot(List<CommonProductsEntity> brand_hot) {
            this.brand_hot = brand_hot;
        }

        public void setBanner(List<CommonPromoteBean> banner) {
            this.banner = banner;
        }

        public void setBrand(List<BrandEntity> brand) {
            this.brand = brand;
        }

        public List<CommonProductsEntity> getBrand_hot() {
            return brand_hot;
        }

        public List<CommonPromoteBean> getBanner() {
            return banner;
        }

        public List<BrandEntity> getBrand() {
            return brand;
        }

        public class BrandEntity {
            private String brand_id;
            private String brand_bg;
            private String introduce;
            private String shop_title;
            private String brand_name;
            private String brand_logo;
            private List<CommonProductsEntity> products;

            public String getBrand_id() {
                return brand_id;
            }

            public void setBrand_id(String brand_id) {
                this.brand_id = brand_id;
            }

            public void setBrand_bg(String brand_bg) {
                this.brand_bg = brand_bg;
            }

            public void setIntroduce(String introduce) {
                this.introduce = introduce;
            }

            public void setShop_title(String shop_title) {
                this.shop_title = shop_title;
            }

            public void setBrand_name(String brand_name) {
                this.brand_name = brand_name;
            }

            public void setBrand_logo(String brand_logo) {
                this.brand_logo = brand_logo;
            }

            public void setProducts(List<CommonProductsEntity> products) {
                this.products = products;
            }

            public String getBrand_bg() {
                return brand_bg;
            }

            public String getIntroduce() {
                return introduce;
            }

            public String getShop_title() {
                return shop_title;
            }

            public String getBrand_name() {
                return brand_name;
            }

            public String getBrand_logo() {
                return brand_logo;
            }

            public List<CommonProductsEntity> getProducts() {
                return products;
            }
        }
    }
}
