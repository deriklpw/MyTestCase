package com.ozmobi.coupons.common.bean;

import java.util.List;

public class IncomeDetailBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private List<Income_detailEntity> income_detail;

        public void setIncome_detail(List<Income_detailEntity> income_detail) {
            this.income_detail = income_detail;
        }

        public List<Income_detailEntity> getIncome_detail() {
            return income_detail;
        }

        public class Income_detailEntity {
            private String income;
            private String month;
            private List<DetailEntity> detail;

            public void setIncome(String income) {
                this.income = income;
            }

            public void setMonth(String month) {
                this.month = month;
            }

            public void setDetail(List<DetailEntity> detail) {
                this.detail = detail;
            }

            public String getIncome() {
                return income;
            }

            public String getMonth() {
                return month;
            }

            public List<DetailEntity> getDetail() {
                return detail;
            }

            public class DetailEntity {
                private String create_time;
                private String money;
                private String goods_title;
                private String order_money;
                private String settle_time;
                private String num_iid;

                public void setCreate_time(String create_time) {
                    this.create_time = create_time;
                }

                public void setMoney(String money) {
                    this.money = money;
                }

                public void setGoods_title(String goods_title) {
                    this.goods_title = goods_title;
                }

                public void setOrder_money(String order_money) {
                    this.order_money = order_money;
                }

                public void setSettle_time(String settle_time) {
                    this.settle_time = settle_time;
                }

                public String getCreate_time() {
                    return create_time;
                }

                public String getMoney() {
                    return money;
                }

                public String getGoods_title() {
                    return goods_title;
                }

                public String getOrder_money() {
                    return order_money;
                }

                public String getSettle_time() {
                    return settle_time;
                }

                public String getNum_iid() {
                    return num_iid;
                }

                public void setNum_iid(String num_iid) {
                    this.num_iid = num_iid;
                }
            }
        }
    }
}
