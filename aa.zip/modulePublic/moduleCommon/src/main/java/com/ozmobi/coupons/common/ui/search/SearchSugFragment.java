package com.ozmobi.coupons.common.ui.search;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.BaseFragment;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.adapter.CustomBaseAdapter;
import com.ozmobi.coupons.common.utils.LinearItemDivider;

import java.util.ArrayList;
import java.util.List;

public class SearchSugFragment extends BaseFragment {

    private static final String TAG = "SearchSugFragment";

    private static final String QUERY_SUG = "query_sug";

    private ArrayList<String> mListSug;

    private SugCallback mSugCallback;

    private SugAdapter mSugAdapter;

    public SearchSugFragment() {
        // Required empty public constructor
    }

    public void updateSug(ArrayList<String> list) {
        if (mListSug != null) {
            mListSug.clear();
            mListSug.addAll(list);
        }
        if (mSugAdapter != null) {
            mSugAdapter.notifyDataSetChanged();
        }
    }

    public static SearchSugFragment newInstance(ArrayList<String> listSug) {
        SearchSugFragment fragment = new SearchSugFragment();
        Bundle args = new Bundle();
        args.putStringArrayList(QUERY_SUG, listSug);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtil.d(TAG, "onCreate: ");
        if (getArguments() != null) {
            mListSug = getArguments().getStringArrayList(QUERY_SUG);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.d(TAG, "onResume: ");
    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.d(TAG, "onPause: ");
    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtil.d(TAG, "onStop: ");
    }

    @Override
    protected int getLayoutId() {
        return R.layout.common_fragment_search_sug;
    }

    @Override
    protected void initViews() {
        RecyclerView recyclerView = findView(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        recyclerView.addItemDecoration(new LinearItemDivider(1, getResources().getColor(R.color.common_color_gray)));
        mSugAdapter = new SugAdapter(R.layout.common_adapter_item_search_sug, mListSug);
        recyclerView.setAdapter(mSugAdapter);
        mSugAdapter.setOnItemClickListener((view, s, position) -> {
            if (mSugCallback != null) {
                LogUtil.d(TAG, "initViews: position=" + position);
                mSugCallback.onSugCallback(mListSug.get(position));
            }
        });
    }

    @Override
    protected void lazyFetchData() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateView: ");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        LogUtil.d(TAG, "onAttach: ");
        if (context instanceof SugCallback) {
            mSugCallback = (SugCallback) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        LogUtil.d(TAG, "onDetach: ");
        mSugCallback = null;
    }

    public class SugAdapter extends CustomBaseAdapter<String> {
        //R.layout.adapter_item_search_sug

        public SugAdapter(int layoutId, List<String> list) {
            super(layoutId, list);
        }

        @Override
        public RecyclerView.ViewHolder onCreateCustomViewHolder(View view) {
            return new SugHolder(view);
        }

        @Override
        public void onBindCustomViewHolder(RecyclerView.ViewHolder viewHolder, String s, int position) {
            if (viewHolder instanceof SugHolder) {
                SugHolder sugHolder = (SugHolder) viewHolder;
                LogUtil.d(TAG, "onBindCustomViewHolder: position=" + position);
                sugHolder.tvQuery.setText(mListSug.get(position));
            }
        }

        class SugHolder extends CustomBaseAdapter.CustomBaseHolder {
            private TextView tvQuery;

            SugHolder(@NonNull View itemView) {
                super(itemView);
                tvQuery = itemView.findViewById(R.id.tv_search_query);
            }
        }
    }

    public interface SugCallback {
        void onSugCallback(String query);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        LogUtil.d(TAG, "onDestroyView: ");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtil.d(TAG, "onDestroy: ");
        if (mListSug != null) {
            mListSug.clear();
            mListSug = null;
        }

        mSugAdapter = null;
    }
}
