package com.ozmobi.coupons.common.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.util.AttributeSet;

import com.ozmobi.coupons.common.R;

public class CustomColorfulTextView extends android.support.v7.widget.AppCompatTextView {

    private final int mEndColor;
    private final int mMiddleColor;
    private LinearGradient mLinearGradient;

    private Rect mTextBound = new Rect();
    private final int mStartColor;

    public CustomColorfulTextView(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.CustomColorfulTextView);
        mStartColor = typedArray.getColor(R.styleable.CustomColorfulTextView_startColor, getResources().getColor(R.color.common_color_D0A681));
        mMiddleColor = typedArray.getColor(R.styleable.CustomColorfulTextView_middleColor, getResources().getColor(R.color.common_color_F7D7B0));
        mEndColor = typedArray.getColor(R.styleable.CustomColorfulTextView_endColor, getResources().getColor(R.color.common_color_D8A179));
        typedArray.recycle();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Paint paint = getPaint();
        String text = getText().toString();
        paint.getTextBounds(text, 0, text.length(), mTextBound);
        float textWidth = mTextBound.width();
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();

        if (mLinearGradient == null) {
            mLinearGradient = new LinearGradient(0, 0, textWidth, 0,
                    new int[]{mStartColor, mMiddleColor, mEndColor},
                    null, Shader.TileMode.REPEAT);
        }
        paint.setShader(mLinearGradient);
        float distance = (fontMetrics.bottom - fontMetrics.top) / 2.0f - fontMetrics.bottom;
        canvas.drawText(text, getMeasuredWidth() / 2.0f - textWidth / 2, getMeasuredHeight() / 2.0f + distance, paint);
    }
}
