package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.data.source.UserDataSource;
import com.ozmobi.coupons.base.manager.UserInfoManager;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

/**
 * Created by xhkj on 2019/5/23.
 */

public class UserDataRepository implements UserDataSource {

    private static final String TAG = "UserDataRepository";

    @Override
    public Disposable queryInvitation(@NonNull String invite, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("invite", invite);
            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "query invite post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().queryInvitation(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable checkMobile(@NonNull String mobile, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("mobile", mobile);
            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "check mobile post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().queryMobile(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable requestMessageCode(@NonNull String mobile, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("mobile", mobile);
            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "send code post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().requestMessageCode(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable registerMobile(@NonNull String mobile, @NonNull String messageCode, @Nullable String invite, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("mobile", mobile);
            params.put("code", messageCode);

            if (!TextUtils.isEmpty(invite)) {
                params.put("invite", invite);
            }
            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "register mobile post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().registerMobile(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
//                        DeviceUtil.saveUserInfo(userInfo.toJSONString());
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable loginWithPwd(@NonNull String mobile, @NonNull String pwd, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("mobile", mobile);
            params.put("password", pwd);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "login with pwd post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().loginWithPwd(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
//                        DeviceUtil.saveUserInfo(userInfo.toJSONString());
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable loginWithCode(@NonNull String mobile, @NonNull String messageCode, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("mobile", mobile);
            params.put("code", messageCode);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "login with code post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().loginWithCode(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
//                        DeviceUtil.saveUserInfo(userInfo.toJSONString());
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable resetPassword(@NonNull String mobile, @NonNull String messageCode, @NonNull String newPwd, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("mobile", mobile);
            params.put("code", messageCode);
            params.put("password", newPwd);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "reset pwd post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().resetPassword(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable registerWithWeChat(@NonNull String mobile, @NonNull String messageCode, @Nullable String invite, @NonNull String unionId, @NonNull String openId, @NonNull String name, @NonNull String iconUrl, int gender, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("mobile", mobile);
            params.put("code", messageCode);

            if (!TextUtils.isEmpty(invite)) {
                params.put("invite", invite);
            }

            params.put("unionId", unionId);
            params.put("openid", openId);
            params.put("name", name);
            params.put("iconurl", iconUrl);
            params.put("unionGender", gender);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "register with wechat post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().registerWithWeChat(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
//                        DeviceUtil.saveUserInfo(userInfo.toJSONString());
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable loginWithWeChat(@NonNull String unionId, @NonNull String openId, @NonNull String name, @NonNull String iconUrl, int gender, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("unionId", unionId);
            params.put("openid", openId);
            params.put("name", name);
            params.put("iconurl", iconUrl);
            params.put("unionGender", gender);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "login with wechat post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().loginWithWeChat(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
//                        DeviceUtil.saveUserInfo(userInfo.toJSONString());
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable updateUserNickName(@NonNull String nickName, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("nick", nickName);

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "update nick post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().updateUserInfo(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
//                        DeviceUtil.saveUserInfo(userInfo.toJSONString());
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable updateUserGender(@NonNull String gender, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("gender", gender);

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "update gender post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().updateUserInfo(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
//                        DeviceUtil.saveUserInfo(userInfo.toJSONString());
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable updateUserIcon(@NonNull String iconBase64, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("icon", iconBase64);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "update icon post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().updateUserInfo(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
//                        DeviceUtil.saveUserInfo(userInfo.toJSONString());
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable unbindTaoBaoAccount(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "unbindTaoBaoAccount post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().unbindTaoBaoAccount(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable bindWeChatAccount(@NonNull String unionId, @NonNull String openId, @NonNull String name, @NonNull String iconUrl, int gender, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("unionId", unionId);
            params.put("openid", openId);
            params.put("name", name);
            params.put("iconurl", iconUrl);
            params.put("unionGender", gender);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "bindWeChatAccount post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().bindWeChatAccount(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable unbindWeChatAccount(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "unbindWeChatAccount post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().unbindWeChatAccount(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable modifyMobile(@NonNull String mobile, @NonNull String msgCode, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("mobile", mobile);
            params.put("code", msgCode);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "modifyMobile post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().modifyMobile(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable checkMessageCode(@NonNull String mobile, @NonNull String msgCode, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("mobile", mobile);
            params.put("code", msgCode);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "checkMessageCode post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().checkMessageCode(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getUserMessage(@NonNull String type, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("type", type);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getUserMessage post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().getUserMessage(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable loginWithOneKeyMobile(@NonNull String loginToken, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("token", loginToken);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getUserMessage post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().loginWithOneKeyMobile(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }
}
