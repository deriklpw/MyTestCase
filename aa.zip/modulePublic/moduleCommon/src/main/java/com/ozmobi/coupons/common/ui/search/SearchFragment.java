package com.ozmobi.coupons.common.ui.search;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.BaseFragment;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.views.flowlayout.FlowLayout;
import com.ozmobi.coupons.common.views.flowlayout.TagAdapter;
import com.ozmobi.coupons.common.views.flowlayout.TagFlowLayout;

import java.util.ArrayList;
import java.util.List;


public class SearchFragment extends BaseFragment {

    private static final String TAG = "SearchFragment";

    private static final String HOT_WORDS = "hot_words";

    private static final String HISTORY_WORDS = "history_words";

    private List<String> mHotWords;

    private List<String> mHistoryWords;

    private SearchCallback mCallback;

    private TagAdapter<String> mHistoryAdapter;

    public SearchFragment() {
        // Required empty public constructor
    }

    public void updateHistory(ArrayList<String> histories) {
        mHistoryWords = histories;
        if (mHistoryAdapter != null) {
            mHistoryAdapter.notifyDataChanged();
        }
    }

    public static SearchFragment newInstance(ArrayList<String> hotWords, ArrayList<String> histories) {
        SearchFragment fragment = new SearchFragment();
        Bundle args = new Bundle();
        args.putStringArrayList(HOT_WORDS, hotWords);
        args.putStringArrayList(HISTORY_WORDS, histories);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtil.d(TAG, "onCreate: ");
        if (getArguments() != null) {
            mHotWords = getArguments().getStringArrayList(HOT_WORDS);
            mHistoryWords = getArguments().getStringArrayList(HISTORY_WORDS);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.d(TAG, "onResume: ");
    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.d(TAG, "onPause: ");
    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtil.d(TAG, "onStop: ");
    }

    @Override
    protected int getLayoutId() {
        return R.layout.common_fragment_search;
    }

    @Override
    protected void initViews() {

        TextView tvClear = findView(R.id.tv_search_history_clear);

        ViewGroup historyTitle = findView(R.id.rl_search_history_title);

        TagFlowLayout hotFlowLayout = findView(R.id.flowlayout_hot);

        TagFlowLayout historyFlowLayout = findView(R.id.flowlayout_history);


        TagAdapter<String> hotAdapter = new TagAdapter<String>(mHotWords) {
            @Override
            public View getView(FlowLayout parent, int position, String s) {
                TextView tv = (TextView) getLayoutInflater().inflate(R.layout.common_tag_search_text,
                        hotFlowLayout, false);
                tv.setText(s);
                return tv;
            }
        };

        hotFlowLayout.setAdapter(hotAdapter);

        hotFlowLayout.setOnTagClickListener(new TagFlowLayout.OnTagClickListener() {
            @Override
            public boolean onTagClick(View view, int position, FlowLayout parent) {
                LogUtil.d(TAG, "hot tag item clicked");
                if (mCallback != null) {
                    mCallback.onTagClicked(mHotWords.get(position));
                }

                return true;
            }
        });


        if (mHistoryWords != null && mHistoryWords.size() > 0) {
            historyTitle.setVisibility(View.VISIBLE);
        } else {
            historyTitle.setVisibility(View.GONE);
        }

        mHistoryAdapter = new TagAdapter<String>(mHistoryWords) {
            @Override
            public View getView(FlowLayout parent, int position, String s) {
                TextView tv = (TextView) getLayoutInflater().inflate(R.layout.common_tag_search_text,
                        historyFlowLayout, false);
                tv.setText(s);
                return tv;
            }
        };

        historyFlowLayout.setAdapter(mHistoryAdapter);

        historyFlowLayout.setOnTagClickListener(new TagFlowLayout.OnTagClickListener() {
            @Override
            public boolean onTagClick(View view, int position, FlowLayout parent) {
                LogUtil.d(TAG, "history tag item clicked: ");
                if (mCallback != null && mHistoryWords != null && mHistoryWords.size() > 0) {
                    mCallback.onTagClicked(mHistoryWords.get(position));
                }
                return true;
            }
        });

        tvClear.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                LogUtil.d(TAG, "history clear clicked: ");
                if (mCallback != null) {
                    mCallback.onClearHistory();
                }
                if (mHistoryWords != null) {
                    mHistoryWords.clear();
                }
                historyTitle.setVisibility(View.GONE);
                mHistoryAdapter.notifyDataChanged();
            }
        });
    }

    @Override
    protected void lazyFetchData() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateView: ");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof SearchCallback) {
            mCallback = (SearchCallback) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallback = null;
        LogUtil.d(TAG, "onDetach: ");
    }

    public interface SearchCallback {
        void onTagClicked(String tag);

        void onClearHistory();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        LogUtil.d(TAG, "onDestroyView: ");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtil.d(TAG, "onDestroy: ");
        mHotWords = null;
        mHistoryWords = null;
        mCallback = null;
        mHistoryAdapter = null;
    }
}
