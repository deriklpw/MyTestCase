package com.ozmobi.coupons.common.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.common.R;

public class AlertDialog2Fragment extends BaseDialogFragment {

    private static final String ARG_TITLE = "arg_title";
    private static final String ARG_TEXT = "arg_text";
    private static final String ARG_TIPS = "arg_tips";
    private static final String ARG_LEFT_BUTTON = "arg_left_button";
    private static final String ARG_RIGHT_BUTTON = "arg_right_button";

    private String mTitle;
    private String mText;
    private String mTips;
    private String mLeftBtnText;
    private String mRightBtnText;

    private OnFragmentInteractionListener mListener;

    public AlertDialog2Fragment() {
        // Required empty public constructor
    }

    public static AlertDialog2Fragment newInstance(String title, String text, String tips, String leftText, String rightText) {
        AlertDialog2Fragment fragment = new AlertDialog2Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_TITLE, title);
        args.putString(ARG_TEXT, text);
        args.putString(ARG_TIPS, tips);
        args.putString(ARG_LEFT_BUTTON, leftText);
        args.putString(ARG_RIGHT_BUTTON, rightText);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mTitle = getArguments().getString(ARG_TITLE);
            mText = getArguments().getString(ARG_TEXT);
            mTips = getArguments().getString(ARG_TIPS);
            mLeftBtnText = getArguments().getString(ARG_LEFT_BUTTON);
            mRightBtnText = getArguments().getString(ARG_RIGHT_BUTTON);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog dialog = new AlertDialog.Builder(mContext).create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.CENTER);
        window.setContentView(R.layout.common_dialog_fragment_alert2);

        ImageView ivClose = window.findViewById(R.id.iv_alert_dialog_close_icon);

        TextView tvTitle = window.findViewById(R.id.tv_alert_dialog_title);
        TextView tvText = window.findViewById(R.id.tv_alert_dialog_text);
        TextView tvTip = window.findViewById(R.id.tv_alert_dialog_tip);

        Button btnLeft = window.findViewById(R.id.btn_alert_dialog_left);
        Button btnRight = window.findViewById(R.id.btn_alert_dialog_right);

        tvTitle.setText(mTitle);
        tvText.setText(mText);

        if (TextUtils.isEmpty(mTips)) {
            tvTip.setVisibility(View.GONE);
        } else {
            tvTip.setVisibility(View.VISIBLE);
            tvTip.setText(mTips);
        }

        if (!TextUtils.isEmpty(mLeftBtnText)) {
            btnLeft.setText(mLeftBtnText);
        }

        if (!TextUtils.isEmpty(mRightBtnText)) {
            btnRight.setText(mRightBtnText);
        }

        ivClose.setOnClickListener(v -> getDialog().dismiss());

        btnLeft.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                getDialog().dismiss();
                if (mListener != null) {
                    mListener.onLeftClick(getTag(), mTitle, mText);
                }
            }
        });

        btnRight.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                getDialog().dismiss();
                if (mListener != null) {
                    mListener.onRightClick(getTag(), mTitle, mText);
                }
            }
        });

        return dialog;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void onLeftClick(String tag, String title, String text);

        void onRightClick(String tag, String title, String text);
    }
}
