package com.ozmobi.coupons.common.data.bean;

import android.os.Parcel;
import android.os.Parcelable;

public class VersionBean implements Parcelable {
    private boolean isForce;
    private String updateTime;
    private String updateVersion;
    private String updateType;
    private String updateInfo;
    private String url;

    private VersionBean(Builder builder) {
        isForce = builder.isForce;
        updateTime = builder.updateTime;
        updateVersion = builder.updateVersion;
        updateType = builder.updateType;
        updateInfo = builder.updateInfo;
        url = builder.url;
    }

    private VersionBean(Parcel in) {
        isForce = in.readByte() != 0;
        updateTime = in.readString();
        updateVersion = in.readString();
        updateType = in.readString();
        updateInfo = in.readString();
        url = in.readString();
    }

    public static final Creator<VersionBean> CREATOR = new Creator<VersionBean>() {
        @Override
        public VersionBean createFromParcel(Parcel in) {
            return new VersionBean(in);
        }

        @Override
        public VersionBean[] newArray(int size) {
            return new VersionBean[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeByte((byte) (isForce ? 1 : 0));
        dest.writeString(updateTime);
        dest.writeString(updateVersion);
        dest.writeString(updateType);
        dest.writeString(updateInfo);
        dest.writeString(url);
    }

    public static final class Builder {
        private boolean isForce;
        private String updateTime;
        private String updateVersion;
        private String updateType;
        private String updateInfo;
        private String url;

        public Builder() {
        }

        public Builder withIsForce(boolean val) {
            isForce = val;
            return this;
        }

        public Builder withUpdateTime(String val) {
            updateTime = val;
            return this;
        }

        public Builder withUpdateVersion(String val) {
            updateVersion = val;
            return this;
        }

        public Builder withUpdateType(String val) {
            updateType = val;
            return this;
        }

        public Builder withUpdateInfo(String val) {
            updateInfo = val;
            return this;
        }

        public Builder withUrl(String val) {
            url = val;
            return this;
        }

        public VersionBean build() {
            return new VersionBean(this);
        }
    }

    public boolean isForce() {
        return isForce;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public String getUpdateVersion() {
        return updateVersion;
    }

    public String getUpdateType() {
        return updateType;
    }

    public String getUpdateInfo() {
        return updateInfo;
    }

    public String getUrl() {
        return url;
    }
}
