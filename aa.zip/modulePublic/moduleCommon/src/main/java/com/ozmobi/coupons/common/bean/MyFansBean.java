package com.ozmobi.coupons.common.bean;

/**
 * Created by xhkj on 2019/8/14.
 */

public class MyFansBean {
    private int error;
    private String msg;
    private DataBean data;
    private int time;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public static class DataBean {
        private InviteUserBean invite_user;
        private DirectFansBean direct_fans;
        private IndirectFansBean indirect_fans;

        public InviteUserBean getInvite_user() {
            return invite_user;
        }

        public void setInvite_user(InviteUserBean invite_user) {
            this.invite_user = invite_user;
        }

        public DirectFansBean getDirect_fans() {
            return direct_fans;
        }

        public void setDirect_fans(DirectFansBean direct_fans) {
            this.direct_fans = direct_fans;
        }

        public IndirectFansBean getIndirect_fans() {
            return indirect_fans;
        }

        public void setIndirect_fans(IndirectFansBean indirect_fans) {
            this.indirect_fans = indirect_fans;
        }

        public static class InviteUserBean {
            private String nick;
            private String icon;
            private String mobile;

            public String getNick() {
                return nick;
            }

            public void setNick(String nick) {
                this.nick = nick;
            }

            public String getIcon() {
                return icon;
            }

            public void setIcon(String icon) {
                this.icon = icon;
            }

            public String getMobile() {
                return mobile;
            }

            public void setMobile(String mobile) {
                this.mobile = mobile;
            }
        }

        public static class DirectFansBean {
            private String fans_num;
            private String pay_amount;
            private String buy_fans_num;
            private String nobuy_fans_num;
            private String seven_day_login_num;
            private String seven_day_nologin_num;
            private String income;

            public String getFans_num() {
                return fans_num;
            }

            public void setFans_num(String fans_num) {
                this.fans_num = fans_num;
            }

            public String getPay_amount() {
                return pay_amount;
            }

            public void setPay_amount(String pay_amount) {
                this.pay_amount = pay_amount;
            }

            public String getBuy_fans_num() {
                return buy_fans_num;
            }

            public void setBuy_fans_num(String buy_fans_num) {
                this.buy_fans_num = buy_fans_num;
            }

            public String getNobuy_fans_num() {
                return nobuy_fans_num;
            }

            public void setNobuy_fans_num(String nobuy_fans_num) {
                this.nobuy_fans_num = nobuy_fans_num;
            }

            public String getSeven_day_login_num() {
                return seven_day_login_num;
            }

            public void setSeven_day_login_num(String seven_day_login_num) {
                this.seven_day_login_num = seven_day_login_num;
            }

            public String getSeven_day_nologin_num() {
                return seven_day_nologin_num;
            }

            public void setSeven_day_nologin_num(String seven_day_nologin_num) {
                this.seven_day_nologin_num = seven_day_nologin_num;
            }

            public String getIncome() {
                return income;
            }

            public void setIncome(String income) {
                this.income = income;
            }
        }

        public static class IndirectFansBean {
            private String fans_num;
            private String pay_amount;
            private String buy_fans_num;
            private String nobuy_fans_num;
            private String seven_day_login_num;
            private String seven_day_nologin_num;
            private String income;

            public String getFans_num() {
                return fans_num;
            }

            public void setFans_num(String fans_num) {
                this.fans_num = fans_num;
            }

            public String getPay_amount() {
                return pay_amount;
            }

            public void setPay_amount(String pay_amount) {
                this.pay_amount = pay_amount;
            }

            public String getBuy_fans_num() {
                return buy_fans_num;
            }

            public void setBuy_fans_num(String buy_fans_num) {
                this.buy_fans_num = buy_fans_num;
            }

            public String getNobuy_fans_num() {
                return nobuy_fans_num;
            }

            public void setNobuy_fans_num(String nobuy_fans_num) {
                this.nobuy_fans_num = nobuy_fans_num;
            }

            public String getSeven_day_login_num() {
                return seven_day_login_num;
            }

            public void setSeven_day_login_num(String seven_day_login_num) {
                this.seven_day_login_num = seven_day_login_num;
            }

            public String getSeven_day_nologin_num() {
                return seven_day_nologin_num;
            }

            public void setSeven_day_nologin_num(String seven_day_nologin_num) {
                this.seven_day_nologin_num = seven_day_nologin_num;
            }

            public String getIncome() {
                return income;
            }

            public void setIncome(String income) {
                this.income = income;
            }
        }
    }
}
