package com.ozmobi.coupons.common.bean;

/**
 * Created by xhkj on 2019/7/4.
 */

public class ShareTextBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private String share_text;
        private String share_label;
        private String tkl_text;

        public void setShare_text(String share_text) {
            this.share_text = share_text;
        }

        public void setShare_label(String share_label) {
            this.share_label = share_label;
        }

        public void setTkl_text(String tkl_text) {
            this.tkl_text = tkl_text;
        }

        public String getShare_text() {
            return share_text;
        }

        public String getShare_label() {
            return share_label;
        }

        public String getTkl_text() {
            return tkl_text;
        }
    }
}
