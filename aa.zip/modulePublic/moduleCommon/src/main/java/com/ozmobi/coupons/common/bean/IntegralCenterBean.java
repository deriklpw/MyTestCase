package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/9/20.
 */

public class IntegralCenterBean {
    private int error;
    private String msg;
    private DataBean data;
    private int time;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public static class DataBean {
        private UserInfoBean userInfo;
        private RightBean right;
        private EarnPointsBean earnPoints;
        private List<ExchangePopularBean> exchangePopular;

        public UserInfoBean getUserInfo() {
            return userInfo;
        }

        public void setUserInfo(UserInfoBean userInfo) {
            this.userInfo = userInfo;
        }

        public RightBean getRight() {
            return right;
        }

        public void setRight(RightBean right) {
            this.right = right;
        }

        public EarnPointsBean getEarnPoints() {
            return earnPoints;
        }

        public void setEarnPoints(EarnPointsBean earnPoints) {
            this.earnPoints = earnPoints;
        }

        public List<ExchangePopularBean> getExchangePopular() {
            return exchangePopular;
        }

        public void setExchangePopular(List<ExchangePopularBean> exchangePopular) {
            this.exchangePopular = exchangePopular;
        }

        public static class UserInfoBean {
            private String level_icon;
            private String next_level;
            private String next_level_desc;
            private int upgrade_integral;
            private int current_integral;
            private List<String> user_level_desc;

            public String getLevel_icon() {
                return level_icon;
            }

            public void setLevel_icon(String level_icon) {
                this.level_icon = level_icon;
            }

            public String getNext_level() {
                return next_level;
            }

            public void setNext_level(String next_level) {
                this.next_level = next_level;
            }

            public String getNext_level_desc() {
                return next_level_desc;
            }

            public void setNext_level_desc(String next_level_desc) {
                this.next_level_desc = next_level_desc;
            }

            public int getUpgrade_integral() {
                return upgrade_integral;
            }

            public void setUpgrade_integral(int upgrade_integral) {
                this.upgrade_integral = upgrade_integral;
            }

            public int getCurrent_integral() {
                return current_integral;
            }

            public void setCurrent_integral(int current_integral) {
                this.current_integral = current_integral;
            }

            public List<String> getUser_level_desc() {
                return user_level_desc;
            }

            public void setUser_level_desc(List<String> user_level_desc) {
                this.user_level_desc = user_level_desc;
            }
        }

        public static class RightBean {
            private int integral;
            private List<RightsBean> rights;

            public int getIntegral() {
                return integral;
            }

            public void setIntegral(int integral) {
                this.integral = integral;
            }

            public List<RightsBean> getRights() {
                return rights;
            }

            public void setRights(List<RightsBean> rights) {
                this.rights = rights;
            }

            public static class RightsBean {
                private String icon;
                private String title;
                private String desc;

                public String getIcon() {
                    return icon;
                }

                public void setIcon(String icon) {
                    this.icon = icon;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getDesc() {
                    return desc;
                }

                public void setDesc(String desc) {
                    this.desc = desc;
                }
            }
        }

        public static class EarnPointsBean {
            private SignBean sign;
            private InviteBean invite;
            private ShareBean share;
            private InfoBean info;

            public SignBean getSign() {
                return sign;
            }

            public void setSign(SignBean sign) {
                this.sign = sign;
            }

            public InviteBean getInvite() {
                return invite;
            }

            public void setInvite(InviteBean invite) {
                this.invite = invite;
            }

            public ShareBean getShare() {
                return share;
            }

            public void setShare(ShareBean share) {
                this.share = share;
            }

            public InfoBean getInfo() {
                return info;
            }

            public void setInfo(InfoBean info) {
                this.info = info;
            }

            public static class SignBean {
                private int integral;
                private boolean checkin;

                public int getIntegral() {
                    return integral;
                }

                public void setIntegral(int integral) {
                    this.integral = integral;
                }

                public boolean isCheckin() {
                    return checkin;
                }

                public void setCheckin(boolean checkin) {
                    this.checkin = checkin;
                }
            }

            public static class InviteBean {
                private int max;
                private int current;
                private List<ActionsBean> actions;

                public int getMax() {
                    return max;
                }

                public void setMax(int max) {
                    this.max = max;
                }

                public int getCurrent() {
                    return current;
                }

                public void setCurrent(int current) {
                    this.current = current;
                }

                public List<ActionsBean> getActions() {
                    return actions;
                }

                public void setActions(List<ActionsBean> actions) {
                    this.actions = actions;
                }

                public static class ActionsBean {
                    private String name;
                    private int integral;
                    private String desc;

                    public String getName() {
                        return name;
                    }

                    public void setName(String name) {
                        this.name = name;
                    }

                    public int getIntegral() {
                        return integral;
                    }

                    public void setIntegral(int integral) {
                        this.integral = integral;
                    }

                    public String getDesc() {
                        return desc;
                    }

                    public void setDesc(String desc) {
                        this.desc = desc;
                    }
                }
            }

            public static class ShareBean {
                private int max;
                private int current;
                private List<ActionsBeanX> actions;

                public int getMax() {
                    return max;
                }

                public void setMax(int max) {
                    this.max = max;
                }

                public int getCurrent() {
                    return current;
                }

                public void setCurrent(int current) {
                    this.current = current;
                }

                public List<ActionsBeanX> getActions() {
                    return actions;
                }

                public void setActions(List<ActionsBeanX> actions) {
                    this.actions = actions;
                }

                public static class ActionsBeanX {
                    private String name;
                    private int integral;
                    private String desc;

                    public String getName() {
                        return name;
                    }

                    public void setName(String name) {
                        this.name = name;
                    }

                    public int getIntegral() {
                        return integral;
                    }

                    public void setIntegral(int integral) {
                        this.integral = integral;
                    }

                    public String getDesc() {
                        return desc;
                    }

                    public void setDesc(String desc) {
                        this.desc = desc;
                    }
                }
            }

            public static class InfoBean {
                private int max;
                private int current;
                private List<ActionsBeanXX> actions;

                public int getMax() {
                    return max;
                }

                public void setMax(int max) {
                    this.max = max;
                }

                public int getCurrent() {
                    return current;
                }

                public void setCurrent(int current) {
                    this.current = current;
                }

                public List<ActionsBeanXX> getActions() {
                    return actions;
                }

                public void setActions(List<ActionsBeanXX> actions) {
                    this.actions = actions;
                }

                public static class ActionsBeanXX {
                    private String name;
                    private int integral;

                    public String getName() {
                        return name;
                    }

                    public void setName(String name) {
                        this.name = name;
                    }

                    public int getIntegral() {
                        return integral;
                    }

                    public void setIntegral(int integral) {
                        this.integral = integral;
                    }
                }
            }
        }

        public static class ExchangePopularBean {
            private int id;
            private String title;
            private String icon;
            private int integral;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getIcon() {
                return icon;
            }

            public void setIcon(String icon) {
                this.icon = icon;
            }

            public int getIntegral() {
                return integral;
            }

            public void setIntegral(int integral) {
                this.integral = integral;
            }
        }
    }
}
