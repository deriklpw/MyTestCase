package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.CateBannerBean;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.data.source.OtherCategoryDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

public class OtherCategoryRepository implements OtherCategoryDataSource {

    private static final String TAG = "OtherCategoryRepository";

    @Override
    public Disposable getOtherCategoryHotGoods(@NonNull String categoryName, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            if (!TextUtils.isEmpty(sort)) {
                params.put("sort", sort);
            }
            params.put("title", categoryName);
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "hot post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        return ApiFactory.getYjlController().getOtherCategoryHotGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable getOtherCategoryGoods(@NonNull String categoryName, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            if (!TextUtils.isEmpty(sort)) {
                params.put("sort", sort);
            }
            params.put("title", categoryName);
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG,"getOtherCategoryGoods post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        return ApiFactory.getYjlController().getOtherCategoryGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable requestOtherBannerData(@NonNull String subCate, @NonNull Consumer<? super CateBannerBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSON.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();

            params.put("title", subCate);
            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG,"other banner post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<CateBannerBean> observable = ApiFactory.getYjlController().requestBannerUrls(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

}
