package com.ozmobi.coupons.common.network.api;

import com.alibaba.fastjson.JSONObject;

import io.reactivex.Observable;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Created by xhkj on 2019/5/23.
 */

/**
 * 均手动解析
 */
public interface AccountController {

    //查询手机号是否已注册
    @POST("api.php?m=user&p=mobileisregister")
    Observable<JSONObject> queryMobile(@Body RequestBody body);

    //请求验证码
    @POST("api.php?m=user&p=sendsmscode")
    Observable<JSONObject> requestMessageCode(@Body RequestBody body);

    //手机号注册
    @POST("api.php?m=user&p=mobileregister")
    Observable<JSONObject> registerMobile(@Body RequestBody body);

    //查询邀请码信息
    @POST("api.php?m=user&p=inviteinfo")
    Observable<JSONObject> queryInvitation(@Body RequestBody body);

    //密码登录
    @POST("api.php?m=user&p=mobilepwdlogin")
    Observable<JSONObject> loginWithPwd(@Body RequestBody body);

    //验证码登录
    @POST("api.php?m=user&p=mobilecodelogin")
    Observable<JSONObject> loginWithCode(@Body RequestBody body);

    //重置密码
    @POST("api.php?m=user&p=mobileresetpwd")
    Observable<JSONObject> resetPassword(@Body RequestBody body);

    //微信注册
    @POST("api.php?m=user&p=wxregister")
    Observable<JSONObject> registerWithWeChat(@Body RequestBody body);

    //微信登录
    @POST("api.php?m=user&p=wxlogin")
    Observable<JSONObject> loginWithWeChat(@Body RequestBody body);

    //更新上传用户信息
    @POST("api.php?m=user&p=updateuserinfo")
    Observable<JSONObject> updateUserInfo(@Body RequestBody body);

    //绑定上级邀请码
    @POST("api.php?m=user&p=bindinvite")
    Observable<JSONObject> bindParentInviteCode(@Body RequestBody body);

    //淘宝，网页授权
    @POST("api.php?m=taobao&p=oauthurl")
    Observable<JSONObject> getTaobaoAuthUrl(@Body RequestBody body);

    //淘宝解绑
    @POST("api.php?m=user&p=unbindtaobao")
    Observable<JSONObject> unbindTaoBaoAccount(@Body RequestBody body);

    //微信绑定
    @POST("api.php?m=user&p=bindwx")
    Observable<JSONObject> bindWeChatAccount(@Body RequestBody body);

    //微信解绑
    @POST("api.php?m=user&p=unbindwx")
    Observable<JSONObject> unbindWeChatAccount(@Body RequestBody body);

    //修改手机号
    @POST("api.php?m=user&p=altermobile")
    Observable<JSONObject> modifyMobile(@Body RequestBody body);

    //校验验证码
    @POST("api.php?m=user&p=checksmscode")
    Observable<JSONObject> checkMessageCode(@Body RequestBody body);

    //获取用户消息
    @POST("api.php?m=user&p=message")
    Observable<JSONObject> getUserMessage(@Body RequestBody body);

    //发送粉丝召回短信
    @POST("api.php?m=fans&p=sendsms")
    Observable<JSONObject> sendSmsToWakeupFans(@Body RequestBody body);

    //充值到短信余额
    @POST("api.php?m=fans&p=balancetopup")
    Observable<JSONObject> topUpBalance(@Body RequestBody body);

    //短信余额提现到券当家余额
    @POST("api.php?m=fans&p=smsmoneywithdraw")
    Observable<JSONObject> withdrawSmsMoney(@Body RequestBody body);

    //支付宝充值到短信余额
    @POST("api.php?m=alipay&p=smsmoneyorder")
    Observable<JSONObject> topUpBalanceWithAlipay(@Body RequestBody body);

    //一键登录
    @POST("api.php?m=user&p=oclogin")
    Observable<JSONObject> loginWithOneKeyMobile(@Body RequestBody body);
}
