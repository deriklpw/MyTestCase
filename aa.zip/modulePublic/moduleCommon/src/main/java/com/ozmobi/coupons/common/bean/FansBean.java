package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/5/27.
 */

public class FansBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private List<MyfansEntity> myfans;

        public void setMyfans(List<MyfansEntity> myfans) {
            this.myfans = myfans;
        }

        public List<MyfansEntity> getMyfans() {
            return myfans;
        }

        public class MyfansEntity {
            private String nick;
            private String icon;
            private String mobile;
            private String time;

            public void setNick(String nick) {
                this.nick = nick;
            }

            public void setIcon(String icon) {
                this.icon = icon;
            }

            public void setMobile(String mobile) {
                this.mobile = mobile;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getNick() {
                return nick;
            }

            public String getIcon() {
                return icon;
            }

            public String getMobile() {
                return mobile;
            }

            public String getTime() {
                return time;
            }
        }
    }
}
