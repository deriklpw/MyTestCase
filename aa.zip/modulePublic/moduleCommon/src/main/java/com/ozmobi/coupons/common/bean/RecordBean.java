package com.ozmobi.coupons.common.bean;

import java.util.List;

public class RecordBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {

        private List<RecordEntity> record;

        public void setRecord(List<RecordEntity> record) {
            this.record = record;
        }

        public List<RecordEntity> getRecord() {
            return record;
        }

        public class RecordEntity {
            private String amount;
            private String status_desc;
            private String time;
            private String order_id;
            private String status;

            public void setAmount(String amount) {
                this.amount = amount;
            }

            public void setStatus_desc(String status_desc) {
                this.status_desc = status_desc;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public void setOrder_id(String order_id) {
                this.order_id = order_id;
            }

            public void setStatus(String status) {
                this.status = status;
            }

            public String getAmount() {
                return amount;
            }

            public String getStatus_desc() {
                return status_desc;
            }

            public String getTime() {
                return time;
            }

            public String getOrder_id() {
                return order_id;
            }

            public String getStatus() {
                return status;
            }
        }
    }
}
