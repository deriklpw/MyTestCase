package com.ozmobi.coupons.common.ui.search;

import android.content.Context;
import android.support.design.widget.AppBarLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import com.jakewharton.rxbinding2.widget.RxTextView;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.BaseActivity;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.bean.QuerySugBean;
import com.ozmobi.coupons.common.ui.search.result.SearchResultFragment;
import com.ozmobi.coupons.common.ui.search.result.SearchResultPresenter;
import com.ozmobi.coupons.common.utils.ActivityUtils;
import com.ozmobi.coupons.base.utils.OnClickUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class SearchActivity extends BaseActivity implements SearchContract.View, View.OnClickListener, SearchFragment.SearchCallback, SearchSugFragment.SugCallback {

    private static final String TAG = "SearchActivity";
    //此页面，SearActivity作为View层，SearchFragment 和 SearchSugFragment作为其切换的两个View，不单独写Presenter

    private AppCompatEditText mEtSearch;

    private AppCompatImageView mSearchClear;

    private SearchContract.Presenter mPresenter;

    private ArrayList<String> mHistoryWords;

    private ArrayList<String> mHotWords;

    private InputMethodManager mInputManager;

    private Disposable mEtTextDisposable;

    @Override
    protected int getLayoutId() {
        return R.layout.common_activity_search;
    }

    @Override
    protected void onResume() {
        super.onResume();
        LogUtil.d(TAG, "onResume: ");
        //初始化后，输入为空，触发
        mEtTextDisposable = RxTextView.textChanges(mEtSearch)
                .debounce(200, TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<CharSequence>() {
                    @Override
                    public void accept(CharSequence charSequence) throws Exception {
                        String query = charSequence.toString();
                        if (!TextUtils.isEmpty(query)) {
                            mPresenter.query(query);
                        } else {
                            //初始化后，输入为空，触发
                            mPresenter.start();
                        }
                    }
                });
    }

    @Override
    protected void onPause() {
        super.onPause();
        LogUtil.d(TAG, "onPause: ");
        if (mEtTextDisposable != null) {
            mEtTextDisposable.dispose();
            mEtTextDisposable = null;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        LogUtil.d(TAG, "onStop: ");
        mPresenter.cancel();
    }

    @Override
    protected void initViews() {
        try {
            mInputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            mPresenter = new SearchPresenter();
            mPresenter.attach(this);

            AppBarLayout appBarLayout = findViewById(R.id.appbar);
            setAppBar(appBarLayout);

            AppCompatImageView ivBack = findViewById(R.id.iv_toolbar_icon_left);
            AppCompatTextView tvSearch = findViewById(R.id.tv_toolbar_icon_right);
            mSearchClear = findViewById(R.id.iv_search_input_clear);

            ivBack.setOnClickListener(this);
            tvSearch.setOnClickListener(this);
            mSearchClear.setOnClickListener(this);

            mEtSearch = findViewById(R.id.et_search);

            mEtSearch.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        AppCompatEditText view = (AppCompatEditText) v;
                        String input = view.getText().toString().trim();
                        if (!TextUtils.isEmpty(input)) {
                            mPresenter.query(input);
                        }
                    }
                }
            });

            mEtSearch.setOnEditorActionListener(new AppCompatTextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView textView, int args1, KeyEvent keyEvent) {
                    if (args1 == EditorInfo.IME_ACTION_SEARCH) {
                        String text = textView.getText().toString().trim();
                        searchText(text);
                    }
                    return false;
                }

            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.iv_toolbar_icon_left) {
            LogUtil.d(TAG, "iv_toolbar_icon_left clicked");
            finish();
        } else if (id == R.id.tv_toolbar_icon_right) {
            if (!OnClickUtils.isFastClick()) {
                LogUtil.d(TAG, "tv_toolbar_icon_right clicked");
                String text = mEtSearch.getText().toString().trim();
                searchText(text);
            }
        } else if (id == R.id.iv_search_input_clear) {
            LogUtil.d(TAG, "iv_search_input_clear clicked");
            mEtSearch.setText("");
        }
    }

    @Override
    public void onTagClicked(String tag) {
        showGoodsFragment(tag);
    }

    @Override
    public void onClearHistory() {
        mPresenter.clearHistory();
    }

    private void searchText(String text) {
        if (!TextUtils.isEmpty(text)) {
            showGoodsFragment(text);
        } else {
            toastMsg(getString(R.string.common_please_input_key_word_to_search));
        }
    }

    @Override
    public void onSugCallback(String query) {
        LogUtil.d(TAG, "sug clicked" + query);
        showGoodsFragment(query);
    }

    @Override
    public void showQuerySug(QuerySugBean queryBean) {
        LogUtil.d(TAG, "showQuerySug: ");
        if (mSearchClear.getVisibility() == View.INVISIBLE) {
            mSearchClear.setVisibility(View.VISIBLE);
        }

        if (mEtSearch.hasFocus() && !TextUtils.isEmpty(mEtSearch.getText())) {
            if (queryBean.getResult() != null && queryBean.getResult().size() > 0) {
                showSearchSugFragment(queryBean);
            } else {
                showSearchFragment();
            }
        }
    }

    @Override
    public void showHintWords(ArrayList<String> hotWords, ArrayList<String> historyWords) {
        LogUtil.d(TAG, "showHintWords: ");
        if (mSearchClear.getVisibility() != View.INVISIBLE) {
            mSearchClear.setVisibility(View.INVISIBLE);
        }
        mHotWords = hotWords;
        mHistoryWords = historyWords;
        if (historyWords != null) {
            Collections.reverse(mHistoryWords);
        }
        mEtSearch.requestFocus();
        if (mInputManager != null) {
            mInputManager.showSoftInput(mEtSearch, 0);
        }
        showSearchFragment();
    }

    private ArrayList<String> convertToList(QuerySugBean categoryBean) {
        ArrayList<String> listSug = new ArrayList<>();
        for (int i = 0; i < categoryBean.getResult().size(); i++) {
            listSug.add(categoryBean.getResult().get(i).get(0)); //第0个字段是名字
        }
        return listSug;
    }

    private void showSearchFragment() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fl_search_container);
        if (fragment != null) {
            if (fragment instanceof SearchFragment) {
                ((SearchFragment) fragment).updateHistory(mHistoryWords);
                LogUtil.d(TAG, "showSearchFragment: update" + ", history=" + mHistoryWords);
            } else {
                LogUtil.d(TAG, "showSearchFragment: replace, " + mHotWords + ", history=" + mHistoryWords);
                SearchFragment searchFragment = SearchFragment.newInstance(mHotWords, mHistoryWords);
                ActivityUtils.replaceFragmentInActivity(getSupportFragmentManager(), searchFragment, R.id.fl_search_container);
            }
        } else {
            LogUtil.d(TAG, "showSearchFragment: add, " + mHotWords + ", history" + mHistoryWords);
            SearchFragment searchFragment = SearchFragment.newInstance(mHotWords, mHistoryWords);
            ActivityUtils.addFragmentToActivity(getSupportFragmentManager(), searchFragment, R.id.fl_search_container);
        }
    }

    private void showSearchSugFragment(QuerySugBean queryBean) {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fl_search_container);
        if (fragment != null) {
            if (fragment instanceof SearchSugFragment) {
                LogUtil.d(TAG, "showSearchSugFragment: update");
                ((SearchSugFragment) fragment).updateSug(convertToList(queryBean));
            } else {
                LogUtil.d(TAG, "showSearchSugFragment: replace");
                SearchSugFragment sugFragment = SearchSugFragment.newInstance(convertToList(queryBean));
                ActivityUtils.replaceFragmentInActivity(getSupportFragmentManager(), sugFragment, R.id.fl_search_container);
            }
        } else {
            LogUtil.d(TAG, "showSearchSugFragment: add");
            SearchSugFragment sugFragment = SearchSugFragment.newInstance(convertToList(queryBean));
            ActivityUtils.addFragmentToActivity(getSupportFragmentManager(), sugFragment, R.id.fl_search_container);
        }
    }

    private void showGoodsFragment(String searchTag) {
        LogUtil.d(TAG, "showGoodsFragment: ");
        if (!TextUtils.isEmpty(searchTag)) {

            if (mInputManager != null) {
                mInputManager.hideSoftInputFromWindow(mEtSearch.getWindowToken(), 0);
            }

            mEtSearch.clearFocus();
            mEtSearch.setText(searchTag);
            mEtSearch.setSelection(searchTag.length());
            mPresenter.saveHistory(searchTag);
            mSearchClear.setVisibility(View.VISIBLE);

            SearchResultFragment searchResultFragment = SearchResultFragment.newInstance(searchTag);
            new SearchResultPresenter(searchResultFragment, searchTag);
            ActivityUtils.replaceFragmentInActivity(getSupportFragmentManager(), searchResultFragment, R.id.fl_search_container);
        }
    }

    @Override
    public void onBackPressed() {
        //如果当前是商品显示页面，则返回搜索页，否则退出
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fl_search_container);
        if (fragment instanceof SearchResultFragment) {
            mPresenter.start();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LogUtil.d(TAG, "onDestroy: ");

        if (mPresenter != null) {
            mPresenter.detach();
            mPresenter.destroy();
            mPresenter = null;
        }

        mHistoryWords = null;
        mHotWords = null;
        mInputManager = null;
        if (mEtSearch != null) {
            mEtSearch.clearFocus();
            mEtSearch = null;
        }
    }
}
