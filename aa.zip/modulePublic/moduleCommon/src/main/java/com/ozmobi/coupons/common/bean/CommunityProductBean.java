package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/6/21.
 */

/**
 * 社区中商品，多了type和finished属性
 */
public class CommunityProductBean {
    private String original_price;
    private String product_url;
    private String plat_type;
    private long num_iid;
    private String title;
    private String type;
    private int shop_score;
    private String short_title;
    private double coupon_rate;
    private String shop_title;
    private String coupon_price;
    private List<String> small_images;
    private String up_commission_fee;
    private String share;
    private String commission_fee;
    private int sales_volume;
    private String share_fee;
    private String end_time;
    private int finished;
    private String pict_url;
    private String start_time;
    private String coupon_click_url;
    private int total_amount;
    private String item_url;
    private double commission_rate;
    private String current_price;
    private String reserve_price;
    private String coupon_start_time;
    private String coupon_end_time;

    public void setOriginal_price(String original_price) {
        this.original_price = original_price;
    }

    public void setProduct_url(String product_url) {
        this.product_url = product_url;
    }

    public void setPlat_type(String plat_type) {
        this.plat_type = plat_type;
    }

    public void setNum_iid(long num_iid) {
        this.num_iid = num_iid;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setShop_score(int shop_score) {
        this.shop_score = shop_score;
    }

    public void setShort_title(String short_title) {
        this.short_title = short_title;
    }

    public void setCoupon_rate(double coupon_rate) {
        this.coupon_rate = coupon_rate;
    }

    public void setShop_title(String shop_title) {
        this.shop_title = shop_title;
    }

    public void setCoupon_price(String coupon_price) {
        this.coupon_price = coupon_price;
    }

    public void setSmall_images(List<String> small_images) {
        this.small_images = small_images;
    }

    public void setUp_commission_fee(String up_commission_fee) {
        this.up_commission_fee = up_commission_fee;
    }

    public void setShare(String share) {
        this.share = share;
    }

    public void setCommission_fee(String commission_fee) {
        this.commission_fee = commission_fee;
    }

    public void setSales_volume(int sales_volume) {
        this.sales_volume = sales_volume;
    }

    public void setShare_fee(String share_fee) {
        this.share_fee = share_fee;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public void setFinished(int finished) {
        this.finished = finished;
    }

    public void setPict_url(String pict_url) {
        this.pict_url = pict_url;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public void setCoupon_click_url(String coupon_click_url) {
        this.coupon_click_url = coupon_click_url;
    }

    public void setTotal_amount(int total_amount) {
        this.total_amount = total_amount;
    }

    public void setItem_url(String item_url) {
        this.item_url = item_url;
    }

    public void setCommission_rate(double commission_rate) {
        this.commission_rate = commission_rate;
    }

    public void setCurrent_price(String current_price) {
        this.current_price = current_price;
    }

    public void setReserve_price(String reserve_price) {
        this.reserve_price = reserve_price;
    }

    public void setCoupon_start_time(String coupon_start_time) {
        this.coupon_start_time = coupon_start_time;
    }

    public void setCoupon_end_time(String coupon_end_time) {
        this.coupon_end_time = coupon_end_time;
    }

    public String getOriginal_price() {
        return original_price;
    }

    public String getProduct_url() {
        return product_url;
    }

    public String getPlat_type() {
        return plat_type;
    }

    public long getNum_iid() {
        return num_iid;
    }

    public String getTitle() {
        return title;
    }

    public String getType() {
        return type;
    }

    public int getShop_score() {
        return shop_score;
    }

    public String getShort_title() {
        return short_title;
    }

    public double getCoupon_rate() {
        return coupon_rate;
    }

    public String getShop_title() {
        return shop_title;
    }

    public String getCoupon_price() {
        return coupon_price;
    }

    public List<String> getSmall_images() {
        return small_images;
    }

    public String getUp_commission_fee() {
        return up_commission_fee;
    }

    public String getShare() {
        return share;
    }

    public String getCommission_fee() {
        return commission_fee;
    }

    public int getSales_volume() {
        return sales_volume;
    }

    public String getShare_fee() {
        return share_fee;
    }

    public String getEnd_time() {
        return end_time;
    }

    public int getFinished() {
        return finished;
    }

    public String getPict_url() {
        return pict_url;
    }

    public String getStart_time() {
        return start_time;
    }

    public String getCoupon_click_url() {
        return coupon_click_url;
    }

    public int getTotal_amount() {
        return total_amount;
    }

    public String getItem_url() {
        return item_url;
    }

    public double getCommission_rate() {
        return commission_rate;
    }

    public String getCurrent_price() {
        return current_price;
    }

    public String getReserve_price() {
        return reserve_price;
    }

    public String getCoupon_start_time() {
        return coupon_start_time;
    }

    public String getCoupon_end_time() {
        return coupon_end_time;
    }
}
