package com.ozmobi.coupons.common.bean;

/**
 * Created by xhkj on 2019/7/2.
 */

public class ContactQrBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private ServiceEntity service;

        public void setService(ServiceEntity service) {
            this.service = service;
        }

        public ServiceEntity getService() {
            return service;
        }

        public class ServiceEntity {
            private String weixin;
            private String weixinQrCode;

            public void setWeixin(String weixin) {
                this.weixin = weixin;
            }

            public void setWeixinQrCode(String weixinQrCode) {
                this.weixinQrCode = weixinQrCode;
            }

            public String getWeixin() {
                return weixin;
            }

            public String getWeixinQrCode() {
                return weixinQrCode;
            }
        }
    }
}
