package com.ozmobi.coupons.common.data.bean;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.DrawableRes;

/**
 * Created by xhkj on 2019/7/15.
 */

public class MineItemBean implements Parcelable {
    private String name;

    @DrawableRes
    private int icon;

    private boolean dividerEnable;

    public MineItemBean(String name, int icon, boolean dividerEnable) {
        this.name = name;
        this.icon = icon;
        this.dividerEnable = dividerEnable;
    }

    protected MineItemBean(Parcel in) {
        name = in.readString();
        icon = in.readInt();
        dividerEnable = in.readByte() != 0;
    }

    public static final Creator<MineItemBean> CREATOR = new Creator<MineItemBean>() {
        @Override
        public MineItemBean createFromParcel(Parcel in) {
            return new MineItemBean(in);
        }

        @Override
        public MineItemBean[] newArray(int size) {
            return new MineItemBean[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeInt(icon);
        dest.writeByte((byte) (dividerEnable ? 1 : 0));
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public boolean isDividerEnable() {
        return dividerEnable;
    }

    public void setDividerEnable(boolean dividerEnable) {
        this.dividerEnable = dividerEnable;
    }
}
