package com.ozmobi.coupons.common.ui.goodsdetails;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.Group;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.ozmobi.coupons.baichuan.AlibaichManager;
import com.ozmobi.coupons.base.GlobalAppInfo;
import com.ozmobi.coupons.base.CustomIntents;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.BaseActivity;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.adapter.LoadMoreWrapper;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.bean.CommonProductsEntity;
import com.ozmobi.coupons.common.bean.GoodsBean;
import com.ozmobi.coupons.common.bean.GoodsDetailsPageBean;
import com.ozmobi.coupons.baichuan.CustomAliLoginCallback;
import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.base.manager.UserInfoManager;
import com.ozmobi.coupons.common.ui.goodsdetails.share.ShareGoodsActivity;
import com.ozmobi.coupons.common.ui.goodsdetails.shop.ShopCouponsActivity;
import com.ozmobi.coupons.common.ui.imageviewer.PictureViewerActivity;
import com.ozmobi.coupons.common.ui.webpage.UrlDetailPageActivity;
import com.ozmobi.coupons.common.utils.BannerGlideImageLoader;
import com.ozmobi.coupons.common.utils.ClipBoardUtil;
import com.ozmobi.coupons.common.utils.GlideUtils;
import com.ozmobi.coupons.common.utils.GoodsConvertUtil;
import com.ozmobi.coupons.common.utils.LinearItemDivider;
import com.ozmobi.coupons.base.utils.IconTextUtil;
import com.ozmobi.coupons.base.utils.NetworkUtil;
import com.ozmobi.coupons.base.utils.NumberUtils;
import com.ozmobi.coupons.base.utils.TimeUtil;
import com.ozmobi.coupons.common.views.CustomLineTextView;
import com.ozmobi.coupons.common.views.CustomRefreshLayout;
import com.ozmobi.coupons.common.views.CustomToast;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.Transformer;

import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.ozmobi.coupons.baichuan.AlibaichManager.login;

//import com.ozmobi.coupons.common.MainActivity;
//import com.ozmobi.coupons.common.account.login.LoginActivity;

public class GoodsDetailsActivity extends BaseActivity implements GoodsDetailsContract.View, SwipeRefreshLayout.OnRefreshListener {

    private static final String TAG = "GoodsDetailsActivity";

    private static final String KEY_GOODS_DETAIL = "key_goods_detail";

    //商品标题，价格区域
    private static final int CONSTANT_GOODS_INFO_TYPE = 0;

    //商店信息区域
    private static final int CONSTANT_SHOP_INFO_TYPE = 1;

    //商品图片详情区域
    private static final int CONSTANT_IMAGES_INFO_TYPE = 2;

    //为你推荐头部
    private static final int CONSTANT_RECOMMEND_HEAD_TYPE = 3;

    private static final int CONSTANT_SPECIAL_TYPE_NUM = 4;

    private GoodsBean mGoodsBean;

    private boolean isCollected = false;

    private CustomToast mToast;

    private GoodsDetailsContract.Presenter mPresenter;

    private TextView mTvFavorite;

    private List<String> mListGoodsImages;

    private List<CommonProductsEntity> mListRelateGoods;

    private boolean mHasCoupon = false;

    private Banner mBanner;

    private GoodsDetailsPageBean.DataEntity.ShopEntity mShopEntity;

    private LoadMoreWrapper mAdapter;

    private CustomRefreshLayout mRefreshView;

    private AppBarLayout mAppBarLayout;

    private Toolbar mToolbar;

    private boolean isCollapsed;

    private String mNumIId;

    @Override
    protected int getLayoutId() {
        return R.layout.common_activity_goods_details;
    }

    @Override
    protected void initViews() {
        try {
            initToolbar();
            mListGoodsImages = new ArrayList<>();
            mListRelateGoods = new ArrayList<>();
            mPresenter = new GoodsDetailsPresenter();
            mPresenter.attach(this);
            //先获取传递过来的数据，用于赋值给view
            mGoodsBean = (GoodsBean) getIntent().getSerializableExtra(KEY_GOODS_DETAIL);
            mNumIId = String.valueOf(mGoodsBean.getGoodsId());
        } catch (Exception e) {
            e.printStackTrace();
        }

        mRefreshView = findViewById(R.id.swipe_refresh);
        mRefreshView.setOnRefreshListener(this);

        CollapsingToolbarLayout collapsingToolbarLayout = findViewById(R.id.ctl_collapse_layout);

        mBanner = findViewById(R.id.banner_goods_details);

        RecyclerView recyclerViewGoodsDetails = findViewById(R.id.recycler_view_goods_details);

        TextView tvHomePage = findViewById(R.id.tv_goods_details_home_page);

        mTvFavorite = findViewById(R.id.tv_goods_details_favorite);

        //分享区域点击事件
        ViewGroup llShare = findViewById(R.id.ll_goods_details_share);

        TextView tvShareLabel = findViewById(R.id.tv_goods_details_share_label);

        //分享赚为0时，设置gone
        Group groupShare = findViewById(R.id.group_goods_details_share);

        //领券区域点击事件
        ViewGroup llBuyGet = findViewById(R.id.ll_goods_details_buy_or_get);

        TextView tvBuyGetLabel = findViewById(R.id.tv_goods_details_buy_or_get_label);

        //没有券时，设置gone
        Group groupBuyGet = findViewById(R.id.group_goods_details_buy_or_get);

        TextView tvCouponValue = findViewById(R.id.tv_goods_details_buy_or_get_value);

        TextView tvShareEarn = findViewById(R.id.tv_goods_details_share_value);

        FloatingActionButton fab = findViewById(R.id.fab_top_back);

        mToast = new CustomToast(GoodsDetailsActivity.this);

        try {
            isCollapsed = false;
            mAppBarLayout.addOnOffsetChangedListener((appBarLayout, verticalOffset) -> {
                LogUtil.d(TAG, "onOffsetChanged: " + verticalOffset);

                if (mRefreshView == null) {
                    return;
                }

                if (verticalOffset == 0) {
                    mRefreshView.setEnabled(true);
                    return;
                }

                //解决滑动事件冲突问题
                mRefreshView.setEnabled(false);

                //剩余距离小于等于toolBar和statusBar的高度和，视为已经折叠
                int offSet = (mAppBarLayout.getHeight() + verticalOffset);
                boolean isCollap = offSet <= (mToolbar.getHeight() + GlobalAppInfo.statusHeight);
                if (isCollapsed != isCollap) {
                    isCollapsed = isCollap;
                    setAppBarTheme(isCollapsed);
                }
            });

            initBanner();

            recyclerViewGoodsDetails.setLayoutManager(new LinearLayoutManager(this));
            int dividerSize = getResources().getDimensionPixelSize(R.dimen.common_dimen_8d);
            LinearItemDivider linearItemDivider = new LinearItemDivider(dividerSize, Color.WHITE, true);
            linearItemDivider.setExcludePositions(new int[]{0, 1, 2});
            linearItemDivider.setDividersWidth(dividerSize, dividerSize, dividerSize, dividerSize);
            recyclerViewGoodsDetails.addItemDecoration(linearItemDivider);

            GoodsDetailsAdapter goodsDetailsAdapter = new GoodsDetailsAdapter();

            mAdapter = new LoadMoreWrapper(goodsDetailsAdapter);
            recyclerViewGoodsDetails.setItemAnimator(new DefaultItemAnimator());
            recyclerViewGoodsDetails.setAdapter(mAdapter);

            recyclerViewGoodsDetails.addOnScrollListener(new RecyclerView.OnScrollListener() {

                @Override
                public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                    if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                        LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
                        int position = linearLayoutManager.findFirstVisibleItemPosition();
                        if (position == 0) {
                            fab.hide();
                        } else {
                            fab.show();
                        }
                    }

                    super.onScrollStateChanged(recyclerView, newState);
                }
            });

            llBuyGet.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    LogUtil.d(TAG, "onSingleClick: but get");

                    if (UserInfoManager.getInstance().isLogin()) {
                        if (AlibaichManager.isTaobaoLogin()) {

                            mPresenter.getTaobaoAuthUrl(authUrl -> {
                                if (!TextUtils.isEmpty(authUrl)) {
                                    //打开授权页
                                    UrlDetailPageActivity.startForUrlDetail(GoodsDetailsActivity.this, getString(R.string.common_application_auth), authUrl, UrlDetailPageActivity.URL_TB_AUTH);
                                } else {
                                    //打开领券或者跳淘宝购买
                                    String urlTaobao;
                                    if (mHasCoupon) {
                                        //打开券详情
                                        urlTaobao = mGoodsBean.getCouponUrl();
                                        mPresenter.addCouponsGoods(mGoodsBean);
                                    } else {
                                        //打开百川商品详情，也可以使用itemId打开
                                        urlTaobao = mGoodsBean.getGoodsUrl();
                                    }
                                    AlibaichManager.showUrlPage(GoodsDetailsActivity.this, urlTaobao);
                                }
                            });
                        } else {
                            login(new CustomAliLoginCallback(mLoginCallbackWrf));
                        }
                    } else {
//                        startActivity(new Intent(GoodsDetailsActivity.this, LoginActivity.class));
                        startLoginUI();
                    }
                }
            });

            if (!TextUtils.isEmpty(mGoodsBean.getShareFree())) {
                double shareFree = Double.valueOf(mGoodsBean.getShareFree());
                if (shareFree - 0.001 > 0) {
                    //设置为分享赚
                    tvShareLabel.setText(getString(R.string.common_share_earn));
                    //设置分享赚额度
                    tvShareEarn.setText(mGoodsBean.getShareFree());

                } else {
                    //设置为马上分享
                    tvShareLabel.setText(getString(R.string.common_share_now));
                    //隐藏分享赚额度区域
                    groupShare.setVisibility(View.GONE);
                }

            } else {
                groupShare.setVisibility(View.GONE);
            }

            if (!TextUtils.isEmpty(mGoodsBean.getCouponUrl())) {
                //设置为领券
                tvBuyGetLabel.setText(getString(R.string.common_get_coupon));
                //设置券额
                tvCouponValue.setText(mGoodsBean.getCouponValue());
                mHasCoupon = true;
            } else {
                //设置为立即购买
                tvBuyGetLabel.setText(getString(R.string.common_buy_now));
                mHasCoupon = false;
                //隐藏券额区域
                groupBuyGet.setVisibility(View.GONE);
            }

            tvHomePage.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    LogUtil.d(TAG, "onSingleClick: home");
                    finish();
//                    startActivity(new Intent(GoodsDetailsActivity.this, MainActivity.class));
                    Intent intent = new Intent();
                    intent.putExtra("key_current_tab_selected", 0);
                    String action = getPackageName() + CustomIntents.INTENT_ACTION_START_MAIN_SUFFIX;
                    intent.setAction(action);
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivity(intent);
                    }
                }
            });

            llShare.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    LogUtil.d(TAG, "onSingleClick: share");

                    if (UserInfoManager.getInstance().isLogin()) {
                        if (AlibaichManager.isTaobaoLogin()) {
                            //检测是否有淘宝分享授权
                            mPresenter.getTaobaoAuthUrl(url -> {
                                if (!TextUtils.isEmpty(url)) {
                                    //打开授权页
                                    UrlDetailPageActivity.startForUrlDetail(GoodsDetailsActivity.this, getString(R.string.common_application_auth), url, UrlDetailPageActivity.URL_TB_AUTH);
                                } else {
                                    //打开分享页
                                    ShareGoodsActivity.startForShare(GoodsDetailsActivity.this, mGoodsBean);
                                }
                            });
                        } else {
                            login(new CustomAliLoginCallback(mLoginCallbackWrf));
                        }
                    } else {
//                        startActivity(new Intent(GoodsDetailsActivity.this, LoginActivity.class));
                        startLoginUI();
                    }
                }
            });

            mTvFavorite.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    LogUtil.d(TAG, "onSingleClick: favorite");
                    if (UserInfoManager.getInstance().isLogin()) {
                        if (isCollected) {
                            mPresenter.deleteFavoriteGoods(String.valueOf(mGoodsBean.getGoodsId()));
                        } else {
                            mPresenter.addFavoriteGoods(mGoodsBean);
                        }
                        mTvFavorite.setEnabled(false);
                    } else {
//                        startActivity(new Intent(GoodsDetailsActivity.this, LoginActivity.class));
                        startLoginUI();
                    }
                }
            });

            fab.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    recyclerViewGoodsDetails.scrollToPosition(0);
                    mAppBarLayout.setExpanded(true);
                    fab.hide();
                }
            });

            //请求数据
            if (UserInfoManager.getInstance().isLogin()) {
                mPresenter.queryCollectState(mNumIId);
            }

            mPresenter.getGoodsDetailsImages(mNumIId, mGoodsBean.getPlatType());
            mPresenter.getRelateGoods(mNumIId);

            //获取当前时间
            mGoodsBean.setBrowserTime(TimeUtil.getCurTimeLong());
            mPresenter.addHistoryGoods(mGoodsBean);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setAppBarTheme(boolean isCollapse) {
        ActionBar ab = getSupportActionBar();
        if (isCollapse) {
            //折叠时，背景白色
            if (ab != null) {
                ab.setHomeAsUpIndicator(R.mipmap.common_ic_back_black);
            }

        } else {
            if (ab != null) {
                ab.setHomeAsUpIndicator(R.mipmap.common_ic_goods_details_back);
            }
        }
    }

    private void startLoginUI() {
        Intent intent = new Intent();
        String action = getPackageName() + CustomIntents.INTENT_ACTION_START_LOGIN_SUFFIX;
        intent.setAction(action);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
//        mBanner.stopAutoPlay();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        mBanner.startAutoPlay();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mPresenter.cancel();
    }

    private void initBanner() {
        try {
            //设置banner样式
            mBanner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);
            //设置图片加载器
            mBanner.setImageLoader(new BannerGlideImageLoader());

            ArrayList<String> listImages = new ArrayList<>();

            listImages.add(mGoodsBean.getIconUrl());

            if (mGoodsBean != null && mGoodsBean.getSmallImages() != null) {
                listImages.addAll(mGoodsBean.getSmallImages());
            }

            mBanner.setImages(listImages);
            //设置banner动画效果
            mBanner.setBannerAnimation(Transformer.Default);
            //设置标题集合（当banner样式有显示title时）
//            bannerHolder.banner.setBannerTitles(titles);
            //设置自动轮播，默认为true
            mBanner.isAutoPlay(false);
            //设置轮播时间
//            bannerHolder.banner.setDelayTime(3500);
            //设置指示器位置（当banner模式中有指示器时）
            mBanner.setIndicatorGravity(BannerConfig.CENTER);
            mBanner.setOnBannerListener(position -> {
                PictureViewerActivity.startPictureViewerActivityUrl(GoodsDetailsActivity.this, listImages, position);
            });

            //banner设置方法全部调用完毕时最后调用
            mBanner.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private SoftReference<AlibaichManager.Callback> mLoginCallbackWrf = new SoftReference<>(new AlibaichManager.Callback() {
        @Override
        public void onSuccess(int loginResult, String openId, String userNick) {
            //淘宝授权成功，自动开始网页应用授权
            if (mPresenter != null) {
                mPresenter.getTaobaoAuthUrl(url -> {
                    if (!TextUtils.isEmpty(url)) {
                        //打开授权页
                        UrlDetailPageActivity.startForUrlDetail(GoodsDetailsActivity.this, getString(R.string.common_application_auth), url, UrlDetailPageActivity.URL_TB_AUTH);
                    }
                });
            }
        }

        @Override
        public void onFailure(int i, String s) {

        }
    });

    private void initToolbar() {
        mAppBarLayout = findViewById(R.id.appbar);
        mToolbar = findViewById(R.id.toolbar);
        TextView tvTitle = findViewById(R.id.tv_toolbar_title);
        setAppBarAndToolbar(mAppBarLayout, mToolbar, tvTitle);
        setAppbarToolbarBlack(true);
    }

    private void updateFavoriteBackground(boolean isCollected) {
        Drawable top;
        if (isCollected) {
            top = getResources().getDrawable(R.mipmap.common_ic_goods_favorite_collected);

        } else {
            top = getResources().getDrawable(R.mipmap.common_ic_goods_favorite_uncollected);
        }
        mTvFavorite.setCompoundDrawablesWithIntrinsicBounds(null, top, null, null);
    }

    public static void startForGoodDetail(Context context, GoodsBean goodsBean) {
        if (context != null && goodsBean != null) {
            Intent intent = new Intent(context, GoodsDetailsActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable(KEY_GOODS_DETAIL, goodsBean);
            intent.putExtras(bundle);
            context.startActivity(intent);
        }
    }

    @Override
    public void setCollectState(boolean collectState) {
        isCollected = collectState;
        updateFavoriteBackground(collectState);
    }

    @Override
    public void showCollectFavorite(boolean result) {
        //true,收藏成功，false取消收藏
        if (mToast != null) {
            if (result) {
                isCollected = true;
                mToast.showAddSuccess();
            } else {
                isCollected = false;
                mToast.showCancel();
            }
        }
        updateFavoriteBackground(result);
        mTvFavorite.setEnabled(true);
    }

    @Override
    public void setGoodsDetailsPageBean(GoodsDetailsPageBean goodsDetailsPageBean) {
        if (goodsDetailsPageBean != null && goodsDetailsPageBean.getData() != null) {
            mShopEntity = null;
            mShopEntity = goodsDetailsPageBean.getData().getShop();

            if (goodsDetailsPageBean.getData().getDetail_images() != null && goodsDetailsPageBean.getData().getDetail_images().size() > 0) {
                mListGoodsImages.clear();
                mListGoodsImages.addAll(goodsDetailsPageBean.getData().getDetail_images());
                LogUtil.d(TAG, "setGoodsDetailsPageBean: " + mListGoodsImages.size());
            }
        }
        mAdapter.setLoadState(LoadMoreWrapper.LOADING_NO_MORE);
    }

    @Override
    public void showRelateGoods(CommonGoodsBean commonGoodsBean) {
        if (commonGoodsBean != null
                && commonGoodsBean.getData() != null
                && commonGoodsBean.getData().getProducts() != null
                && commonGoodsBean.getData().getProducts().size() > 0) {
            mListRelateGoods.clear();
            mListRelateGoods.addAll(commonGoodsBean.getData().getProducts());
            LogUtil.d(TAG, "showRelateGoods: " + mListRelateGoods.size());
        }
        mAdapter.setLoadState(LoadMoreWrapper.LOADING_NO_MORE);
    }

    @Override
    public void setShopCouponsGoods(CommonGoodsBean commonGoodsBean) {
        if (commonGoodsBean != null
                && commonGoodsBean.getData() != null
                && commonGoodsBean.getData().getProducts() != null
                && commonGoodsBean.getData().getProducts().size() > 0) {
            if (mShopEntity != null) {
                ShopCouponsActivity.startForShopCoupons(GoodsDetailsActivity.this, mShopEntity.getName());
            }
        } else {
            toastMsg(getString(R.string.common_query_no_shop_coupons_goods));
        }
    }

    @Override
    public void setRefresh(boolean enable) {
        mRefreshView.setRefreshing(enable);
    }

    @Override
    public void onRefresh() {
        if (mGoodsBean != null) {
            if (UserInfoManager.getInstance().isLogin()) {
                mPresenter.queryCollectState(mNumIId);
            }

            mPresenter.getGoodsDetailsImages(mNumIId, mGoodsBean.getPlatType());
            mPresenter.getRelateGoods(mNumIId);
        }
    }

    public class GoodsDetailsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            LogUtil.d(TAG, "onCreateViewHolder: type=" + viewType);
            switch (viewType) {
                case CONSTANT_GOODS_INFO_TYPE:
                    view = getLayoutInflater().inflate(R.layout.common_adapter_item_goods_details_goods_info, parent, false);
                    return new GoodsInfoHolder(view);

                case CONSTANT_SHOP_INFO_TYPE:
                    view = getLayoutInflater().inflate(R.layout.common_adapter_item_goods_details_shop_info, parent, false);
                    return new ShopInfoHolder(view);

                case CONSTANT_IMAGES_INFO_TYPE:
                    view = getLayoutInflater().inflate(R.layout.common_adapter_item_goods_details_images, parent, false);
                    return new ImagesInfoHolder(view);

                case CONSTANT_RECOMMEND_HEAD_TYPE:
                    view = getLayoutInflater().inflate(R.layout.common_adapter_item_goods_details_relate_head, parent, false);
                    return new RelateHeadHolder(view);

                default:
                    view = getLayoutInflater().inflate(R.layout.common_adapter_item_common_goods_list, parent, false);
                    return new GoodsListHolder(view);
            }
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
            LogUtil.d(TAG, "onCreateViewHolder: bind position=" + position);
            switch (position) {
                case 0:
                    if (viewHolder instanceof GoodsInfoHolder) {
                        GoodsInfoHolder holder = (GoodsInfoHolder) viewHolder;
                        // data信息从上一页传入，在GoodsBean中
                        bindGoodsInfo(holder, mGoodsBean);
                    }
                    break;
                case 1:
                    if (viewHolder instanceof ShopInfoHolder) {
                        //数据启动本activity时请求，需刷新
                        ShopInfoHolder holder = (ShopInfoHolder) viewHolder;
                        bindShopInfo(holder, mShopEntity);
                    }
                    break;
                case 2:
                    if (viewHolder instanceof ImagesInfoHolder) {
                        ImagesInfoHolder holder = (ImagesInfoHolder) viewHolder;
                        bindImagesInfo(holder, mListGoodsImages);
                    }
                    break;
                case 3:
                    if (viewHolder instanceof RelateHeadHolder) {
                        //无数据区域
                    }
                    break;
                default:
                    if (viewHolder instanceof GoodsListHolder) {
                        GoodsListHolder holder = (GoodsListHolder) viewHolder;
                        bindRelateGoodsData(holder, position - CONSTANT_SPECIAL_TYPE_NUM);//减除特殊项
                    }
            }

        }

        private void bindImagesInfo(ImagesInfoHolder holder, List<String> images) {
            //nothing
        }

        private void bindShopInfo(ShopInfoHolder holder, GoodsDetailsPageBean.DataEntity.ShopEntity shopEntity) {
            try {
                if (shopEntity == null) {
                    return;
                }

                if (!TextUtils.isEmpty(shopEntity.getName())) {
                    ViewGroup.LayoutParams layoutParams = holder.vShopContainer.getLayoutParams();
                    layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                    holder.vShopContainer.setLayoutParams(layoutParams);
                } else {
                    return;
                }

                GlideUtils.initImageWithFileCache(shopEntity.getIcon(), R.mipmap.common_ic_image_place_holder, holder.ivShopIcon);
                holder.tvShopName.setText(shopEntity.getName());

                //第0个是宝贝描述
                GoodsDetailsPageBean.DataEntity.ShopEntity.EvaluatesEntity evaluatesDescription = shopEntity.getEvaluates().get(0);
                //第一个是卖家服务
                GoodsDetailsPageBean.DataEntity.ShopEntity.EvaluatesEntity evaluatesSeller = shopEntity.getEvaluates().get(1);
                //第二个是物流服务
                GoodsDetailsPageBean.DataEntity.ShopEntity.EvaluatesEntity evaluatesLogistics = shopEntity.getEvaluates().get(2);

                holder.tvDescriptionScore.setText(evaluatesDescription.getScore());
                holder.tvDescriptionLevel.setText(evaluatesDescription.getLevelText());

                holder.tvSellerScore.setText(evaluatesSeller.getScore());
                holder.tvSellerLevel.setText(evaluatesSeller.getLevelText());

                holder.tvLogisticsScore.setText(evaluatesLogistics.getScore());
                holder.tvLogisticsLevel.setText(evaluatesLogistics.getLevelText());

                //设置色号
                int descriptionTextColor;
                int descriptionBackgroundColor;

                int sellerTextColor;
                int sellerBackgroundColor;

                int logisticsTextColor;
                int logisticsBackgroundColor;

                if ("tmall".equals(mGoodsBean.getPlatType())) {
                    descriptionTextColor = Color.parseColor(evaluatesDescription.getTmallLevelTextColor());
                    descriptionBackgroundColor = Color.parseColor(evaluatesDescription.getTmallLevelBackgroundColor());

                    sellerTextColor = Color.parseColor(evaluatesSeller.getTmallLevelTextColor());
                    sellerBackgroundColor = Color.parseColor(evaluatesSeller.getTmallLevelBackgroundColor());

                    logisticsTextColor = Color.parseColor(evaluatesLogistics.getTmallLevelTextColor());
                    logisticsBackgroundColor = Color.parseColor(evaluatesLogistics.getTmallLevelBackgroundColor());

                } else {
                    descriptionTextColor = Color.parseColor(evaluatesDescription.getLevelTextColor());
                    descriptionBackgroundColor = Color.parseColor(evaluatesDescription.getLevelBackgroundColor());

                    sellerTextColor = Color.parseColor(evaluatesSeller.getLevelTextColor());
                    sellerBackgroundColor = Color.parseColor(evaluatesSeller.getLevelBackgroundColor());

                    logisticsTextColor = Color.parseColor(evaluatesLogistics.getLevelTextColor());
                    logisticsBackgroundColor = Color.parseColor(evaluatesLogistics.getLevelBackgroundColor());
                }

                holder.tvDescriptionTitle.setText(evaluatesDescription.getTitle());
                holder.tvDescriptionScore.setTextColor(descriptionTextColor);
                holder.tvDescriptionLevel.setTextColor(descriptionTextColor);
                holder.tvDescriptionLevel.setBackgroundColor(descriptionBackgroundColor);

                holder.tvSellerTitle.setText(evaluatesSeller.getTitle());
                holder.tvSellerScore.setTextColor(sellerTextColor);
                holder.tvSellerLevel.setTextColor(sellerTextColor);
                holder.tvSellerLevel.setBackgroundColor(sellerBackgroundColor);

                holder.tvLogisticsTitle.setText(evaluatesLogistics.getTitle());
                holder.tvLogisticsScore.setTextColor(logisticsTextColor);
                holder.tvLogisticsLevel.setTextColor(logisticsTextColor);
                holder.tvLogisticsLevel.setBackgroundColor(logisticsBackgroundColor);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void bindGoodsInfo(GoodsInfoHolder holder, GoodsBean goodsBean) {
            try {
                if (goodsBean == null) {
                    return;
                }

                if (!TextUtils.isEmpty(goodsBean.getCouponValue())) {
                    float couponValue = Float.valueOf(goodsBean.getCouponValue());
                    if (couponValue - 0.001 > 0) {
                        holder.tvCurrentPriceLabel.setText(getString(R.string.common_price_after_coupon_label));
                        holder.clvOriginPrice.setVisibility(View.VISIBLE);
                    } else {
                        holder.tvCurrentPriceLabel.setText(getString(R.string.common_money_symbol));
                        holder.clvOriginPrice.setVisibility(View.GONE);
                    }
                } else {
                    holder.tvCurrentPriceLabel.setText(getString(R.string.common_money_symbol));
                    holder.clvOriginPrice.setVisibility(View.GONE);
                }

                //设置券后价
                double currentPrice = Double.valueOf(goodsBean.getCurrentPrice());
                holder.tvCurrentPrice.setText(NumberUtils.format(currentPrice));

                //设置预估收益
                if (!TextUtils.isEmpty(goodsBean.getCommissionFee())) {
                    double commissionFee = Double.valueOf(goodsBean.getCommissionFee());
                    if (commissionFee - 0.001 > 0) {
                        //设置预估收益
                        holder.tvForecastValue.setText(String.format(getString(R.string.common_forecast_earnings_format2), NumberUtils.format(commissionFee)));
                    } else {
                        //隐藏预估收益区域
                        holder.groupForecastEarn.setVisibility(View.GONE);
                    }
                }

                //设置原价
                double originPrice = Double.valueOf(goodsBean.getOriginPrice());
                holder.clvOriginPrice.setText(String.format(Locale.getDefault(), getString(R.string.common_origin_price_format), NumberUtils.format(originPrice)));

                //设置销量
                int volume = goodsBean.getGoodsVolume();
                String formatString;
                if (10000 > volume) {
                    formatString = getString(R.string.common_already_sell_format); //%d
                    holder.tvVolume.setText(String.format(formatString, volume));
                } else {
                    formatString = getString(R.string.common_already_sell_format2); //%s
                    float floatVolume = volume / 10000.0f;
                    holder.tvVolume.setText(String.format(formatString, NumberUtils.format(floatVolume)));
                }

                if (!TextUtils.isEmpty(goodsBean.getPlatType())) {
                    if ("tmall".equals(goodsBean.getPlatType())) {
                        //设置天猫图标
                        IconTextUtil.setIconAndTextInTextView(GoodsDetailsActivity.this, holder.tvGoodsTitle, R.mipmap.common_ic_tianmao_logo, goodsBean.getTitle());
                    } else if ("taobao".equals(goodsBean.getPlatType())) {
                        //设置淘宝图标
                        IconTextUtil.setIconAndTextInTextView(GoodsDetailsActivity.this, holder.tvGoodsTitle, R.mipmap.common_ic_taobao_logo, goodsBean.getTitle());
                    } else {
                        holder.tvGoodsTitle.setText(goodsBean.getTitle());
                    }
                } else {
                    holder.tvGoodsTitle.setText(goodsBean.getTitle());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        private void bindRelateGoodsData(GoodsListHolder holder, int position) {
            try {
                if (mListRelateGoods != null && mListRelateGoods.size() > 0 && position >= 0) {
                    Context context = holder.itemView.getContext().getApplicationContext();

                    CommonProductsEntity relateGoods = mListRelateGoods.get(position);

                    GlideUtils.initImageWithFileCache(relateGoods.getPict_url(), R.mipmap.common_ic_image_place_holder, holder.icon);

                    double originPrice = Double.valueOf(relateGoods.getOriginal_price());
                    String originPriceStr = NumberUtils.format(originPrice);

                    if (!TextUtils.isEmpty(relateGoods.getPlat_type())) {
                        if ("tmall".equals(relateGoods.getPlat_type())) {
                            //设置天猫图标
                            IconTextUtil.setIconAndTextInTextView(context, holder.title, R.mipmap.common_ic_tianmao_logo, relateGoods.getTitle());
                            holder.originPrice.setText(String.format(context.getString(R.string.common_goods_price_tianmao_format), originPriceStr));
                        } else if ("taobao".equals(relateGoods.getPlat_type())) {
                            //设置淘宝图标
                            IconTextUtil.setIconAndTextInTextView(context, holder.title, R.mipmap.common_ic_taobao_logo, relateGoods.getTitle());
                            holder.originPrice.setText(String.format(context.getString(R.string.common_goods_price_taobao_format), originPriceStr));
                        } else {
                            holder.title.setText(relateGoods.getTitle());
                            holder.originPrice.setText(String.format(context.getString(R.string.common_goods_price_format), originPriceStr));
                        }
                    } else {
                        holder.title.setText(relateGoods.getTitle());
                        holder.originPrice.setText(String.format(context.getString(R.string.common_goods_price_format), originPriceStr));
                    }

                    double couponValue = Double.valueOf(relateGoods.getCoupon_price());
                    if (couponValue - 0 < 0.0001) {
                        holder.couponValue.setVisibility(View.GONE);
                    } else {
                        holder.couponValue.setVisibility(View.VISIBLE);
                        holder.couponValue.setText(String.format(context.getString(R.string.common_goods_coupons_value_format), NumberUtils.format(couponValue)));
                    }

                    double currentPrice = Double.valueOf(relateGoods.getCurrent_price());
                    String currentPriceStr = NumberUtils.format(currentPrice);
                    holder.currentPrice.setText(String.format(context.getString(R.string.common_goods_price_format), currentPriceStr));

                    int volume = relateGoods.getSales_volume();
                    String formatString;
                    if (10000 > volume) {
                        formatString = context.getString(R.string.common_already_sell_format); //%d
                        holder.sell.setText(String.format(formatString, volume));
                    } else {
                        formatString = context.getString(R.string.common_already_sell_format2); //%s
                        float floatVolume = volume / 10000.0f;
                        holder.sell.setText(String.format(formatString, NumberUtils.format(floatVolume)));
                    }

                    double orderFee = Double.valueOf(relateGoods.getCommission_fee());
                    if (orderFee - 0.001 > 0) {
                        formatString = context.getString(R.string.common_forecast_earnings_format);
                        holder.orderRebate.setVisibility(View.VISIBLE);
                        holder.orderRebate.setText(String.format(Locale.getDefault(), formatString, NumberUtils.format(orderFee)));
                    } else {
                        holder.orderRebate.setVisibility(View.GONE);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public int getItemViewType(int position) {
            int viewType;
            switch (position) {
                case 0:
                    viewType = CONSTANT_GOODS_INFO_TYPE;
                    break;
                case 1:
                    viewType = CONSTANT_SHOP_INFO_TYPE;
                    break;
                case 2:
                    viewType = CONSTANT_IMAGES_INFO_TYPE;
                    break;
                case 3:
                    viewType = CONSTANT_RECOMMEND_HEAD_TYPE;
                    break;
                default:
                    viewType = position;
            }
            return viewType;
        }

        @Override
        public int getItemCount() {
            return mListRelateGoods != null ? mListRelateGoods.size() + CONSTANT_SPECIAL_TYPE_NUM : CONSTANT_SPECIAL_TYPE_NUM; //加上特殊项
        }

        public class GoodsInfoHolder extends RecyclerView.ViewHolder {
            private Group groupForecastEarn;
            private TextView tvCurrentPriceLabel;
            private TextView tvCurrentPrice;
            private TextView tvForecastValue;
            private CustomLineTextView clvOriginPrice;
            private TextView tvVolume;
            private TextView tvGoodsTitle;

            public GoodsInfoHolder(@NonNull View itemView) {
                super(itemView);
                groupForecastEarn = itemView.findViewById(R.id.group_goods_detail_forecast_earn);
                tvCurrentPriceLabel = itemView.findViewById(R.id.tv_goods_details_price_after_coupons_title);
                tvCurrentPrice = itemView.findViewById(R.id.tv_goods_details_price_after_coupons);
                tvForecastValue = itemView.findViewById(R.id.tv_goods_details_forecast_earnings);
                clvOriginPrice = itemView.findViewById(R.id.clv_goods_details_origin_price);
                tvVolume = itemView.findViewById(R.id.tv_goods_details_volume);
                tvGoodsTitle = itemView.findViewById(R.id.tv_goods_details_goods_title);
                tvGoodsTitle.setOnLongClickListener(v -> {
                    if (mGoodsBean != null && !TextUtils.isEmpty(mGoodsBean.getTitle())) {
                        if (ClipBoardUtil.copyTextWithAppLabel(GoodsDetailsActivity.this, mGoodsBean.getTitle())) {
                            toastMsg(getString(R.string.common_copy_success));
                        } else {
                            toastMsg(getString(R.string.common_copy_failed));
                        }
                    }
                    return false;
                });
            }
        }

        public class ShopInfoHolder extends RecyclerView.ViewHolder {
            private ViewGroup vShopContainer;
            private ImageView ivShopIcon;
            private TextView tvShopName;
            private TextView tvDescriptionScore;
            private TextView tvDescriptionLevel;
            private TextView tvSellerScore;
            private TextView tvSellerLevel;
            private TextView tvLogisticsScore;
            private TextView tvLogisticsLevel;
            private TextView tvDescriptionTitle;
            private TextView tvSellerTitle;
            private TextView tvLogisticsTitle;

            public ShopInfoHolder(@NonNull View itemView) {
                super(itemView);
                vShopContainer = itemView.findViewById(R.id.cl_good_details_other_coupons_shop);

                ivShopIcon = itemView.findViewById(R.id.iv_goods_details_shop_icon);
                tvShopName = itemView.findViewById(R.id.tv_goods_details_shop_name);

                tvDescriptionTitle = itemView.findViewById(R.id.tv_goods_details_description_title);
                tvDescriptionScore = itemView.findViewById(R.id.tv_goods_details_description_score);
                tvDescriptionLevel = itemView.findViewById(R.id.tv_goods_details_description_level);

                tvSellerTitle = itemView.findViewById(R.id.tv_goods_details_seller_service_title);
                tvSellerScore = itemView.findViewById(R.id.tv_goods_details_seller_service_score);
                tvSellerLevel = itemView.findViewById(R.id.tv_goods_details_seller_service_level);

                tvLogisticsTitle = itemView.findViewById(R.id.tv_goods_details_logistics_service_title);
                tvLogisticsScore = itemView.findViewById(R.id.tv_goods_details_logistics_service_score);
                tvLogisticsLevel = itemView.findViewById(R.id.tv_goods_details_logistics_service_level);

                vShopContainer.setOnClickListener(new OnSingleClickListener() {
                    @Override
                    public void onSingleClick(View v) {
                        //查看店铺有券商品
                        if (mShopEntity != null) {
                            mPresenter.getShopCouponsGoods(mShopEntity.getName());
                        }
                    }
                });
            }
        }

        public class ImagesInfoHolder extends RecyclerView.ViewHolder {
            private ViewGroup vGoodsDetails;
            private RecyclerView recyclerView;
            private CheckBox cbxExpanded;

            public ImagesInfoHolder(@NonNull View itemView) {
                super(itemView);
                vGoodsDetails = itemView.findViewById(R.id.cl_goods_details_look);
                cbxExpanded = itemView.findViewById(R.id.cbx_goods_details_look_indicator);
                recyclerView = itemView.findViewById(R.id.recycler_view_goods_detail_images);
                recyclerView.setLayoutManager(new LinearLayoutManager(GoodsDetailsActivity.this));
                int dividerSize = getResources().getDimensionPixelSize(R.dimen.common_dimen_8d);
                LinearItemDivider linearItemDivider = new LinearItemDivider(dividerSize, getResources().getColor(R.color.common_color_white), true);
                linearItemDivider.setDividersWidth(dividerSize, 0, dividerSize, 0);
                recyclerView.setItemAnimator(new DefaultItemAnimator());
                GoodsImagesAdapter imagesAdapter = new GoodsImagesAdapter();
                recyclerView.setAdapter(imagesAdapter);

                cbxExpanded.setChecked(NetworkUtil.isWiFiConnected());
                if (cbxExpanded.isChecked()) {
                    recyclerView.setVisibility(View.VISIBLE);
                } else {
                    recyclerView.setVisibility(View.GONE);
                }

                recyclerView.setEnabled(false);

                cbxExpanded.setOnCheckedChangeListener((buttonView, isChecked) -> {
                    if (cbxExpanded.isChecked()) {
                        recyclerView.setVisibility(View.VISIBLE);
                    } else {
                        recyclerView.setVisibility(View.GONE);
                    }
                });

                vGoodsDetails.setOnClickListener(v -> cbxExpanded.setChecked(!cbxExpanded.isChecked()));
            }
        }

        public class RelateHeadHolder extends RecyclerView.ViewHolder {

            public RelateHeadHolder(@NonNull View itemView) {
                super(itemView);
            }
        }

        public class GoodsListHolder extends RecyclerView.ViewHolder {
            private ImageView icon;
            private TextView title;
            private TextView couponValue;
            private TextView currentPrice;
            private TextView originPrice;
            private TextView sell;
            private TextView orderRebate;
//            private TextView updateRebate;

            public GoodsListHolder(View itemView) {
                super(itemView);
                icon = itemView.findViewById(R.id.iv_goods_list);
                title = itemView.findViewById(R.id.tv_goods_title_list);
                couponValue = itemView.findViewById(R.id.tv_goods_coupon_goods_list);
                currentPrice = itemView.findViewById(R.id.tv_goods_current_price_list);
                originPrice = itemView.findViewById(R.id.tv_origin_price_goods_list);
                sell = itemView.findViewById(R.id.tv_goods_sales_volume_list);
                orderRebate = itemView.findViewById(R.id.tv_goods_order_rebate_list);
//                updateRebate = itemView.findViewById(R.id.tv_goods_update_rebate_list);
                itemView.setOnClickListener(new OnSingleClickListener() {
                    @Override
                    public void onSingleClick(View v) {
                        int index = getAdapterPosition() - CONSTANT_SPECIAL_TYPE_NUM;
                        if (index >= 0) {
                            GoodsDetailsActivity.startForGoodDetail(GoodsDetailsActivity.this, GoodsConvertUtil.convertToGoodsBean(mListRelateGoods.get(index)));
                        }
                    }
                });
            }

        }

    }

    public class GoodsImagesAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override
        public void onViewRecycled(@NonNull RecyclerView.ViewHolder viewHolder) {
            super.onViewRecycled(viewHolder);
            if (viewHolder instanceof GoodsImagesHolder) {
                GoodsImagesHolder holder = (GoodsImagesHolder) viewHolder;
                if (holder.icon != null) {
                    GlideUtils.clearImageView(holder.icon);
                }
            }
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LogUtil.d(TAG, "onCreateViewHolder:");
            View view = getLayoutInflater().inflate(R.layout.common_adapter_item_goods_details_images_item, parent, false);

            return new GoodsImagesHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
            LogUtil.d(TAG, "onBindViewHolder: image=" + position);
            if (viewHolder instanceof GoodsImagesHolder) {
                GoodsImagesHolder holder = (GoodsImagesHolder) viewHolder;
                holder.icon.setImageResource(R.mipmap.common_ic_image_place_holder);
                GlideUtils.loadIntoUseFitWidth(mListGoodsImages.get(position), holder.icon);
            }
        }

        @Override
        public int getItemCount() {
            return mListGoodsImages != null ? mListGoodsImages.size() : 0;
        }

        class GoodsImagesHolder extends RecyclerView.ViewHolder {
            private ImageView icon;

            public GoodsImagesHolder(@NonNull View itemView) {
                super(itemView);
                icon = itemView.findViewById(R.id.iv_goods_details_image);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mGoodsBean != null) {
            mGoodsBean = null;
        }

        if (mListGoodsImages != null) {
            mListGoodsImages.clear();
            mListGoodsImages = null;
        }

        if (mListRelateGoods != null) {
            mListRelateGoods.clear();
            mListRelateGoods = null;
        }

        if (mToast != null) {
            mToast.destroy();
            mToast = null;
        }

        if (mPresenter != null) {
            mPresenter.detach();
            mPresenter.destroy();
            mPresenter = null;
        }

        if (mBanner != null) {
            mBanner.stopAutoPlay();
            mBanner = null;
        }

        if (mRefreshView != null) {
            mRefreshView.setRefreshing(false);
            mRefreshView = null;
        }

        mShopEntity = null;
        mAdapter = null;
        mAppBarLayout = null;
        mToolbar = null;
        mLoginCallbackWrf = null;

    }
}
