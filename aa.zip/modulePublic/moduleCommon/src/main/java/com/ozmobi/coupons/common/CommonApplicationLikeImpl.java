package com.ozmobi.coupons.common;

import android.app.Application;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.ozmobi.coupons.base.BaseApplicationLike;
import com.ozmobi.coupons.common.greendao.DaoMaster;
import com.ozmobi.coupons.common.greendao.DaoSession;
import com.ozmobi.coupons.common.utils.CouponDevOpenHelper;
import com.ozmobi.coupons.common.utils.GlideUtils;

/**
 * Created by xhkj on 2019/11/13.
 */

public class CommonApplicationLikeImpl implements BaseApplicationLike {
    private static Context context;

    private static DaoSession mDaoSession;

    private static SQLiteDatabase mDatabase;

    @Override
    public void onCreate(Application application) {
        //本地数据库
        setDatabase(application);
        context = application.getApplicationContext();
    }

    @Override
    public void onLowMemory() {
        GlideUtils.clearMemoryCache(context);
    }

    public static Context getContext() {
        return context;
    }

    private void setDatabase(Context context) {
        CouponDevOpenHelper devOpenHelper = new CouponDevOpenHelper(context, "coupons.db");
        mDatabase = devOpenHelper.getWritableDatabase();

        DaoMaster daoMaster = new DaoMaster(mDatabase);
        mDaoSession = daoMaster.newSession();
    }

    public static DaoSession getDaoSession() {
        return mDaoSession;
    }


    public static SQLiteDatabase getDatabase() {
        return mDatabase;
    }
}
