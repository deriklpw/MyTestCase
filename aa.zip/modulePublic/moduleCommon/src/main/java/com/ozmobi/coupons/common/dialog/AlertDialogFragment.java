package com.ozmobi.coupons.common.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.R;
import com.umeng.analytics.MobclickAgent;

/**
 * Created by xhkj on 2019/3/19.
 */

public class AlertDialogFragment extends BaseDialogFragment {

    private static final String TAG = "AlertDialogFragment";

    public static final String ARG_PARAM_TITLE = "param_title";

    public static final String ARG_PARAM_TEXT = "param_text";

    public static final String ARG_PARAM_TAG = "param_tag";

    private static final String ARG_PARAM_LEFT_BTN_TEXT = "param_left_btn_text";

    private static final String ARG_PARAM_RIGHT_BTN_TEXT = "param_right_btn_text";

    private OnConfirmClickCallback mCallback;

    private String mTitle;

    private String mTextContent;

    private String mBtnTextLeft;

    private String mBtnTextRight;

    public interface OnConfirmClickCallback {
        void onLeftClick(String tag, String title, String content);

        void onRightClick(String tag, String title, String content);
    }

    public AlertDialogFragment() {
        // Required empty public constructor
    }

    public static AlertDialogFragment newInstance(String title, String content, String leftText, String rightText) {
        AlertDialogFragment fragment = new AlertDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM_TITLE, title);
        args.putString(ARG_PARAM_TEXT, content);
        args.putString(ARG_PARAM_LEFT_BTN_TEXT, leftText);
        args.putString(ARG_PARAM_RIGHT_BTN_TEXT, rightText);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mTitle = getArguments().getString(ARG_PARAM_TITLE);
            mTextContent = getArguments().getString(ARG_PARAM_TEXT);
            mBtnTextLeft = getArguments().getString(ARG_PARAM_LEFT_BTN_TEXT);
            mBtnTextRight = getArguments().getString(ARG_PARAM_RIGHT_BTN_TEXT);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.d(TAG, "onResume: ");
        MobclickAgent.onPageStart(TAG);
    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.d(TAG, "onPause: ");
        MobclickAgent.onPageEnd(TAG);
    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtil.d(TAG, "onStop: ");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateView: ");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateDialog: ");
        AlertDialog dialog = new AlertDialog.Builder(mContext).create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.CENTER);
        window.setContentView(R.layout.common_dialog_fragment_alert);

        TextView tvTitle = window.findViewById(R.id.tv_alert_dialog_title);
        TextView tvContent = window.findViewById(R.id.tv_alert_dialog_content);
        TextView tvLeft = window.findViewById(R.id.tv_alert_dialog_left);
        TextView tvRight = window.findViewById(R.id.tv_alert_dialog_right);

        if (!TextUtils.isEmpty(mTitle)) {
            tvTitle.setText(mTitle);
        }

        if (!TextUtils.isEmpty(mBtnTextLeft)) {
            tvLeft.setText(mBtnTextLeft);
            tvLeft.setVisibility(View.VISIBLE);
        } else {
            tvLeft.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(mBtnTextRight)) {
            tvRight.setText(mBtnTextRight);
            tvRight.setVisibility(View.VISIBLE);
        } else {
            tvRight.setVisibility(View.GONE);
        }

        if (!TextUtils.isEmpty(mTextContent)) {
            tvContent.setText(mTextContent);
        }

        tvLeft.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                getDialog().dismiss();
                if (mCallback != null) {
                    mCallback.onLeftClick(getTag(), mTitle, mTextContent);
                } else {
                    Fragment fragment = getTargetFragment();
                    if (fragment != null) {
                        Intent intent = new Intent();
                        intent.putExtra(ARG_PARAM_TITLE, mTitle);
                        intent.putExtra(ARG_PARAM_TEXT, mTextContent);
                        intent.putExtra(ARG_PARAM_TAG, getTag());
                        fragment.onActivityResult(getTargetRequestCode(), Activity.RESULT_CANCELED, intent);
                    }
                }
            }
        });

        tvRight.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                getDialog().dismiss();
                if (mCallback != null) {
                    mCallback.onRightClick(getTag(), mTitle, mTextContent);
                } else {
                    Fragment fragment = getTargetFragment();
                    if (fragment != null) {
                        Intent intent = new Intent();
                        intent.putExtra(ARG_PARAM_TITLE, mTitle);
                        intent.putExtra(ARG_PARAM_TEXT, mTextContent);
                        intent.putExtra(ARG_PARAM_TAG, getTag());
                        fragment.onActivityResult(getTargetRequestCode(), Activity.RESULT_OK, intent);
                    }
                }
            }
        });

        return dialog;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        LogUtil.d(TAG, "onAttach: ");
        if (context instanceof OnConfirmClickCallback) {
            mCallback = (OnConfirmClickCallback) context;
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        LogUtil.d(TAG, "onDetach: ");
        mCallback = null;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtil.d(TAG, "onDestroy: ");
    }

}
