package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.bean.GoodsDetailsPageBean;
import com.ozmobi.coupons.common.bean.ShareTextBean;
import com.ozmobi.coupons.common.data.source.GoodsDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

/**
 * Created by xhkj on 2019/6/15.
 */

public class GoodsDataRepository implements GoodsDataSource {

    private static final String TAG = "GoodsDataRepository";
    @Override
    public Disposable getShopCouponsGoods(@NonNull String shopName, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("shop_title", shopName);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "get shop coupons goods post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<CommonGoodsBean> observable = ApiFactory.getYjlController().getShopCouponsGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }


    @Override
    public Disposable getGoodsDetails(@NonNull String numIId, @NonNull String platType, @NonNull Consumer<? super GoodsDetailsPageBean> success, @NonNull Consumer<? super Throwable> error) {

        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("num_iid", numIId);
            params.put("plat_type", platType);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getGoodsDetails post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<GoodsDetailsPageBean> observable = ApiFactory.getYjlController().getGoodsDetails(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getRelatedGoods(@NonNull String numIId, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("num_iid", numIId);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "get relate goods post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<CommonGoodsBean> observable = ApiFactory.getYjlController().getRelatedGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getGoodsShareText(@NonNull String numIId, @NonNull Consumer<? super ShareTextBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("num_iid", numIId);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getGoodsShareText post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<ShareTextBean> observable = ApiFactory.getYjlController().getShareText(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

}
