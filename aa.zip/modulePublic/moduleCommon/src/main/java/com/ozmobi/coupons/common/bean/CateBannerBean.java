package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/5/13.
 */

public class CateBannerBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public static class DataEntity {
        private List<CommonPromoteBean> text_banner;
        private BrandbuyEntity brandbuy;
        private ActivitiesEntity activities;
        private FastbuyEntity fastbuy;
        private List<BannerEntity> banner;
        private List<CommonPromoteBean> promotion_banner;
        private BannerBgEntity banner_bg;
        private AppBarBean app_bar;

        public void setText_banner(List<CommonPromoteBean> text_banner) {
            this.text_banner = text_banner;
        }

        public void setBrandbuy(BrandbuyEntity brandbuy) {
            this.brandbuy = brandbuy;
        }

        public void setActivities(ActivitiesEntity activities) {
            this.activities = activities;
        }

        public void setFastbuy(FastbuyEntity fastbuy) {
            this.fastbuy = fastbuy;
        }

        public void setBanner(List<BannerEntity> banner) {
            this.banner = banner;
        }

        public void setPromotion_banner(List<CommonPromoteBean> promotion_banner) {
            this.promotion_banner = promotion_banner;
        }

        public void setBanner_bg(BannerBgEntity banner_bg) {
            this.banner_bg = banner_bg;
        }

        public void setApp_bar(AppBarBean app_bar) {
            this.app_bar = app_bar;
        }

        public List<CommonPromoteBean> getText_banner() {
            return text_banner;
        }

        public BrandbuyEntity getBrandbuy() {
            return brandbuy;
        }

        public ActivitiesEntity getActivities() {
            return activities;
        }

        public FastbuyEntity getFastbuy() {
            return fastbuy;
        }

        public List<BannerEntity> getBanner() {
            return banner;
        }

        public List<CommonPromoteBean> getPromotion_banner() {
            return promotion_banner;
        }

        public BannerBgEntity getBanner_bg() {
            return banner_bg;
        }

        public AppBarBean getApp_bar() {
            return app_bar;
        }

        public static class BrandbuyEntity {
            private List<String> images;
            private String sub_title;
            private String title;

            public void setImages(List<String> images) {
                this.images = images;
            }

            public void setSub_title(String sub_title) {
                this.sub_title = sub_title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public List<String> getImages() {
                return images;
            }

            public String getSub_title() {
                return sub_title;
            }

            public String getTitle() {
                return title;
            }
        }

        public static class ActivitiesEntity {
            private String background;
            private List<ActiveEntity> active;
            private String titleBackground;
            private HeaderEntity header;

            public void setBackground(String background) {
                this.background = background;
            }

            public void setActive(List<ActiveEntity> active) {
                this.active = active;
            }

            public void setTitleBackground(String titleBackground) {
                this.titleBackground = titleBackground;
            }

            public void setHeader(HeaderEntity header) {
                this.header = header;
            }

            public String getBackground() {
                return background;
            }

            public List<ActiveEntity> getActive() {
                return active;
            }

            public String getTitleBackground() {
                return titleBackground;
            }

            public HeaderEntity getHeader() {
                return header;
            }

            public static class ActiveEntity {
                private String titleColor;
                private List<DataEntity2> data;
                private String title;

                public void setTitleColor(String titleColor) {
                    this.titleColor = titleColor;
                }

                public void setData(List<DataEntity2> data) {
                    this.data = data;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getTitleColor() {
                    return titleColor;
                }

                public List<DataEntity2> getData() {
                    return data;
                }

                public String getTitle() {
                    return title;
                }

                public static class DataEntity2 extends CommonPromoteBean {
                    private double image_ratio;

                    public void setImage_ratio(double image_ratio) {
                        this.image_ratio = image_ratio;
                    }

                    public double getImage_ratio() {
                        return image_ratio;
                    }

                }
            }

            public static class HeaderEntity {
                private String title;
                private String background;
                private CommonPromoteBean promote;

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getBackground() {
                    return background;
                }

                public void setBackground(String background) {
                    this.background = background;
                }

                public CommonPromoteBean getPromote() {
                    return promote;
                }

                public void setPromote(CommonPromoteBean promote) {
                    this.promote = promote;
                }
            }
        }

        public static class FastbuyEntity {
            private int left_time;
            private List<String> images;
            private String sub_title;
            private List<String> flash_time;

            public void setLeft_time(int left_time) {
                this.left_time = left_time;
            }

            public void setImages(List<String> images) {
                this.images = images;
            }

            public void setSub_title(String sub_title) {
                this.sub_title = sub_title;
            }

            public void setFlash_time(List<String> flash_time) {
                this.flash_time = flash_time;
            }

            public int getLeft_time() {
                return left_time;
            }

            public List<String> getImages() {
                return images;
            }

            public String getSub_title() {
                return sub_title;
            }

            public List<String> getFlash_time() {
                return flash_time;
            }
        }

        public static class BannerEntity extends CommonPromoteBean {
            private String bgcolor;

            public void setBgcolor(String bgcolor) {
                this.bgcolor = bgcolor;
            }
            public String getBgcolor() {
                return bgcolor;
            }
        }

        public static class BannerBgEntity {
            private String btn_image;
            private CommonPromoteBean promote;

            public String getBtn_image() {
                return btn_image;
            }

            public void setBtn_image(String btn_image) {
                this.btn_image = btn_image;
            }

            public CommonPromoteBean getPromote() {
                return promote;
            }

            public void setPromote(CommonPromoteBean promote) {
                this.promote = promote;
            }
        }

        public static class AppBarBean {
            private String icon_color;
            private SearchBarBean search_bar;
            private TabTextBean tab_text;
            private List<String> bg_color;

            public String getIcon_color() {
                return icon_color;
            }

            public void setIcon_color(String icon_color) {
                this.icon_color = icon_color;
            }

            public SearchBarBean getSearch_bar() {
                return search_bar;
            }

            public void setSearch_bar(SearchBarBean search_bar) {
                this.search_bar = search_bar;
            }

            public TabTextBean getTab_text() {
                return tab_text;
            }

            public void setTab_text(TabTextBean tab_text) {
                this.tab_text = tab_text;
            }

            public List<String> getBg_color() {
                return bg_color;
            }

            public void setBg_color(List<String> bg_color) {
                this.bg_color = bg_color;
            }

            public static class SearchBarBean {
                private String bg_color;
                private String icon_color;
                private String text_color;

                public String getBg_color() {
                    return bg_color;
                }

                public void setBg_color(String bg_color) {
                    this.bg_color = bg_color;
                }

                public String getIcon_color() {
                    return icon_color;
                }

                public void setIcon_color(String icon_color) {
                    this.icon_color = icon_color;
                }

                public String getText_color() {
                    return text_color;
                }

                public void setText_color(String text_color) {
                    this.text_color = text_color;
                }
            }

            public static class TabTextBean {
                private String select_color;
                private String unselect_color;
                private String indicator_color;

                public String getSelect_color() {
                    return select_color;
                }

                public void setSelect_color(String select_color) {
                    this.select_color = select_color;
                }

                public String getUnselect_color() {
                    return unselect_color;
                }

                public void setUnselect_color(String unselect_color) {
                    this.unselect_color = unselect_color;
                }

                public String getIndicator_color() {
                    return indicator_color;
                }

                public void setIndicator_color(String indicator_color) {
                    this.indicator_color = indicator_color;
                }
            }
        }
    }
}
