package com.ozmobi.coupons.common.ui.goodsdetails.shop;

import android.content.Context;
import android.content.Intent;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;

import com.ozmobi.coupons.common.BaseActivity;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.adapter.ListGoodsAdapter;
import com.ozmobi.coupons.common.adapter.LoadMoreWrapper;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.bean.CommonProductsEntity;
import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.common.ui.goodsdetails.GoodsDetailsActivity;
import com.ozmobi.coupons.common.utils.GoodsConvertUtil;
import com.ozmobi.coupons.common.utils.LinearItemDivider;
import com.ozmobi.coupons.base.utils.NetworkUtil;
import com.ozmobi.coupons.common.views.CustomRefreshLayout;

import java.util.ArrayList;
import java.util.List;

public class ShopCouponsActivity extends BaseActivity implements ShopCouponsContract.View, SwipeRefreshLayout.OnRefreshListener {

    private static final String TAG = "ShopCouponsActivity";

    private static final String EXTRA_KEY_SHOP_NAME = "extra_key_shop_name";

    private CustomRefreshLayout mRefreshView;

    private ShopCouponsContract.Presenter mPresenter;

    private List<CommonProductsEntity> mListGoods;

    private LoadMoreWrapper mAdapter;

    @Override
    protected int getLayoutId() {
        return R.layout.common_activity_shop_coupons;
    }

    @Override
    protected void onStop() {
        super.onStop();
        mPresenter.cancel();
    }

    @Override
    protected void initViews() {
        String shopName = getIntent().getStringExtra(EXTRA_KEY_SHOP_NAME);
        setToolbarTitle(shopName);
        
        mListGoods = new ArrayList<>();
        mPresenter = new ShopCouponsPresenter(shopName);
        mPresenter.attach(this);

        mRefreshView = findViewById(R.id.swipe_refresh);
        mRefreshView.setOnRefreshListener(this);
        RecyclerView recyclerView = findViewById(R.id.recycler_view);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        int dividerSize = getResources().getDimensionPixelSize(R.dimen.common_dimen_8d);
        LinearItemDivider linearItemDivider = new LinearItemDivider(dividerSize, getResources().getColor(R.color.common_color_white), true);
        linearItemDivider.setDividersWidth(dividerSize, dividerSize, dividerSize, dividerSize);
        recyclerView.addItemDecoration(linearItemDivider);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        ListGoodsAdapter listGoodsAdapter = new ListGoodsAdapter(R.layout.common_adapter_item_common_goods_list, mListGoods);
        listGoodsAdapter.setErrorResId(R.layout.common_layout_network_error, view -> {
            Button btnRefresh = view.findViewById(R.id.btn_network_error_refresh);
            btnRefresh.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    mPresenter.start();
                }
            });
        });
        listGoodsAdapter.setOnItemClickListener((view, commonProductsEntity, position) -> {
            GoodsDetailsActivity.startForGoodDetail(this, GoodsConvertUtil.convertToGoodsBean(commonProductsEntity));
        });
        mAdapter = new LoadMoreWrapper(listGoodsAdapter);
        recyclerView.setAdapter(mAdapter);

        mPresenter.start();
    }

    public static void startForShopCoupons(Context context, String shopName) {
        if (context != null && !TextUtils.isEmpty(shopName)) {
            Intent intent = new Intent(context, ShopCouponsActivity.class);
            intent.putExtra(EXTRA_KEY_SHOP_NAME, shopName);
            context.startActivity(intent);
        }
    }

    @Override
    public void setRefresh(boolean enable) {
        mRefreshView.setRefreshing(enable);
    }

    @Override
    public void setShopCouponsGoods(CommonGoodsBean commonGoodsBean) {
        if (commonGoodsBean != null &&
                commonGoodsBean.getData() != null &&
                commonGoodsBean.getData().getProducts() != null) {
            mListGoods.clear();
            mListGoods.addAll(commonGoodsBean.getData().getProducts());
            mAdapter.setLoadState(LoadMoreWrapper.LOADING_NO_MORE);
        }
    }

    @Override
    public void showError() {
        if (NetworkUtil.isNetworkAvailable()) {
            toastGetDataFail();
        } else {
            if (mListGoods != null && mListGoods.size() > 0) {
                toastNetError();
            } else {
                mAdapter.setNetError();
            }
        }
    }

    @Override
    public void onRefresh() {
        mPresenter.getShopCouponsGoods();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mPresenter != null) {
            mPresenter.detach();
            mPresenter.destroy();
            mPresenter = null;
        }

        if (mListGoods != null) {
            mListGoods.clear();
            mListGoods = null;
        }

        if (mRefreshView != null) {
            mRefreshView.setRefreshing(false);
            mRefreshView = null;
        }

        mAdapter = null;
    }
}
