package com.ozmobi.coupons.common.ui.search.urlgoods;

import com.ozmobi.coupons.base.Constants;
import com.ozmobi.coupons.common.IMoreContract;
import com.ozmobi.coupons.common.data.source.SearchDataSource;
import com.ozmobi.coupons.common.data.source.remote.SearchRepository;
import com.ozmobi.coupons.common.ui.search.result.SearchResultContract;

public class UrlGoodsPresenter extends IMoreContract.AbsMorePresenter<SearchResultContract.View, SearchDataSource> {

    private String mGoodsRequestUrl;

    private String mSort;

    public UrlGoodsPresenter(SearchResultContract.View view, String url) {
        super(new SearchRepository());
        mGoodsRequestUrl = url;
        this.attach(view);
        view.setPresenter(this);
    }

    @Override
    public void start() {
        if (getBaseView() != null) {
            getBaseView().showLoading();
        }
        loadData(1);
    }

    public void setSortAndReload(String sort) {
        mSort = sort;
        start();
    }

    @Override
    protected void loadData(int page) {
        if (getBaseRepository() == null) {
            if (getBaseView() != null && getBaseView().isLoading()) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
            }
            return;
        }
        addOperatorDisposable(getBaseRepository().getUrlGoods(mGoodsRequestUrl, Constants.PAGE_SIZE_LOAD_DEFAULT, page, mSort, commonGoodsBean -> {
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
                if (commonGoodsBean != null && commonGoodsBean.getData() != null) {
                    getBaseView().showData(commonGoodsBean.getData().getProducts());
                }
            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
                getBaseView().showGetDataError();
            }
        }));

    }

    @Override
    protected void loadMoreData(int page) {
        if (getBaseRepository() == null) {
            return;
        }
        addOperatorDisposable(getBaseRepository().getUrlGoods(mGoodsRequestUrl, Constants.PAGE_SIZE_LOAD_MORE, page, mSort, commonGoodsBean -> {
            if (getBaseView() != null) {
                if (commonGoodsBean != null && commonGoodsBean.getData() != null) {
                    getBaseView().showMoreData(commonGoodsBean.getData().getProducts());
                }
            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }));
    }

}
