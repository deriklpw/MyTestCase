package com.ozmobi.coupons.common;

import com.ozmobi.coupons.common.data.source.BaseDataSource;

import java.util.List;

/**
 * Created by xhkj on 2019/9/23.
 */

/**
 * 加载更多场景
 */
public interface IMoreContract {
    /**
     *
     * @param <B> java bean范型
     */
    interface IMoreView<B> extends BaseView {

        void showGetDataError();

        void showData(List<B> list);

        void showMoreData(List<B> list);

        void setRefresh(boolean enable);

        boolean isActive();
    }

    /**
     *
     * @param <V> View范型
     * @param <R> 数据仓库范型
     */
    abstract class AbsMorePresenter<V extends IMoreContract.IMoreView, R extends BaseDataSource> extends AbsBasePresenter<V, R> {

        public AbsMorePresenter(R r) {
            super(r);
        }

        protected abstract void loadData(int page);

        protected abstract void loadMoreData(int page);

        //空方法
        public void setSortAndReload(String sort) {}
    }
}
