package com.ozmobi.coupons.common.data.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 此目录中的Bean均不避开混淆，敏感信息，手动解析使用
 */
public class BindOrderBean implements Parcelable {
    private String tradeId;
    private String goodsTitle;
    private String payAmount;
    private String time;
    private String status;

    public BindOrderBean() {

    }

    protected BindOrderBean(Parcel in) {
        tradeId = in.readString();
        goodsTitle = in.readString();
        payAmount = in.readString();
        time = in.readString();
        status = in.readString();
    }

    public static final Creator<BindOrderBean> CREATOR = new Creator<BindOrderBean>() {
        @Override
        public BindOrderBean createFromParcel(Parcel in) {
            return new BindOrderBean(in);
        }

        @Override
        public BindOrderBean[] newArray(int size) {
            return new BindOrderBean[size];
        }
    };

    public String getTradeId() {
        return tradeId;
    }

    public void setTradeId(String tradeId) {
        this.tradeId = tradeId;
    }

    public String getGoodsTitle() {
        return goodsTitle;
    }

    public void setGoodsTitle(String goodsTitle) {
        this.goodsTitle = goodsTitle;
    }

    public String getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(String payAmount) {
        this.payAmount = payAmount;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(tradeId);
        dest.writeString(goodsTitle);
        dest.writeString(payAmount);
        dest.writeString(time);
        dest.writeString(status);
    }
}
