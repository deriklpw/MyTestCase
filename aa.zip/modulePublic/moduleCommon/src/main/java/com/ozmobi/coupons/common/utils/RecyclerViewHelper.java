package com.ozmobi.coupons.common.utils;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;

import com.ozmobi.coupons.base.utils.SortUtil;

/**
 * 功能：RecyclerView切换LayoutManger时，保留position位置
 * <p>
 * Created by xhkj on 2019/7/13.
 */

public class RecyclerViewHelper {

    public static void setLayoutManager(RecyclerView recyclerView, RecyclerView.LayoutManager layoutManager) {
        int scrollPosition = 0;

        RecyclerView.LayoutManager originLayoutManager = recyclerView.getLayoutManager();
        if (originLayoutManager instanceof LinearLayoutManager) {
            scrollPosition = ((LinearLayoutManager) originLayoutManager).findFirstVisibleItemPosition();
        } else if (originLayoutManager instanceof StaggeredGridLayoutManager) {
            StaggeredGridLayoutManager staggeredGridLayoutManager = (StaggeredGridLayoutManager) originLayoutManager;
            int[] firstVisiblePositions = staggeredGridLayoutManager.findFirstVisibleItemPositions(new int[staggeredGridLayoutManager.getSpanCount()]);
            scrollPosition = SortUtil.maoPaoSortExt(firstVisiblePositions)[0];
        }

        recyclerView.setLayoutManager(layoutManager);

        recyclerView.scrollToPosition(scrollPosition);
    }
}
