package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.bean.QuerySugBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public interface SearchDataSource extends BaseDataSource {

    Disposable getQuerySug(@NonNull String query, @NonNull Consumer<? super QuerySugBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getSearchGoods(@NonNull String query, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getUrlGoods(@NonNull String url, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);
}
