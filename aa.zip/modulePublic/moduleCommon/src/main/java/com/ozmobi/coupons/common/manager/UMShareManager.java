package com.ozmobi.coupons.common.manager;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.Toast;

import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.R;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.shareboard.ShareBoardConfig;
import com.umeng.socialize.utils.ShareBoardlistener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class UMShareManager {

    private static final String TAG = "UMShareManager";

    private ShareAction mDisplayShareAction;

    private ShareBoardConfig mShareConfig;

    private Context mContext;

    public static final String CUSTOM_SHARE_BUTTON_DOWNLOAD = "common_umeng_sharebutton_custom_download";

    public UMShareManager(Activity activity) {
        mContext = activity.getApplicationContext();
        mShareConfig = new ShareBoardConfig();
        mShareConfig.setMenuItemBackgroundShape(ShareBoardConfig.BG_SHAPE_CIRCULAR);
        mShareConfig.setCancelButtonVisibility(false);
        mShareConfig.setTitleText(mContext.getResources().getString(com.ozmobi.coupons.umeng.R.string.umeng_share_to_friend));
        mShareConfig.setTitleTextColor(mContext.getResources().getColor(com.ozmobi.coupons.umeng.R.color.umeng_color_share_title_text));
        mShareConfig.setMenuItemTextColor(mContext.getResources().getColor(com.ozmobi.coupons.umeng.R.color.umeng_color_share_item_name_text));
        mShareConfig.setShareboardBackgroundColor(Color.WHITE);
        mShareConfig.setIndicatorVisibility(false);

        mDisplayShareAction = new ShareAction(activity);
        mDisplayShareAction.setDisplayList(SHARE_MEDIA.WEIXIN, SHARE_MEDIA.QQ, SHARE_MEDIA.SINA, SHARE_MEDIA.WEIXIN_CIRCLE, SHARE_MEDIA.QZONE);
    }

    private UMShareListener mShareListener = new UMShareListener() {
        /**
         * @descrption 分享开始的回调
         * @param platform 平台类型
         */
        @Override
        public void onStart(SHARE_MEDIA platform) {

        }

        /**
         * @descrption 分享成功的回调
         * @param platform 平台类型
         */
        @Override
        public void onResult(SHARE_MEDIA platform) {
            if (mContext != null) {
                toastMsg(mContext.getResources().getString(com.ozmobi.coupons.umeng.R.string.umeng_share_success));
            }

        }

        /**
         * @descrption 分享失败的回调
         * @param platform 平台类型
         * @param t 错误原因
         */
        @Override
        public void onError(SHARE_MEDIA platform, Throwable t) {
            if (mContext != null) {
                toastMsg(mContext.getResources().getString(com.ozmobi.coupons.umeng.R.string.umeng_share_failed));
            }
        }

        /**
         * @descrption 分享取消的回调
         * @param platform 平台类型
         */
        @Override
        public void onCancel(SHARE_MEDIA platform) {
            if (mContext != null) {
                toastMsg(mContext.getResources().getString(com.ozmobi.coupons.umeng.R.string.umeng_share_cancel));
            }

        }
    };

    public void shareImageWithFile(Activity activity, String pathFile, String shareText) {
        shareImageWithFile(activity, pathFile, shareText, mShareListener);
    }

    public void shareImageWithBitmap(Activity activity, Bitmap bitmap, String shareText) {
        if (bitmap == null) {
            return;
        }
        UMImage image = new UMImage(activity, bitmap);
        image.setThumb(image);
        shareImage(activity, image, shareText, mShareListener);
    }

    public void shareImageWithFile(Activity activity, String pathFile, String shareText, UMShareListener shareListener) {
        if (TextUtils.isEmpty(pathFile)) {
            return;
        }
        File imageFile = new File(pathFile);
        UMImage image = new UMImage(activity.getApplicationContext(), imageFile);
        image.setThumb(image);
        shareImage(activity, image, shareText, shareListener);
    }

    public void shareImagesWithFiles(Activity activity, List<String> listPaths, String shareText) {
        shareImagesWithFiles(activity, listPaths, shareText, mShareListener);
    }

    public void shareImagesWithFiles(Activity activity, List<String> listPaths, String shareText, UMShareListener shareListener) {
        if (listPaths == null || listPaths.size() == 0) {
            return;
        }

        List<UMImage> listUmImage = new ArrayList<>();
        for (String str : listPaths) {
            File file = new File(str);
            UMImage image = new UMImage(activity.getApplicationContext(), file);
            image.setThumb(image);
            image.compressStyle = UMImage.CompressStyle.SCALE;
            listUmImage.add(image);
        }

        UMImage[] imageArray = new UMImage[listUmImage.size()];
        mDisplayShareAction
                .setShareboardclickCallback((snsPlatform, share_media) -> {
                    if (UMShareAPI.get(activity).isInstall(activity, share_media)) {
                        if (share_media == SHARE_MEDIA.WEIXIN || share_media == SHARE_MEDIA.QQ) {
                            openLocalImagesShare(share_media, listPaths);

                        } else {
                            ShareAction shareAction = new ShareAction(activity);
                            shareAction.setPlatform(share_media)
                                    .setCallback(shareListener) //回调监听器
                                    .withMedias(listUmImage.toArray(imageArray));

                            if (!TextUtils.isEmpty(shareText)) {
                                shareAction.withText(shareText);
                            }
                            shareAction.share();
                        }
                    } else {
                        String name = getShareMediaName(share_media);
                        toastMsg(String.format(Locale.getDefault(), mContext.getResources().getString(com.ozmobi.coupons.umeng.R.string.umeng_please_install_app_first), name));
                    }
                })
                .open(mShareConfig);
    }

    private void shareImage(Activity activity, UMImage image, String shareText, UMShareListener shareListener) {
        if (image == null) {
            return;
        }
        mDisplayShareAction
                .setShareboardclickCallback((snsPlatform, share_media) -> {
                    if (UMShareAPI.get(activity).isInstall(activity, share_media)) {
                        ShareAction shareAction = new ShareAction(activity);
                        shareAction.setPlatform(share_media)
                                .setCallback(shareListener) //回调监听器
                                .withMedia(image);

                        if (!TextUtils.isEmpty(shareText)) {
                            shareAction.withText(shareText);
                        }
                        shareAction.share();
                    } else {
                        String name = getShareMediaName(share_media);
                        toastMsg(String.format(Locale.getDefault(), mContext.getResources().getString(com.ozmobi.coupons.umeng.R.string.umeng_please_install_app_first), name));
                    }
                })
                .open(mShareConfig);
    }

    public void toastMsg(String msg) {
        Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
    }

    public String getShareMediaName(SHARE_MEDIA share_media) {
        String name = "";

        if (SHARE_MEDIA.WEIXIN == share_media || SHARE_MEDIA.WEIXIN_CIRCLE == share_media) {
            name = mContext.getResources().getString(com.ozmobi.coupons.umeng.R.string.umeng_wechat);
        } else if (SHARE_MEDIA.QQ == share_media) {
            name = share_media.getName();
        } else if (SHARE_MEDIA.SINA == share_media) {
            name = mContext.getResources().getString(com.ozmobi.coupons.umeng.R.string.umeng_sina_weibo);
        } else if (SHARE_MEDIA.QZONE == share_media) {
            name = mContext.getResources().getString(com.ozmobi.coupons.umeng.R.string.umeng_qq_zone);
        }
        return name;
    }

    /**
     * 用于QQ和微信好友多图分享
     */
    private void openLocalImagesShare(SHARE_MEDIA share_media, List<String> listPath) {
        if (listPath == null || listPath.size() == 0) {
            return;
        }

        Intent intent = new Intent();
        ComponentName comp = null;

        if (share_media == SHARE_MEDIA.QQ) {
            comp = new ComponentName("com.tencent.mobileqq", "com.tencent.mobileqq.activity.JumpActivity");

        } else if (share_media == SHARE_MEDIA.WEIXIN) {
            comp = new ComponentName("com.tencent.mm", "com.tencent.mm.ui.tools.ShareImgUI");
        }

        if (comp != null) {
            intent.setComponent(comp);
            intent.setAction(Intent.ACTION_SEND_MULTIPLE);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setType("image/*");
            ArrayList<Uri> imageUris = new ArrayList<>();
            for (int i = 0; i < listPath.size(); i++) {
                File file = new File(listPath.get(i));
                LogUtil.d(TAG, "openLocalImagesShare: path=" + file.getAbsolutePath());
                imageUris.add(Uri.fromFile(file));
            }
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, imageUris);
            if (intent.resolveActivity(mContext.getPackageManager()) != null) {
                mContext.startActivity(intent);
            }
        }
    }

    public void shareVideo(Activity activity, ShareBoardlistener shareBoardlistener) {
        mDisplayShareAction = new ShareAction(activity);
        mDisplayShareAction.setDisplayList(SHARE_MEDIA.WEIXIN, SHARE_MEDIA.WEIXIN_CIRCLE, SHARE_MEDIA.QQ)
                .addButton(activity.getString(R.string.common_umeng_sharebutton_custom_download), CUSTOM_SHARE_BUTTON_DOWNLOAD, "common_icon_share_video_download", "common_icon_share_video_download");
        mDisplayShareAction
                .setShareboardclickCallback(shareBoardlistener)
                .open(mShareConfig);
    }

    /**
     * 用于QQ和微信好友分享视频
     */
    public void openLocalVideoShare(SHARE_MEDIA share_media, String videoPath) {
        if (TextUtils.isEmpty(videoPath)) {
            return;
        }

        Intent intent = new Intent();
        ComponentName comp = null;

        if (share_media == SHARE_MEDIA.QQ) {
            comp = new ComponentName("com.tencent.mobileqq", "com.tencent.mobileqq.activity.JumpActivity");

        } else if (share_media == SHARE_MEDIA.WEIXIN) {
            comp = new ComponentName("com.tencent.mm", "com.tencent.mm.ui.tools.ShareImgUI");
        }

        if (comp != null) {
            intent.setComponent(comp);
            intent.setAction(Intent.ACTION_SEND);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setType("video/*");
            intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(videoPath)));
            if (intent.resolveActivity(mContext.getPackageManager()) != null) {
                mContext.startActivity(intent);
            }
        }

        if (share_media == SHARE_MEDIA.WEIXIN_CIRCLE) {
//            comp = new ComponentName("com.tencent.mm", "com.tencent.mm.ui.tools.ShareToTimeLineUI");
            Intent lan = mContext.getPackageManager().getLaunchIntentForPackage("com.tencent.mm");
            intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (lan != null && lan.getComponent() != null) {
                intent.setComponent(lan.getComponent());
                mContext.startActivity(intent);
            }
        }
    }

    public static void onActivityResult(Context context, int requestCode, int resultCode, Intent data) {
        UMShareAPI.get(context).onActivityResult(requestCode, resultCode, data);
    }

    public static void release(Context context) {
        UMShareAPI.get(context).release();
    }
}
