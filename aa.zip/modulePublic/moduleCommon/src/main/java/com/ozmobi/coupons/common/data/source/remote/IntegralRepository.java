package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.ExchangeGoodsBean;
import com.ozmobi.coupons.common.bean.ExchangeRecordBean;
import com.ozmobi.coupons.common.bean.IntegralCenterBean;
import com.ozmobi.coupons.common.bean.IntegralDetailBean;
import com.ozmobi.coupons.common.bean.PunchRecordDetailBean;
import com.ozmobi.coupons.common.bean.PunchRecordResultBean;
import com.ozmobi.coupons.common.bean.PunchIntegralBean;
import com.ozmobi.coupons.common.bean.SignInResultBean;
import com.ozmobi.coupons.common.data.source.IntegralDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

/**
 * Created by xhkj on 2019/5/10.
 */

public class IntegralRepository implements IntegralDataSource {

    private static final String TAG = "IntegralRepository";

    @Override
    public Disposable getIntegralCenterData(@NonNull Consumer<? super IntegralCenterBean> success, @NonNull Consumer<? super Throwable> error) {

        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "getIntegralCenterData post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<IntegralCenterBean> observable = ApiFactory.getYjlController().getIntegralCenterData(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getIntegralDetail(int page, int pageSize, @NonNull Consumer<? super IntegralDetailBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getIntegralDetail post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<IntegralDetailBean> observable = ApiFactory.getYjlController().getIntegralDetail(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getExchangeGoodsDetail(int id, @NonNull Consumer<? super ExchangeGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());

            JSONObject params = new JSONObject();
            params.put("id", id);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getExchangeGoodsDetail post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<ExchangeGoodsBean> observable = ApiFactory.getYjlController().getExchangeGoodsDetail(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable exchangeGoods(int id, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());

            JSONObject params = new JSONObject();
            params.put("id", id);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }
        LogUtil.d(TAG, "exchangeGoods post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController().exchangeGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getExchangeRecord(int page, int pageSize, @NonNull Consumer<? super ExchangeRecordBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getExchangeRecord post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<ExchangeRecordBean> observable = ApiFactory.getYjlController().getExchangeRecord(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable signInNow(@NonNull Consumer<? super SignInResultBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "signInNow post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<SignInResultBean> observable = ApiFactory.getYjlController().signInNow(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getPunchIntegral(@NonNull Consumer<? super PunchIntegralBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "getPunchIntegral post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<PunchIntegralBean> observable = ApiFactory.getYjlController().getPunchIntegral(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable applyPunch(@NonNull Consumer<? super PunchIntegralBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "applyPunch post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<PunchIntegralBean> observable = ApiFactory.getYjlController().applyPunch(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable punchNow(@NonNull Consumer<? super PunchIntegralBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "punchNow post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<PunchIntegralBean> observable = ApiFactory.getYjlController().punchNow(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getPunchRecordMyResult(@NonNull Consumer<? super PunchRecordResultBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "getPunchRecordMyResult post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<PunchRecordResultBean> observable = ApiFactory.getYjlController().getPunchRecordMyResult(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getPunchRecordDetail(int page, int pageSize, @NonNull Consumer<? super PunchRecordDetailBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("pagesize", pageSize);
            params.put("page", page);

            rootJson.put("param", params);
            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getPunchRecordDetail post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<PunchRecordDetailBean> observable = ApiFactory.getYjlController().getPunchRecordDetail(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }
}
