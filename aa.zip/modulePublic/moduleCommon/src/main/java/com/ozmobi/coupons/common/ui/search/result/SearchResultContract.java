package com.ozmobi.coupons.common.ui.search.result;

import com.ozmobi.coupons.common.IMoreContract;
import com.ozmobi.coupons.common.bean.CommonProductsEntity;

public interface SearchResultContract {

    interface View extends IMoreContract.IMoreView<CommonProductsEntity> {
        void setPresenter(IMoreContract.AbsMorePresenter presenter);
    }
}
