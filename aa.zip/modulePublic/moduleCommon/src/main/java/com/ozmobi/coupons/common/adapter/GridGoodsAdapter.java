package com.ozmobi.coupons.common.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.bean.CommonProductsEntity;
import com.ozmobi.coupons.common.utils.GlideUtils;
import com.ozmobi.coupons.base.utils.IconTextUtil;
import com.ozmobi.coupons.base.utils.NumberUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

/**
 * 图，title，券信息，价格四行
 * 一部分垂直列表商品布局相同，采用相同的适配器
 */
public class GridGoodsAdapter extends CustomBaseAdapter<CommonProductsEntity> {
//    R.layout.adapter_item_common_goods

    private LinkedList<ImageView> mListImageView;

    public GridGoodsAdapter(int layoutId, List<CommonProductsEntity> list) {
        super(layoutId, list);
        mListImageView = new LinkedList<>();
    }

    @Override
    public void onViewRecycled(@NonNull RecyclerView.ViewHolder viewHolder) {
        super.onViewRecycled(viewHolder);
        if (viewHolder instanceof GoodsHolderVertical) {
            GoodsHolderVertical holder = (GoodsHolderVertical) viewHolder;
            if (holder.icon != null) {
                GlideUtils.clearImageView(holder.icon);
                mListImageView.remove(holder.icon);
            }
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateCustomViewHolder(View view) {
        return new GoodsHolderVertical(view);
    }

    @Override
    public void onBindCustomViewHolder(RecyclerView.ViewHolder viewHolder, CommonProductsEntity goods, int position) {

        if (viewHolder instanceof GoodsHolderVertical) {
            try {
                Context context = viewHolder.itemView.getContext();

                GoodsHolderVertical holder = (GoodsHolderVertical) viewHolder;

                GlideUtils.initImageWithFileCache(goods.getPict_url(), R.mipmap.common_ic_image_place_holder, holder.icon);
                mListImageView.add(holder.icon);

                if (!TextUtils.isEmpty(goods.getPlat_type())) {
                    if ("tmall".equals(goods.getPlat_type())) {
                        //设置天猫图标
                        IconTextUtil.setIconAndTextInTextView(context, holder.title, R.mipmap.common_ic_tianmao_logo, goods.getTitle());
                    } else if ("taobao".equals(goods.getPlat_type())) {
                        //设置淘宝图标
                        IconTextUtil.setIconAndTextInTextView(context, holder.title, R.mipmap.common_ic_taobao_logo, goods.getTitle());
                    } else {
                        holder.title.setText(goods.getTitle());
                    }
                } else {
                    holder.title.setText(goods.getTitle());
                }

                double couponValue = Double.valueOf(goods.getCoupon_price());
                if (couponValue - 0 < 0.0001) {
                    holder.couponValue.setVisibility(View.GONE);
                } else {
                    holder.couponValue.setVisibility(View.VISIBLE);
                    holder.couponValue.setText(String.format(context.getString(R.string.common_goods_coupons_value_format), NumberUtils.format(couponValue)));
                }

                double currentPrice = Double.valueOf(goods.getCurrent_price());
                double originPrice = Double.valueOf(goods.getOriginal_price());
                holder.currentPrice.setText(String.format(context.getString(R.string.common_goods_price_format), NumberUtils.format(currentPrice)));
                holder.originPrice.setText(String.format(context.getString(R.string.common_goods_price_format), NumberUtils.format(originPrice)));

                int volume = goods.getSales_volume();
                String formatString;
                if (10000 > volume) {
                    formatString = context.getString(R.string.common_already_sell_format); //%d
                    holder.sell.setText(String.format(formatString, volume));
                } else {
                    formatString = context.getString(R.string.common_already_sell_format2); //%s
                    float floatVolume = volume / 10000.0f;
                    holder.sell.setText(String.format(formatString, NumberUtils.format(floatVolume)));
                }

                double orderFee = Double.valueOf(goods.getCommission_fee());
                if (orderFee - 0.001 > 0) {
                    formatString = context.getString(R.string.common_forecast_earnings_format);
                    holder.orderRebate.setVisibility(View.VISIBLE);
                    holder.orderRebate.setText(String.format(Locale.getDefault(), formatString, NumberUtils.format(orderFee)));
                } else {
                    holder.orderRebate.setVisibility(View.GONE);
                }

                if (TextUtils.isEmpty(goods.getShop_title())) {
                    holder.shopName.setVisibility(View.GONE);
                } else {
                    holder.shopName.setVisibility(View.VISIBLE);
                    holder.shopName.setText(goods.getShop_title());
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class GoodsHolderVertical extends CustomBaseHolder {
        private ImageView icon;
        private TextView title;
        private TextView couponValue;
        private TextView currentPrice;
        private TextView originPrice;
        private TextView sell;
        private AppCompatTextView orderRebate;
        private TextView shopName;

        public GoodsHolderVertical(View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.iv_common_icon_goods);
            title = itemView.findViewById(R.id.tv_common_title_goods);
            couponValue = itemView.findViewById(R.id.tv_common_coupon_goods);
            currentPrice = itemView.findViewById(R.id.tv_common_current_price_goods);
            originPrice = itemView.findViewById(R.id.clv_common_origin_price_goods);
            sell = itemView.findViewById(R.id.tv_common_sell_goods);
            orderRebate = itemView.findViewById(R.id.tv_common_order_rebate);
            shopName = itemView.findViewById(R.id.tv_common_shop_name_goods);
        }
    }

    @Override
    public void clearImageViews() {
        for (ImageView view: mListImageView) {
            GlideUtils.clearImageView(view);
        }
    }

}
