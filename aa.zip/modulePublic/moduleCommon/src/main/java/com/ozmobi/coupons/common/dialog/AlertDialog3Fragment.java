package com.ozmobi.coupons.common.dialog;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.ozmobi.coupons.common.R;

public class AlertDialog3Fragment extends BaseDialogFragment {

    private static final String ARG_TITLE = "title";
    private static final String ARG_TEXT = "text";
    private static final String ARG_TIP = "tip";

    private String mTitle;
    private String mText;
    private String mTip;

    public AlertDialog3Fragment() {
        // Required empty public constructor
    }

    public static AlertDialog3Fragment newInstance(String title, String text, String tip) {
        AlertDialog3Fragment fragment = new AlertDialog3Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_TITLE, title);
        args.putString(ARG_TEXT, text);
        args.putString(ARG_TIP, tip);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mTitle = getArguments().getString(ARG_TITLE);
            mText = getArguments().getString(ARG_TEXT);
            mTip = getArguments().getString(ARG_TIP);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog dialog = new AlertDialog.Builder(mContext).create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.CENTER);
        window.setContentView(R.layout.common_dialog_fragment_alert3);

        ImageView ivClose = window.findViewById(R.id.iv_alert_dialog_close_icon);

        TextView tvTitle = window.findViewById(R.id.tv_alert_dialog_title);
        TextView tvText = window.findViewById(R.id.tv_alert_dialog_text);
        TextView tvTip = window.findViewById(R.id.tv_alert_dialog_tip);

        tvTitle.setText(mTitle);
        tvText.setText(mText);

        if (TextUtils.isEmpty(mTip)) {
            tvTip.setVisibility(View.GONE);
        } else {
            tvTip.setVisibility(View.VISIBLE);
            tvTip.setText(mTip);
        }

        ivClose.setOnClickListener(v -> getDialog().dismiss());

        return dialog;
    }

}
