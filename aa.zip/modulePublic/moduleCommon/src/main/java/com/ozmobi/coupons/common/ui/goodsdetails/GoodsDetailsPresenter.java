package com.ozmobi.coupons.common.ui.goodsdetails;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.GoodsBean;
import com.ozmobi.coupons.common.data.source.MineDataSource;
import com.ozmobi.coupons.common.data.source.remote.GoodsDataRepository;
import com.ozmobi.coupons.common.data.source.remote.MineDataRepository;

/**
 * Created by xhkj on 2019/6/11.
 */

public class GoodsDetailsPresenter extends GoodsDetailsContract.Presenter {

    private static final String TAG = "GoodsDetailsPresenter";

    private MineDataSource mMineDataSource;

    GoodsDetailsPresenter() {
        super(new GoodsDataRepository());
        mMineDataSource = new MineDataRepository();
    }

    @Override
    public void start() {
    }

    @Override
    public void addCouponsGoods(GoodsBean goodsBean) {
        addOperatorDisposable(mMineDataSource.addCouponGoods(goodsBean, addCouponsCallback));
    }

    @Override
    public void addHistoryGoods(GoodsBean goodsBean) {
        addOperatorDisposable(mMineDataSource.addHistoryGoods(goodsBean, addHistoryCallback));
    }

    @Override
    public void getGoodsDetailsImages(String numIId, String platType) {
        if (getBaseRepository() == null) {
            return;
        }
        addOperatorDisposable(getBaseRepository().getGoodsDetails(numIId, platType, goodsDetailsPageBean -> {
            LogUtil.d(TAG, "getGoodsDetailsImages: " + JSON.toJSONString(goodsDetailsPageBean));
            if (getBaseView() != null) {
                getBaseView().setGoodsDetailsPageBean(goodsDetailsPageBean);
            }

        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }));
    }

    @Override
    public void getRelateGoods(String numIId) {
        if (getBaseRepository() == null) {
            return;
        }
        addOperatorDisposable(getBaseRepository().getRelatedGoods(numIId, commonGoodsBean -> {
            LogUtil.d(TAG, "getRelateGoods: " + JSON.toJSONString(commonGoodsBean));
            if (getBaseView() != null) {
                getBaseView().setRefresh(false);
                getBaseView().showRelateGoods(commonGoodsBean);
            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().setRefresh(false);
                getBaseView().showError();
            }
        }));
    }

    @Override
    public void getShopCouponsGoods(String shopName) {
        if (getBaseRepository() == null) {
            return;
        }
        addOperatorDisposable(getBaseRepository().getShopCouponsGoods(shopName, commonGoodsBean -> {
            LogUtil.d(TAG, "getShopCouponsGoods: " + JSON.toJSONString(commonGoodsBean));
            if (getBaseView() != null) {
                getBaseView().setShopCouponsGoods(commonGoodsBean);
            }

        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }));
    }

    @Override
    public void getTaobaoAuthUrl(GoodsDetailsContract.Callback callback) {
        if (getBaseRepository() == null) {
            return;
        }
        addOperatorDisposable(getBaseRepository().getTaobaoAuthUrl(jsonObject -> {
            LogUtil.d(TAG, "getTaobaoAuthUrl: " + jsonObject.toJSONString());
            if (getBaseView() != null) {
                String url;
                try {
                    int error = jsonObject.getIntValue("error");
                    String msg = jsonObject.getString("msg");
                    if (error == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        url = dataObj.getString("oauthurl");
                        if (callback != null) {
                            callback.onResponse(url);
                        }
                    } else {
                        getBaseView().toastMsg(msg);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }));
    }

    @Override
    public void queryCollectState(String id) {
        addOperatorDisposable(mMineDataSource.queryCollectStateGoods(id, queryStateBean -> {
            if (getBaseView() != null) {
                if (queryStateBean.getError() == 0) {
                    if ("1".equals(queryStateBean.getData().getCollect())) {
                        //返回"1"，已收集，"0"，未收集
                        getBaseView().setCollectState(true);
                    } else {
                        getBaseView().setCollectState(false);
                    }
                }
            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }));
    }

    @Override
    public void addFavoriteGoods(GoodsBean goodsBean) {
        addOperatorDisposable(mMineDataSource.addFavoriteGoods(goodsBean, addFavoriteCallBack));
    }

    @Override
    public void deleteFavoriteGoods(String id) {
        addOperatorDisposable(mMineDataSource.deleteFavoriteGoods(id, deleteFavoriteCallback));
    }

    private MineDataSource.MineResultCallback addCouponsCallback = new MineDataSource.MineResultCallback() {
        @Override
        public void onSuccess() {
        }

        @Override
        public void onError() {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }
    };

    private MineDataSource.MineResultCallback addHistoryCallback = new MineDataSource.MineResultCallback() {
        @Override
        public void onSuccess() {

        }

        @Override
        public void onError() {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }
    };

    private MineDataSource.MineResultCallback addFavoriteCallBack = new MineDataSource.MineResultCallback() {
        @Override
        public void onSuccess() {
            if (getBaseView() != null) {
                getBaseView().showCollectFavorite(true);
            }
        }

        @Override
        public void onError() {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }
    };

    private MineDataSource.MineResultCallback deleteFavoriteCallback = new MineDataSource.MineResultCallback() {
        @Override
        public void onSuccess() {
            if (getBaseView() != null) {
                getBaseView().showCollectFavorite(false);
            }
        }

        @Override
        public void onError() {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }
    };


    @Override
    public void destroy() {
        super.destroy();
        mMineDataSource = null;

        addFavoriteCallBack = null;
        deleteFavoriteCallback = null;
        addCouponsCallback = null;
        addHistoryCallback = null;
    }
}
