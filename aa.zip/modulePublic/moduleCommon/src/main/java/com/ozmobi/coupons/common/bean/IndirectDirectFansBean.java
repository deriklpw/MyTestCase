package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/8/14.
 */

public class IndirectDirectFansBean {
    private int error;
    private String msg;
    private DataBean data;
    private int time;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public static class DataBean {
        private List<FanslistBeanX> fanslist;

        public List<FanslistBeanX> getFanslist() {
            return fanslist;
        }

        public void setFanslist(List<FanslistBeanX> fanslist) {
            this.fanslist = fanslist;
        }

        public static class FanslistBeanX {
            private String uid;
            private String nick;
            private String icon;
            private String mobile;
            private String register_date;
            private String level;
            private int fans_num;
            private List<FanslistBean> fanslist;

            public String getUid() {
                return uid;
            }

            public void setUid(String uid) {
                this.uid = uid;
            }

            public String getNick() {
                return nick;
            }

            public void setNick(String nick) {
                this.nick = nick;
            }

            public String getIcon() {
                return icon;
            }

            public void setIcon(String icon) {
                this.icon = icon;
            }

            public String getMobile() {
                return mobile;
            }

            public void setMobile(String mobile) {
                this.mobile = mobile;
            }

            public String getRegister_date() {
                return register_date;
            }

            public void setRegister_date(String register_date) {
                this.register_date = register_date;
            }

            public String getLevel() {
                return level;
            }

            public void setLevel(String level) {
                this.level = level;
            }

            public int getFans_num() {
                return fans_num;
            }

            public void setFans_num(int fans_num) {
                this.fans_num = fans_num;
            }

            public List<FanslistBean> getFanslist() {
                return fanslist;
            }

            public void setFanslist(List<FanslistBean> fanslist) {
                this.fanslist = fanslist;
            }

            public static class FanslistBean {
                private String uid;
                private String nick;
                private String icon;
                private String mobile;
                private String register_date;
                private String level;

                public String getUid() {
                    return uid;
                }

                public void setUid(String uid) {
                    this.uid = uid;
                }

                public String getNick() {
                    return nick;
                }

                public void setNick(String nick) {
                    this.nick = nick;
                }

                public String getIcon() {
                    return icon;
                }

                public void setIcon(String icon) {
                    this.icon = icon;
                }

                public String getMobile() {
                    return mobile;
                }

                public void setMobile(String mobile) {
                    this.mobile = mobile;
                }

                public String getRegister_date() {
                    return register_date;
                }

                public void setRegister_date(String register_date) {
                    this.register_date = register_date;
                }

                public String getLevel() {
                    return level;
                }

                public void setLevel(String level) {
                    this.level = level;
                }
            }
        }
    }
}
