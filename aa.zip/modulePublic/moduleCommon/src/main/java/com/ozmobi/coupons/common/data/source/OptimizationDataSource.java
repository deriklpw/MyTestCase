package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;

import com.ozmobi.coupons.common.bean.CommonGoodsBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public interface OptimizationDataSource extends BaseDataSource {

    Disposable getGuessLikeGoods(@NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);
}
