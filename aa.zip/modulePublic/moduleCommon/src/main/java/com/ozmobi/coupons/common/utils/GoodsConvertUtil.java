package com.ozmobi.coupons.common.utils;

import com.ozmobi.coupons.common.bean.CommonProductsEntity;
import com.ozmobi.coupons.common.bean.CommunityProductBean;
import com.ozmobi.coupons.common.bean.CouponsGoodsBean;
import com.ozmobi.coupons.common.bean.FavoriteGoodsBean;
import com.ozmobi.coupons.common.bean.GoodsBean;

/**
 * Created by xhkj on 2019/3/26.
 */

public class GoodsConvertUtil {

    /**
     * 自动解析bean转可序列化bean
     *
     * @param commonBean
     * @return
     */
    public static GoodsBean convertToGoodsBean(CommonProductsEntity commonBean) {

        GoodsBean goods = new GoodsBean();

        try {
            //商品ID
            goods.setGoodsId(commonBean.getNum_iid());
            //商品URL
            goods.setGoodsUrl(commonBean.getItem_url());
            //商品icon
            goods.setIconUrl(commonBean.getPict_url());
            //商品名称
            goods.setTitle(commonBean.getTitle());
            //券值
            goods.setCouponValue(commonBean.getCoupon_price());
            //现价
            goods.setCurrentPrice(commonBean.getCurrent_price());
            //原价
            goods.setOriginPrice(commonBean.getOriginal_price());
            //领券链接
            goods.setCouponUrl(commonBean.getCoupon_click_url());
            //折扣率
            goods.setDiscountRate(commonBean.getCoupon_rate());
            //结束时间
            goods.setEndTime(commonBean.getEnd_time());
            //销量
            goods.setGoodsVolume(commonBean.getSales_volume());
            //券结束时间
            goods.setCouponEndTime(commonBean.getCoupon_end_time());

            //商品总量
            goods.setTotalAmount(commonBean.getTotal_amount());

            //没用到
            goods.setReservePrice(commonBean.getReserve_price());

            //优惠券开始时间
            goods.setCouponStartTime(commonBean.getCoupon_start_time());

            //店铺名
            goods.setShopTitle(commonBean.getShop_title());

            //开始时间
            goods.setStartTime(commonBean.getStart_time());

            //平台类型
            goods.setPlatType(commonBean.getPlat_type());

            //优惠率
            goods.setCouponRate(commonBean.getCoupon_rate());

            //产品链接，短链
            goods.setProductUrl(commonBean.getProduct_url());

            //店铺分
            goods.setShopScore(commonBean.getShop_score());

            //商品详情图组
            goods.setSmallImages(commonBean.getSmall_images());

            //商品分享赚
            goods.setShareFree(commonBean.getShare_fee());

            //返现率
            goods.setCommissionRate(commonBean.getCommission_rate());

            //返现
            goods.setCommissionFee(commonBean.getCommission_fee());

            //升级赚
            goods.setUpCommissionFee(commonBean.getUp_commission_fee());

            //分享链接
            goods.setShare(commonBean.getShare());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return goods;
    }

    /**
     * 自动解析bean转可序列化bean
     *
     * @param collectEntity
     * @return
     */
    public static GoodsBean convertToGoodsBean(FavoriteGoodsBean.DataEntity.CollectEntity collectEntity) {

        GoodsBean goods = new GoodsBean();
        try {
            //商品ID
            goods.setGoodsId(collectEntity.getNum_iid());
            //商品URL
            goods.setGoodsUrl(collectEntity.getItem_url());
            //商品icon
            goods.setIconUrl(collectEntity.getPict_url());
            //商品名称
            goods.setTitle(collectEntity.getTitle());
            //券值
            goods.setCouponValue(collectEntity.getCoupon_price());
            //现价
            goods.setCurrentPrice(collectEntity.getCurrent_price());
            //原价
            goods.setOriginPrice(collectEntity.getOriginal_price());
            //领券链接
            goods.setCouponUrl(collectEntity.getCoupon_click_url());
//        //折扣率
//        goods.setDiscountRate(collectEntity.getCoupon_rate());
//        //结束时间
//        goods.setEndTime(collectEntity.getEnd_time());
            //销量
            goods.setGoodsVolume(collectEntity.getSales_volume());
            //券结束时间
            goods.setCouponEndTime(collectEntity.getCoupon_end_time());

            //商品总量
//        goods.setTotalAmount(collectEntity.getTotal_amount());

            //没用到
//        goods.setReservePrice(collectEntity.getReserve_price());

            //优惠券开始时间
//        goods.setCouponStartTime(collectEntity.getCoupon_start_time());

            //店铺名
            goods.setShopTitle(collectEntity.getShop_title());

            //开始时间
//        goods.setStartTime(collectEntity.getStart_time());

            //平台类型
            goods.setPlatType(collectEntity.getPlat_type());

            //优惠率
//        goods.setCouponRate(collectEntity.getCoupon_rate());

            //产品链接，短链
            goods.setProductUrl(collectEntity.getProduct_url());

            //店铺分
            goods.setShopScore(collectEntity.getShop_score());

            //商品详情图组
            goods.setSmallImages(collectEntity.getSmall_images());

            //预估收益
            goods.setCommissionFee(collectEntity.getCommission_fee());

            //升级赚
            goods.setUpCommissionFee(collectEntity.getUp_commission_fee());

            //分享赚
            goods.setShareFree(collectEntity.getShare_fee());

            //分享链接
            goods.setShare(collectEntity.getShare());

            //返现率
            goods.setCommissionRate(collectEntity.getCommission_rate());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return goods;
    }

    /**
     * 自动解析bean转可序列化bean
     *
     * @param couponEntity
     * @return
     */
    public static GoodsBean convertToGoodsBean(CouponsGoodsBean.DataEntity.CouponEntity couponEntity) {

        GoodsBean goods = new GoodsBean();

        try {
            //商品ID
            goods.setGoodsId(couponEntity.getNum_iid());
            //商品URL
            goods.setGoodsUrl(couponEntity.getItem_url());
            //商品icon
            goods.setIconUrl(couponEntity.getPict_url());
            //商品名称
            goods.setTitle(couponEntity.getTitle());
            //券值
            goods.setCouponValue(couponEntity.getCoupon_price());
            //现价
            goods.setCurrentPrice(couponEntity.getCurrent_price());
            //原价
            goods.setOriginPrice(couponEntity.getOriginal_price());
            //领券链接
            goods.setCouponUrl(couponEntity.getCoupon_click_url());
//        //折扣率
//        goods.setDiscountRate(couponEntity.getCoupon_rate());
//        //结束时间
//        goods.setEndTime(couponEntity.getEnd_time());
            //销量
            goods.setGoodsVolume(couponEntity.getSales_volume());
            //券结束时间
            goods.setCouponEndTime(couponEntity.getCoupon_end_time());

            //商品总量
            goods.setTotalAmount(couponEntity.getTotal_amount());

            //没用到
//        goods.setReservePrice(couponEntity.getReserve_price());

            //优惠券开始时间
//        goods.setCouponStartTime(couponEntity.getCoupon_start_time());

            //店铺名
            goods.setShopTitle(couponEntity.getShop_title());

            //开始时间
//        goods.setStartTime(couponEntity.getStart_time());

            //平台类型
            goods.setPlatType(couponEntity.getPlat_type());

            //优惠率
//        goods.setCouponRate(couponEntity.getCoupon_rate());

            //产品链接，短链
            goods.setProductUrl(couponEntity.getProduct_url());

            //店铺分
            goods.setShopScore(couponEntity.getShop_score());

            //商品详情图组
            goods.setSmallImages(couponEntity.getSmall_images());

            //预估收益
            goods.setCommissionFee(couponEntity.getCommission_fee());

            //升级赚
            goods.setUpCommissionFee(couponEntity.getUp_commission_fee());

            //分享赚
            goods.setShareFree(couponEntity.getShare_fee());

            //分享链接
            goods.setShare(couponEntity.getShare());

            //返现率
            goods.setCommissionRate(couponEntity.getCommission_rate());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return goods;
    }

    /**
     * 自动解析bean转可序列化bean
     *
     * @param productEntity
     * @return
     */
    public static GoodsBean convertToGoodsBean(CommunityProductBean productEntity) {

        GoodsBean goods = new GoodsBean();

        try {
            //商品ID
            goods.setGoodsId(productEntity.getNum_iid());
            //商品URL
            goods.setGoodsUrl(productEntity.getItem_url());
            //商品icon
            goods.setIconUrl(productEntity.getPict_url());
            //商品名称
            goods.setTitle(productEntity.getTitle());
            //券值
            goods.setCouponValue(productEntity.getCoupon_price());
            //现价
            goods.setCurrentPrice(productEntity.getCurrent_price());
            //原价
            goods.setOriginPrice(productEntity.getOriginal_price());
            //领券链接
            goods.setCouponUrl(productEntity.getCoupon_click_url());
            //折扣率
            goods.setDiscountRate(productEntity.getCoupon_rate());
            //结束时间
            goods.setEndTime(productEntity.getEnd_time());
            //销量
            goods.setGoodsVolume(productEntity.getSales_volume());
            //券结束时间
            goods.setCouponEndTime(productEntity.getCoupon_end_time());

            //商品总量
            goods.setTotalAmount(productEntity.getTotal_amount());

            //没用到
            goods.setReservePrice(productEntity.getReserve_price());

            //优惠券开始时间
            goods.setCouponStartTime(productEntity.getCoupon_start_time());

            //店铺名
            goods.setShopTitle(productEntity.getShop_title());

            //开始时间
            goods.setStartTime(productEntity.getStart_time());

            //平台类型
            goods.setPlatType(productEntity.getPlat_type());

            //优惠率
            goods.setCouponRate(productEntity.getCoupon_rate());

            //产品链接，短链
            goods.setProductUrl(productEntity.getProduct_url());

            //店铺分
            goods.setShopScore(productEntity.getShop_score());

            //商品详情图组
            goods.setSmallImages(productEntity.getSmall_images());

            //预估收益
            goods.setCommissionFee(productEntity.getCommission_fee());

            //升级赚
            goods.setUpCommissionFee(productEntity.getUp_commission_fee());

            //分享赚
            goods.setShareFree(productEntity.getShare_fee());

            //分享链接
            goods.setShare(productEntity.getShare());

            //返现率
            goods.setCommissionRate(productEntity.getCommission_rate());

        } catch (Exception e) {
            e.printStackTrace();
        }

        return goods;
    }

    /**
     * 可序列化bean转自动解析bean
     *
     * @param goods
     * @return
     */
    /*public static CommonGoodsBean.DataEntity.ProductsEntity convertToProductsBean(GoodsBean goods) {

        CommonGoodsBean.DataEntity.ProductsBean productsBean = new CommonGoodsBean.DataEntity().ProductsEntity();

        try {
            //商品ID
            productsBean.setNum_iid(goods.getGoodsId());
            //商品URL
            productsBean.setItem_url(goods.getGoodsUrl());
            //商品icon
            productsBean.setPict_url(goods.getIconUrl());
            //商品名称
            productsBean.setTitle(goods.getTitle());
            //券值
            productsBean.setCoupon_price(goods.getCouponValue());
            //现价
            productsBean.setCurrent_price(goods.getCurrentPrice());
            //原价
            productsBean.setOriginal_price(goods.getOriginPrice());
            //领券链接
            productsBean.setCoupon_click_url(goods.getCouponUrl());
            //折扣率
            productsBean.setCoupon_rate(goods.getDiscountRate());
            //结束时间
            productsBean.setEnd_time(goods.getEndTime());
            //销量
            productsBean.setSales_volume(goods.getGoodsVolume());
            //券结束时间
            productsBean.setCoupon_end_time(goods.getCouponEndTime());

            //商品总量
            productsBean.setTotal_amount(goods.getTotalAmount());

            //没用到
            productsBean.setReserve_price(goods.getReservePrice());

            //优惠券开始时间
            productsBean.setCoupon_start_time(goods.getCouponStartTime());

            //店铺名
            productsBean.setShop_title(goods.getShopTitle());

            //开始时间
            productsBean.setStart_time(goods.getStartTime());

            //平台类型
            productsBean.setPlat_type(goods.getPlatType());

            //优惠率
            productsBean.setCoupon_rate(goods.getCouponRate());

            //产品链接，短链
            productsBean.setProduct_url(goods.getProductUrl());

            //店铺分
            productsBean.setShop_score(goods.getShopScore());

            //商品详情图组
            productsBean.setSmall_images(goods.getSmallImages());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return productsBean;
    }*/
}
