package com.ozmobi.coupons.common.data.bean;

import android.os.Parcel;
import android.os.Parcelable;

public class IntegralExchangeBean implements Parcelable {
    private int iconResId;
    private String title;
    private int num;
    private String desc;

    public IntegralExchangeBean(int iconResId, String title, int num, String desc) {
        this.iconResId = iconResId;
        this.title = title;
        this.num = num;
        this.desc = desc;
    }

    protected IntegralExchangeBean(Parcel in) {
        iconResId = in.readInt();
        title = in.readString();
        num = in.readInt();
        desc = in.readString();
    }

    public static final Creator<IntegralExchangeBean> CREATOR = new Creator<IntegralExchangeBean>() {
        @Override
        public IntegralExchangeBean createFromParcel(Parcel in) {
            return new IntegralExchangeBean(in);
        }

        @Override
        public IntegralExchangeBean[] newArray(int size) {
            return new IntegralExchangeBean[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(iconResId);
        dest.writeString(title);
        dest.writeInt(num);
        dest.writeString(desc);
    }

    public int getIconResId() {
        return iconResId;
    }

    public void setIconResId(int iconResId) {
        this.iconResId = iconResId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}