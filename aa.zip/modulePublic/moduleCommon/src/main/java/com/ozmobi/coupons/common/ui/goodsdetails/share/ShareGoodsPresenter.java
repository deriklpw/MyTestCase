package com.ozmobi.coupons.common.ui.goodsdetails.share;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.data.source.remote.GoodsDataRepository;

/**
 * Created by xhkj on 2019/7/4.
 */

public class ShareGoodsPresenter extends ShareGoodsContract.Presenter {
    private static final String TAG = "ShareGoodsPresenter";

    private String mGoodsId;

    ShareGoodsPresenter(String goodsId) {
        super(new GoodsDataRepository());
        mGoodsId = goodsId;
    }

    @Override
    public void start() {
        if (getBaseView() != null) {
            getBaseView().showLoading();
        }
        getShareText();
    }

    @Override
    public void getShareText() {
        if (TextUtils.isEmpty(mGoodsId) || getBaseRepository() == null) {
            if (getBaseView() != null && getBaseView().isLoading()) {
                getBaseView().hideLoading();
            }
            return;
        }
        addOperatorDisposable(getBaseRepository().getGoodsShareText(mGoodsId, shareTextBean -> {
            LogUtil.d(TAG, "getShareText: " + JSON.toJSONString(shareTextBean));
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                if (shareTextBean != null) {
                    if (shareTextBean.getError() == 0) {
                        getBaseView().showShareText(shareTextBean);
                    } else {
                        getBaseView().toastMsg(shareTextBean.getMsg());
                    }
                }
            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().showError();
            }
        }));
    }
}
