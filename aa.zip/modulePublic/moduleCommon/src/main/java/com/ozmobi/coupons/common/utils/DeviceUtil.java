package com.ozmobi.coupons.common.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.GlobalAppInfo;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.base.utils.PrefUtils;
import com.ozmobi.coupons.baichuan.AlibaichManager;
import com.ozmobi.coupons.base.manager.UserInfoManager;
import com.ozmobi.coupons.common.BuildConfig;
import com.ozmobi.coupons.common.CommonApplicationLikeImpl;

import java.net.NetworkInterface;

public class DeviceUtil {
    private static final String TAG = "DeviceUtil";
    private static final String CUSTOM_APP_ID = "1001";

    //读取首次启动时，选择性别，未登录时作为post参数
    private static String gender = "";

    //读取首次启动时，选择的偏好，作为每次post的参数
    private static String favorites = "";

    //避免每次通过api获取version
    private static String appVersion = "";

    public static String getAndroidID() {

        return Settings.Secure.getString(CommonApplicationLikeImpl.getContext().getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public static String getMacAddress() {
        try {
            String macAddress;
            StringBuilder stringBuilder = new StringBuilder();
            NetworkInterface networkInterface;
            networkInterface = NetworkInterface.getByName("eth1");
            if (networkInterface == null) {
                networkInterface = NetworkInterface.getByName("wlan0");
            }
            if (networkInterface == null) {
                return "02:00:00:00:00:02";
            }
            byte[] addr = networkInterface.getHardwareAddress();
            for (byte b : addr) {
                stringBuilder.append(String.format("%02X:", b));
            }
            if (stringBuilder.length() > 0) {
                stringBuilder.deleteCharAt(stringBuilder.length() - 1);
            }
            macAddress = stringBuilder.toString();
            return macAddress;
        } catch (Exception e) {
            return "";
        }
    }

/*    public static String getIMEI() {
        String imei = "";
        Context context = CouponsApplication.getInstance().getApplicationContext();
        try {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                if (tm.getDeviceId() == null) {
                    imei = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
                } else {
                    imei = tm.getDeviceId();
                }
                return imei;
            }

        } catch (Exception e) {
            imei = "";
        }
        return imei;
    }*/

    public static String getWidth() {
        String width = "";
        try {
            WindowManager windowManager = (WindowManager) CommonApplicationLikeImpl.getContext().getSystemService(Context.WINDOW_SERVICE);
            width = String.valueOf(windowManager.getDefaultDisplay().getWidth());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return width;
    }

    public static String getHeight() {
        String height = "";
        try {
            WindowManager windowManager = (WindowManager) CommonApplicationLikeImpl.getContext().getSystemService(Context.WINDOW_SERVICE);
            height = String.valueOf(windowManager.getDefaultDisplay().getHeight());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return height;
    }

    public static String getDpi() {
        DisplayMetrics displayMetrics = CommonApplicationLikeImpl.getContext().getResources().getDisplayMetrics();
        return String.valueOf(displayMetrics.densityDpi);
    }

    public static String getModel() {
        return Build.MODEL;
    }

    public static String getBrand() {
        return Build.BRAND;
    }

    public static String getSystemVersion() {
        return Build.VERSION.RELEASE;
    }

    public static String getAppVersion() {
        if (TextUtils.isEmpty(appVersion)) {
            Context context = CommonApplicationLikeImpl.getContext();
            try {
                PackageManager manager = context.getPackageManager();
                PackageInfo info = manager.getPackageInfo(context.getPackageName(), 0);
                appVersion = info.versionName;
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
        }
        return appVersion;
    }

    public static String getUserAgent() {
        WebView webView = new WebView(CommonApplicationLikeImpl.getContext());
        WebSettings webSettings = webView.getSettings();
        return webSettings.getUserAgentString();
    }

    public static String getTbId() {
        return AlibaichManager.getOpenId();
    }

    public static String getGender() {
        if (TextUtils.isEmpty(gender)) {
            gender = String.valueOf(PrefUtils.readInt(PrefUtils.KEY_USER_CONFIG_GENDER, 2));
        }
        return gender;
    }

    public static String getFavorites() {
        if (TextUtils.isEmpty(favorites)) {
            favorites = PrefUtils.readString(PrefUtils.KEY_USER_FAVORITES);
        }
        return favorites;
    }

    public static String getDeviceToken() {
        String deviceToken = GlobalAppInfo.deviceToken;
        return TextUtils.isEmpty(deviceToken) ? "" : deviceToken;
    }

    public static String getJsonDeviceInfo() {
        String commonParams = null;
        try {
            // 从存储文件中读取设备Json字符串
            commonParams = PrefUtils.readString(PrefUtils.KEY_USER_CONFIG_DEVICE_INFO);

            if (TextUtils.isEmpty(commonParams)) {
                JSONObject params = new JSONObject();

//                params.put("imei", getIMEI());
                params.put("mac", getMacAddress());
                params.put("android", getAndroidID());
                params.put("brand", getBrand());
                params.put("model", getModel());
                params.put("dpi", getDpi());

                params.put("width", getWidth());
                params.put("height", getHeight());
                params.put("sys_ver", getSystemVersion());
                params.put("ua", getUserAgent());
                // 保存Json字符串到文件中
                commonParams = params.toJSONString();
                PrefUtils.writeString(PrefUtils.KEY_USER_CONFIG_DEVICE_INFO, commonParams);
            }

            //会变化信息
            JSONObject jsonObject = JSON.parseObject(commonParams);
            jsonObject.put("tbid", getTbId());
            jsonObject.put("favorite", getFavorites());
            jsonObject.put("devicetoken", getDeviceToken());
            jsonObject.put("app_ver", getAppVersion());
            jsonObject.put("api", GlobalAppInfo.yjlApi);
            jsonObject.put("appid", GlobalAppInfo.channel);//可能走推广渠道

            if (UserInfoManager.getInstance().isLogin()) {
                String uid = UserInfoManager.getInstance().getUserInfo().getUid();
                String gender = UserInfoManager.getInstance().getUserInfo().getGender();
                if (!TextUtils.isEmpty(uid)) {
                    jsonObject.put("uid", uid);
                    jsonObject.put("gender", gender);
                }
            } else {
                //没有登录，使用最开始选择的性别
                jsonObject.put("gender", getGender());
            }
            commonParams = jsonObject.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        LogUtil.d("DeviceUtil", "getJsonDeviceInfo, json=" + commonParams);
        return commonParams;
    }

}
