package com.ozmobi.coupons.common.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.ui.goodsdetails.GoodsDetailsActivity;
import com.ozmobi.coupons.common.bean.CommonProductsEntity;
import com.ozmobi.coupons.common.ui.webpage.UrlDetailPageActivity;
import com.ozmobi.coupons.common.ui.search.result.SearchResultActivity;
import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.baichuan.AlibaichManager;
import com.ozmobi.coupons.common.utils.GlideUtils;
import com.ozmobi.coupons.common.utils.GoodsConvertUtil;
import com.umeng.analytics.MobclickAgent;

/**
 * Created by xhkj on 2019/3/19.
 */

public class ImagePushDialogFragment extends BaseDialogFragment {

    private static final String TAG = "ImagePushDialogFragment";

    private static final String ARG_PARAM_IMAGE_URL = "arg_param_image_url";

    private static final String ARG_PARAM_NAME = "arg_param_name";

    private static final String ARG_PARAM_DETAIL_URL = "arg_param_detail_url";

    private static final String ARG_PARAM_FOR_WELCOME_DIALOG = "for_welcome_dialog";

    private String mImageUrl;

    private String mName;

    private String mDetailUrl;

    private JSONObject mWelcomeObj;

    private ImageView mIvImage;

    public ImagePushDialogFragment() {
        // Required empty public constructor
    }

    public static ImagePushDialogFragment newInstanceForPush(String name, String imageUrl, String weblUrl) {
        ImagePushDialogFragment fragment = new ImagePushDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM_NAME, name);
        args.putString(ARG_PARAM_IMAGE_URL, imageUrl);
        args.putString(ARG_PARAM_DETAIL_URL, weblUrl);
        fragment.setArguments(args);
        return fragment;
    }

    public static ImagePushDialogFragment newInstanceForWelcome(String name, String imageUrl, JSONObject welcomeObj) {
        ImagePushDialogFragment fragment = new ImagePushDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM_NAME, name);
        args.putString(ARG_PARAM_IMAGE_URL, imageUrl);
        args.putSerializable(ARG_PARAM_FOR_WELCOME_DIALOG, welcomeObj);
        fragment.setArguments(args);
        return fragment;
    }

    public void updateForPush(String name, String imageUrl, String weblUrl) {
        mName = name;
        mImageUrl = imageUrl;
        mDetailUrl = weblUrl;
        if (mIvImage != null) {
            GlideUtils.loadIntoUseFitWidth(mImageUrl, mIvImage);
        }
    }

    public void updateForWelcome(String name, String imageUrl, JSONObject welcomeObj) {
        mName = name;
        mImageUrl = imageUrl;
        mWelcomeObj = welcomeObj;
        if (mIvImage != null) {
            GlideUtils.loadIntoUseFitWidth(mImageUrl, mIvImage);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mName = getArguments().getString(ARG_PARAM_NAME);
            mImageUrl = getArguments().getString(ARG_PARAM_IMAGE_URL);
            mDetailUrl = getArguments().getString(ARG_PARAM_DETAIL_URL);
            mWelcomeObj = (JSONObject) getArguments().getSerializable(ARG_PARAM_FOR_WELCOME_DIALOG);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.d(TAG, "onResume: ");
        MobclickAgent.onPageStart(TAG);
    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.d(TAG, "onPause: ");
        MobclickAgent.onPageEnd(TAG);
    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtil.d(TAG, "onStop: ");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateView: ");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateDialog: ");
        AlertDialog dialog = new AlertDialog.Builder(mContext).create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.CENTER);
        window.setContentView(R.layout.common_dialog_fragment_image_push);

        mIvImage = window.findViewById(R.id.iv_image_push);
        ImageButton ibnClose = window.findViewById(R.id.ibn_image_push_dialog_close);

        GlideUtils.loadIntoUseFitWidth(mImageUrl, mIvImage);

        mIvImage.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                getDialog().dismiss();
                if (mWelcomeObj != null) {
                    try {
                        String type = mWelcomeObj.getString("type");
                        String url = mWelcomeObj.getString("url");

                        if ("link".equals(type)) {
                            int tb = mWelcomeObj.getIntValue("tb");
                            if (!TextUtils.isEmpty(url)) {
                                if (tb == 1) {
                                    //淘宝链接
                                    AlibaichManager.showUrlPage((Activity)mContext, url);
                                } else {
                                    //非淘宝链接
                                    UrlDetailPageActivity.startForUrlDetail(mContext, mName, url, UrlDetailPageActivity.URL_COMMON);
                                }
                            }

                        } else if ("product".equals(type)) {
                            //商品信息
                            JSONObject productObj = mWelcomeObj.getJSONObject("product");
                            CommonProductsEntity product = JSONObject.parseObject(productObj.toJSONString(), CommonProductsEntity.class);
                            if (product != null) {
                                GoodsDetailsActivity.startForGoodDetail(mContext, GoodsConvertUtil.convertToGoodsBean(product));
                            }

                        } else if ("list".equals(type)) {
                            SearchResultActivity.startActivityForUrlGoods(mContext, mName, url);
//                            HomeContainerActivity.startActivityForUrlGoods(mContext, url, mName);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    UrlDetailPageActivity.startForUrlDetail(mContext, mName, mDetailUrl, UrlDetailPageActivity.URL_COMMON);
                }
            }
        });

        ibnClose.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                getDialog().dismiss();
            }
        });

        return dialog;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        LogUtil.d(TAG, "onAttach: ");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        LogUtil.d(TAG, "onDetach: ");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtil.d(TAG, "onDestroy: ");
    }

}
