package com.ozmobi.coupons.common.ui.search;

import com.ozmobi.coupons.common.AbsBasePresenter;
import com.ozmobi.coupons.common.BaseView;
import com.ozmobi.coupons.common.bean.QuerySugBean;
import com.ozmobi.coupons.common.data.source.SearchDataSource;

import java.util.ArrayList;

/**
 * Created by xhkj on 2019/3/15.
 */

public interface SearchContract {

    interface View extends BaseView {

        void showQuerySug(QuerySugBean querySugBean);

        void showHintWords(ArrayList<String> hotWords, ArrayList<String> historyWords);

    }

    abstract class Presenter extends AbsBasePresenter<SearchContract.View, SearchDataSource> {

        public Presenter(SearchDataSource searchDataSource) {
            super(searchDataSource);
        }

        abstract void saveHistory(String text);

        abstract void clearHistory();

        abstract void query(String query);
    }
}
