package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.common.bean.ContactQrBean;
import com.ozmobi.coupons.common.bean.CouponsGoodsBean;
import com.ozmobi.coupons.common.bean.FavoriteGoodsBean;
import com.ozmobi.coupons.common.bean.GoodsBean;
import com.ozmobi.coupons.common.bean.IncomeBean;
import com.ozmobi.coupons.common.bean.IncomeDetailBean;
import com.ozmobi.coupons.common.bean.PresentIncomeBean;
import com.ozmobi.coupons.common.bean.QueryStateBean;
import com.ozmobi.coupons.common.bean.RecordBean;
import com.ozmobi.coupons.common.bean.TKLBean;

import java.util.List;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

/**
 * Created by xhkj on 2019/3/19.
 */

public interface MineDataSource extends BaseDataSource {

    interface MineResultCallback {

        void onSuccess();

        void onError();
    }

    interface QueryHistoryCallback {

        void onHistoryGoodLoaded(List<GoodsBean> historyGoods);

        void onDataNotAvailable();
    }

    /**
     * 用户反馈
     *
     * @param id
     * @param content
     * @param callback
     * @return
     */
    Disposable feedbackContent(@NonNull String id, @NonNull String content, @Nullable MineResultCallback callback);

    /**
     * 添加收藏
     *
     * @param goodsBean
     * @param callback
     * @return
     */
    Disposable addFavoriteGoods(@NonNull GoodsBean goodsBean, @Nullable MineResultCallback callback);

    /**
     * 删除收藏
     *
     * @param id
     * @param callback
     * @return
     */
    Disposable deleteFavoriteGoods(@NonNull String id, @Nullable MineResultCallback callback);


    /**
     * 查新收藏状态
     * @param goodsId
     * @param success
     * @param error
     * @return
     */
    Disposable queryCollectStateGoods(@NonNull String goodsId, @NonNull Consumer<? super QueryStateBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 查询收藏商品
     *
     * @return
     */
    Disposable queryFavoriteGoods(@NonNull Consumer<? super FavoriteGoodsBean> success, @NonNull Consumer<? super Throwable> error);


    /**
     * 添加已领优惠券
     *
     * @param goodsBean
     * @param callback
     * @return
     */
    Disposable addCouponGoods(@NonNull GoodsBean goodsBean, @Nullable MineResultCallback callback);

    /**
     * 删除已领优惠券
     *
     * @param id
     * @param callback
     * @return
     */
    Disposable deleteCouponGoods(@NonNull String id, @Nullable MineResultCallback callback);

    /**
     * 查询已领优惠券
     *
     * @return
     */
    Disposable queryCouponGoods(@NonNull Consumer<? super CouponsGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 添加浏览历史
     *
     * @param goodsBean
     * @param callback
     * @return
     */
    Disposable addHistoryGoods(@NonNull GoodsBean goodsBean, @Nullable MineResultCallback callback);

    /**
     * 删除浏览历史
     *
     * @param goodsBean
     * @param callback
     * @return
     */
    Disposable deleteHistoryGoods(@NonNull GoodsBean goodsBean, @Nullable MineResultCallback callback);

    /**
     * 查询浏览历史
     *
     * @param callback
     * @return
     */
    Disposable queryHistoryGoods(@Nullable QueryHistoryCallback callback);

    /**
     * 淘口令
     *
     * @param goodsBean
     * @return
     */
    Disposable getTKL(@NonNull GoodsBean goodsBean, @NonNull Consumer<? super TKLBean> success, @NonNull Consumer<? super Throwable> error);

//    /**
//     * 我的粉丝
//     *
//     * @param success
//     * @param error
//     * @return
//     */
//    Disposable getMyFans(@NonNull Consumer<? super FansBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 我的收益
     *
     * @param success
     * @param error
     * @return
     */
    Disposable getMyIncome(@NonNull Consumer<? super IncomeBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 我的收益明细
     *
     * @param success
     * @param error
     * @return
     */
    Disposable getMyIncomeDetail(@NonNull Consumer<? super IncomeDetailBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 提现记录
     *
     * @param success
     * @param error
     * @return
     */
    Disposable withdrawRecord(@NonNull Consumer<? super RecordBean> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 绑定支付宝账号
     *
     * @param mobile
     * @param messageCode
     * @param alipayAccount
     * @param alipayName
     * @param success
     * @param error
     * @return
     */
    Disposable bindAlipayAccount(@NonNull String mobile, @NonNull String messageCode, @NonNull String alipayAccount, @NonNull String alipayName, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 提现
     *
     * @param money
     * @param success
     * @param error
     * @return
     */
    Disposable withdraw(String money, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取用户信息
     *
     * @param success
     * @param error
     * @return
     */
    Disposable getUserInfo(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 绑定淘宝订单
     *
     * @param tradeIds
     * @param success
     * @param error
     * @return
     */
    Disposable bindOrders(String tradeIds, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 查询已绑定订单
     *
     * @param success
     * @param error
     * @return
     */
    Disposable queryMyOrders(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取个人专属邀请信息
     *
     * @param success
     * @param error
     * @return
     */
    Disposable getMyInvitePages(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 提交商务合作
     *
     * @param company
     * @param name
     * @param job
     * @param mobile
     * @param intention
     * @param success
     * @param error
     * @return
     */
    Disposable submitBusiness(@NonNull String company, @NonNull String name, @Nullable String job, @NonNull String mobile, @NonNull String intention, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 用户收益汇总
     *
     * @param success
     * @param error
     * @return
     */
    Disposable getUserPresentIncome(@NonNull Consumer<? super PresentIncomeBean> success, @NonNull Consumer<? super Throwable> error);


    /**
     * 微信客服
     *
     * @param success
     * @param error
     * @return
     */
    Disposable getCustomerWeChatInfo(@NonNull Consumer<? super ContactQrBean> success, @NonNull Consumer<? super Throwable> error);

}
