package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.CommonApplicationLikeImpl;
import com.ozmobi.coupons.common.bean.ContactQrBean;
import com.ozmobi.coupons.common.bean.CouponsGoodsBean;
import com.ozmobi.coupons.common.bean.FavoriteGoodsBean;
import com.ozmobi.coupons.common.bean.FeedbackBean;
import com.ozmobi.coupons.common.bean.GoodsBean;
import com.ozmobi.coupons.common.bean.IncomeBean;
import com.ozmobi.coupons.common.bean.IncomeDetailBean;
import com.ozmobi.coupons.common.bean.PresentIncomeBean;
import com.ozmobi.coupons.common.bean.QueryStateBean;
import com.ozmobi.coupons.common.bean.RecordBean;
import com.ozmobi.coupons.common.bean.TKLBean;
import com.ozmobi.coupons.common.data.source.MineDataSource;
import com.ozmobi.coupons.common.greendao.DaoSession;
import com.ozmobi.coupons.common.greendao.GoodsBeanDao;
import com.ozmobi.coupons.base.manager.UserInfoManager;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.CompletableEmitter;
import io.reactivex.CompletableOnSubscribe;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.observers.DisposableCompletableObserver;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

/**
 * Created by xhkj on 2019/3/19.
 */

public class MineDataRepository implements MineDataSource {

    private static final String TAG = "MineDataRepository";

    public Disposable feedbackContent(@NonNull String id, @NonNull String content, @Nullable MineResultCallback callback) {
        String json = "";

        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());

            rootJson.put("uid", id);

            rootJson.put("content", content);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "feedback post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().feedbackContent(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<FeedbackBean>() {
                    @Override
                    public void accept(FeedbackBean feedbackBean) throws Exception {
                        if (callback != null) {
                            if (feedbackBean != null) {
                                if (feedbackBean.getError() == 0) {
                                    LogUtil.d(TAG, "feedback response json=" + JSON.toJSONString(feedbackBean));
                                    callback.onSuccess();
                                } else {
                                    LogUtil.d(TAG, "feedback response no data");
                                    callback.onError();
                                }
                            }
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        LogUtil.d(TAG, "feedback response no data, error");
                        if (callback != null) {
                            callback.onError();
                        }
                    }
                });
    }

    @Override
    public Disposable queryCollectStateGoods(@NonNull String goodsId, @NonNull Consumer<? super QueryStateBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";

        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("num_iid", goodsId);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "query collect post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().queryCollectStateGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable addFavoriteGoods(@NonNull GoodsBean goodsBean, @Nullable MineResultCallback callback) {
        String json = "";

        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("num_iid", goodsBean.getGoodsId());
//            params.put("title", goodsBean.getTitle());
//            params.put("sales_volume", goodsBean.getGoodsVolume());
//            params.put("original_price", goodsBean.getOriginPrice());
//            params.put("current_price", goodsBean.getCurrentPrice());
//            params.put("coupon_price", TextUtils.isEmpty(goodsBean.getCouponValue()) ? "" : goodsBean.getCouponValue()); //和券相关的需要判断
//            params.put("pict_url", goodsBean.getIconUrl());
//            params.put("item_url", goodsBean.getGoodsUrl());
//            params.put("coupon_click_url", TextUtils.isEmpty(goodsBean.getCouponUrl()) ? "" : goodsBean.getCouponUrl());
//            params.put("coupon_end_time", TextUtils.isEmpty(goodsBean.getCouponEndTime()) ? "" : goodsBean.getCouponEndTime());

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "add favorite post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().addFavoriteGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<com.alibaba.fastjson.JSONObject>() {
                    @Override
                    public void accept(com.alibaba.fastjson.JSONObject addResponseBean) throws Exception {
                        if (callback != null) {
                            if (addResponseBean != null) {
                                LogUtil.d(TAG, "add favorite response json = " + JSON.toJSONString(addResponseBean));
                                callback.onSuccess();
                            } else {
                                LogUtil.d(TAG, "add favorite response no data");
                                callback.onError();
                            }
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        LogUtil.d(TAG, "add favorite response no data, error");
                        if (callback != null) {
                            callback.onError();
                        }
                    }
                });
    }

    @Override
    public Disposable deleteFavoriteGoods(@NonNull String id, @Nullable MineResultCallback callback) {
        String json = "";

        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("num_iid", id);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "delete favorite post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().deleteFavoriteGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<com.alibaba.fastjson.JSONObject>() {
                    @Override
                    public void accept(com.alibaba.fastjson.JSONObject deleteResponseBean) throws Exception {
                        if (callback != null) {
                            if (deleteResponseBean != null) {
                                LogUtil.d(TAG, "delete favorite response json = " + JSON.toJSONString(deleteResponseBean));
                                callback.onSuccess();
                            } else {
                                LogUtil.d(TAG, "delete favorite response no data");
                                callback.onError();
                            }
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        LogUtil.d(TAG, "delete favorite response no data, error");
                        if (callback != null) {
                            callback.onError();
                        }
                    }
                });
    }

    @Override
    public Disposable queryFavoriteGoods(@NonNull Consumer<? super FavoriteGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "query favorite post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().queryFavoriteGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable addCouponGoods(@NonNull GoodsBean goodsBean, @Nullable MineResultCallback callback) {
        String json = "";

        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("num_iid", goodsBean.getGoodsId());
//            params.put("title", goodsBean.getTitle());
//            params.put("sales_volume", goodsBean.getGoodsVolume());
//            params.put("original_price", goodsBean.getOriginPrice());
//            params.put("current_price", goodsBean.getCurrentPrice());
//            params.put("coupon_price", TextUtils.isEmpty(goodsBean.getCouponValue()) ? "" : goodsBean.getCouponValue()); //和券相关的需要判断
//            params.put("pict_url", goodsBean.getIconUrl());
//            params.put("item_url", goodsBean.getGoodsUrl());
//            params.put("coupon_click_url", TextUtils.isEmpty(goodsBean.getCouponUrl()) ? "" : goodsBean.getCouponUrl());
//            params.put("coupon_end_time", TextUtils.isEmpty(goodsBean.getCouponEndTime()) ? "" : goodsBean.getCouponEndTime());

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "add coupon post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().addCouponsGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<com.alibaba.fastjson.JSONObject>() {
                    @Override
                    public void accept(com.alibaba.fastjson.JSONObject addResponseBean) throws Exception {
                        if (callback != null) {
                            if (addResponseBean != null) {
                                LogUtil.d(TAG, "add coupons response json=" + JSON.toJSONString(addResponseBean));
                                callback.onSuccess();
                            } else {
                                LogUtil.d(TAG, "add coupons response no data");
                                callback.onError();
                            }
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        LogUtil.d(TAG, "add coupons response no data, error");
                        if (callback != null) {
                            callback.onError();
                        }
                    }
                });
    }

    @Override
    public Disposable deleteCouponGoods(@NonNull String id, @Nullable MineResultCallback callback) {
        String json = "";

        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("num_iid", id);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "delete coupon post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().deleteCouponsGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<com.alibaba.fastjson.JSONObject>() {
                    @Override
                    public void accept(com.alibaba.fastjson.JSONObject deleteResponseBean) throws Exception {
                        if (callback != null) {
                            if (deleteResponseBean != null) {
                                LogUtil.d(TAG, "delete coupons response json=" + JSON.toJSONString(deleteResponseBean));
                                callback.onSuccess();
                            } else {
                                LogUtil.d(TAG, "delete coupons response no data");
                                callback.onError();
                            }
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        LogUtil.d(TAG, "delete coupons response no data, error");
                        if (callback != null) {
                            callback.onError();
                        }
                    }
                });
    }

    @Override
    public Disposable queryCouponGoods(@NonNull Consumer<? super CouponsGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "query coupon post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().queryCouponsGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

    @Override
    public Disposable addHistoryGoods(@NonNull GoodsBean goodsBean, @Nullable MineResultCallback callback) {
        return Completable.create(new CompletableOnSubscribe() {
            @Override
            public void subscribe(CompletableEmitter emitter) throws Exception {
                try {
                    DaoSession daoSession = CommonApplicationLikeImpl.getDaoSession();
                    daoSession.getGoodsBeanDao().insertOrReplace(goodsBean);
                    emitter.onComplete();
                } catch (Exception e) {
                    emitter.onError(e);
                }
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableCompletableObserver() {
                    @Override
                    public void onStart() {
                        LogUtil.d(TAG, "addHistoryGoods onStart: ");
                    }

                    @Override
                    public void onError(Throwable error) {
                        error.printStackTrace();
                        LogUtil.d(TAG, "addHistoryGoods onError: ");
                        if (callback != null) {
                            callback.onError();
                        }
                    }

                    @Override
                    public void onComplete() {
                        LogUtil.d(TAG, "addHistoryGoods onComplete: ");
                        if (callback != null) {
                            callback.onSuccess();
                        }
                    }
                });
    }

    @Override
    public Disposable deleteHistoryGoods(@NonNull GoodsBean goodsBean, @Nullable MineResultCallback callback) {
        return Completable.create(new CompletableOnSubscribe() {
            @Override
            public void subscribe(CompletableEmitter emitter) throws Exception {
                try {
                    DaoSession daoSession = CommonApplicationLikeImpl.getDaoSession();
                    daoSession.getGoodsBeanDao().deleteByKey(goodsBean.getGoodsId());
                    LogUtil.d(TAG, "deleteHistoryGoods subscribe: ");
                    emitter.onComplete();
                } catch (Exception e) {
                    emitter.onError(e);
                }
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableCompletableObserver() {
                    @Override
                    public void onStart() {
                        LogUtil.d(TAG, "deleteHistoryGoods onStart: ");
                    }

                    @Override
                    public void onError(Throwable error) {
                        error.printStackTrace();
                        LogUtil.d(TAG, "deleteHistoryGoods onError: ");
                        if (callback != null) {
                            callback.onError();
                        }
                    }

                    @Override
                    public void onComplete() {
                        LogUtil.d(TAG, "deleteHistoryGoods onComplete: ");
                        if (callback != null) {
                            callback.onSuccess();
                        }
                    }
                });
    }

    @Override
    public Disposable queryHistoryGoods(@Nullable QueryHistoryCallback callback) {
        return Observable.create(new ObservableOnSubscribe<List<GoodsBean>>() {
            @Override
            public void subscribe(ObservableEmitter<List<GoodsBean>> emitter) throws Exception {
                DaoSession daoSession = CommonApplicationLikeImpl.getDaoSession();
                List<GoodsBean> goods = daoSession.getGoodsBeanDao().queryBuilder().orderDesc(GoodsBeanDao.Properties.BrowserTime).list();
                emitter.onNext(goods);
                emitter.onComplete();
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<List<GoodsBean>>() {
                    @Override
                    public void accept(List<GoodsBean> historyGoods) throws Exception {
                        if (callback != null) {
                            if (historyGoods != null) {
                                LogUtil.d(TAG, "queryHistoryGoods json = " + JSON.toJSONString(historyGoods));
                                callback.onHistoryGoodLoaded(historyGoods);
                            } else {
                                LogUtil.d(TAG, "queryHistoryGoods: null");
                                callback.onDataNotAvailable();
                            }
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        LogUtil.d(TAG, "queryHistoryGoods: error");
                        if (callback != null) {
                            callback.onDataNotAvailable();
                        }
                    }
                });
    }

    @Override
    public Disposable getTKL(@NonNull GoodsBean goodsBean, @NonNull Consumer<? super TKLBean> success, @NonNull Consumer<? super Throwable> error) {

        String json = "";

        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("num_iid", goodsBean.getGoodsId());

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "get tkl post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
        return ApiFactory.getYjlController().getTKL(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }

//    @Override
//    public Disposable getMyFans(@NonNull Consumer<? super FansBean> success, @NonNull Consumer<? super Throwable> error) {
//        String json = DeviceUtil.getJsonDeviceInfo();
//
//        LogUtil.d(TAG, "fans post json=" + json);
//
//        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);
//
//        Observable<FansBean> observable = ApiFactory.getYjlController().getMyFans(requestBody)
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread());
//
//        return observable.subscribe(success, error);
//    }

    @Override
    public Disposable getMyIncome(@NonNull Consumer<? super IncomeBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "my income post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<IncomeBean> observable = ApiFactory.getYjlController().getMyIncome(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getMyIncomeDetail(@NonNull Consumer<? super IncomeDetailBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "income detail post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<IncomeDetailBean> observable = ApiFactory.getYjlController().getMyIncomeDetail(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable withdrawRecord(@NonNull Consumer<? super RecordBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "withdraw record post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<RecordBean> observable = ApiFactory.getYjlController().withdrawRecord(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable bindAlipayAccount(@NonNull String mobile, @NonNull String messageCode, @NonNull String alipayAccount, @NonNull String alipayName, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("mobile", mobile);
            params.put("code", messageCode);
            params.put("alipay", alipayAccount);
            params.put("alipay_name", alipayName);

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "bind post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController().bindAlipayAccount(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable withdraw(String money, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("amount", money);

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "withdraw post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController().withdraw(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getUserInfo(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "get userinfo post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController().queryUserInfo(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
//                        DeviceUtil.saveUserInfo(userInfo.toJSONString());
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable bindOrders(String tradeIds, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("trade_id", tradeIds);

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "bind orders post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController().bindOrders(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable queryMyOrders(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "query orders post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController().queryMyOrders(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getMyInvitePages(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "get invite pagers post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController().getMyInvitePages(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable submitBusiness(@NonNull String company, @NonNull String name, @Nullable String job, @NonNull String mobile, @NonNull String intention, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("company", company);
            params.put("name", name);

            if (!TextUtils.isEmpty(job)) {
                params.put("jobs", job);
            }

            params.put("mobile", mobile);
            params.put("intention", intention);

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "submit business post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController().submitBusiness(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getUserPresentIncome(@NonNull Consumer<? super PresentIncomeBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "get user present income post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<PresentIncomeBean> observable = ApiFactory.getYjlController().getUserPresentIncome(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getCustomerWeChatInfo(@NonNull Consumer<? super ContactQrBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "get CustomerWeChatInfo post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<ContactQrBean> observable = ApiFactory.getYjlController().getCustomerWeChatInfo(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }
}
