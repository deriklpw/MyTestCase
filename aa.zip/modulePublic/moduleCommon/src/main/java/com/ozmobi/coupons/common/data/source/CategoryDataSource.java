package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.common.bean.CategoryBean;
import com.ozmobi.coupons.common.bean.UpdateBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public interface CategoryDataSource extends BaseDataSource {

    Disposable getCategory(@NonNull Consumer<? super CategoryBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable checkUpdate(@NonNull Consumer<? super UpdateBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getWelcomeDialogInfo (@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);
}
