package com.ozmobi.coupons.common.utils;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.TextUtils;

/**
 * Created by xhkj on 2019/6/25.
 */

public class ClipBoardUtil {

    /**
     * 使用统一名称作为剪贴板信息描述
     *
     * @param context
     * @param text
     * @return
     */
    public static boolean copyTextWithAppLabel(Context context, String text) {
        return context != null && copyText(context, context.getPackageName(), text);
    }

    /**
     * 使用指定名称作为剪贴板信息描述
     *
     * @param context
     * @param label
     * @param text
     * @return
     */
    public static boolean copyText(Context context, String label, String text) {
        boolean result;
        if (TextUtils.isEmpty(text)) {
            return false;
        }

        ClipData clipData = ClipData.newPlainText(label, text);
        ClipboardManager cmb = (ClipboardManager) context.getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (cmb != null) {
            cmb.setPrimaryClip(clipData);
            result = true;
        } else {
            result = false;
        }
        return result;
    }

    public static String getClipText(Context context) {
        String text = null;
        ClipboardManager cmb = (ClipboardManager) context.getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (cmb != null && cmb.hasPrimaryClip()) {
            ClipData clipData = cmb.getPrimaryClip();

            if (clipData != null && clipData.getItemCount() > 0 && clipData.getItemAt(0).getText() != null) {
                text = clipData.getItemAt(0).getText().toString();
            }
        }
        return text;
    }


    public static boolean isSelfAppCopyText(Context context) {
        boolean result = false;
        if (context == null) {
            return  result;
        }
        ClipboardManager cmb = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cmb != null && cmb.hasPrimaryClip()) {
            ClipData clipData = cmb.getPrimaryClip();

            CharSequence label = null;
            if (clipData != null && clipData.getDescription() != null) {
                label = clipData.getDescription().getLabel();
            }

            String appName = context.getPackageName();
            result = label != null && appName.equals(label.toString());
        }

        return result;
    }

    public static void clearClip(Context context) {
        ClipboardManager cmb = (ClipboardManager) context.getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (cmb != null) {
            ClipData clipData = ClipData.newPlainText(null, "");
            cmb.setPrimaryClip(clipData);
        }
    }
}
