package com.ozmobi.coupons.common.ui.search;

import android.text.TextUtils;

import com.ozmobi.coupons.base.Constants;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.base.utils.PrefUtils;
import com.ozmobi.coupons.common.CommonApplicationLikeImpl;
import com.ozmobi.coupons.common.data.source.remote.SearchRepository;

import java.util.ArrayList;

/**
 * Created by xhkj on 2019/3/15.
 */

public class SearchPresenter extends SearchContract.Presenter {

    private static final String TAG = "SearchPresenter";

    private ArrayList<String> mHotWords;

    SearchPresenter() {
        super(new SearchRepository());
    }

    @Override
    public void start() {
        try {
            //数据量小，直接读取
            if (mHotWords == null) {
                mHotWords = PrefUtils.getCurrentObject(CommonApplicationLikeImpl.getContext(), PrefUtils.SEARCH_HOT_WORDS, ArrayList.class);
            }
            ArrayList<String> historyWords = PrefUtils.getCurrentObject(CommonApplicationLikeImpl.getContext(), PrefUtils.SEARCH_HISTORY, ArrayList.class);

            if (mHotWords == null) {
                return;
            }
            LogUtil.d(TAG, "start: hot words=" + mHotWords.size());

            if (getBaseView() != null) {
                getBaseView().showHintWords(mHotWords, historyWords);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void saveHistory(String text) {
        try {
            if (TextUtils.isEmpty(text)) {
                return;
            }
            ArrayList<String> historyWords = PrefUtils.getCurrentObject(CommonApplicationLikeImpl.getContext(), PrefUtils.SEARCH_HISTORY, ArrayList.class);
            if (historyWords != null) {
                if (historyWords.contains(text)) {
                    historyWords.remove(text);
                }
            } else {
                historyWords = new ArrayList<>();
            }

            if (historyWords.size() >= Constants.SEARCH_HISTORY_SAVE_MAX) {
                historyWords.remove(0);
            }

            historyWords.add(text);
            LogUtil.d(TAG, "saveHistory: word= " + text);
            PrefUtils.setCurrentObject(CommonApplicationLikeImpl.getContext(), PrefUtils.SEARCH_HISTORY, historyWords);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void clearHistory() {
        PrefUtils.clearCurrentObject(CommonApplicationLikeImpl.getContext(), PrefUtils.SEARCH_HISTORY);
    }

    @Override
    public void query(String query) {
        if (getBaseRepository() == null) {
            return;
        }
        addOperatorDisposable(getBaseRepository().getQuerySug(query, querySugBean -> {
            if (getBaseView() != null) {
                getBaseView().showQuerySug(querySugBean);
            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }));
    }

    @Override
    public void destroy() {
        super.destroy();
        mHotWords = null;
    }
}
