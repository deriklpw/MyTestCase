package com.ozmobi.coupons.common.ui.imageviewer;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;

import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.BaseActivity;
import com.ozmobi.coupons.base.Constants;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.utils.GlideUtils;
import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.base.utils.BitmapUtil;
import com.ozmobi.coupons.base.utils.FileDigestUtil;
import com.ozmobi.coupons.base.utils.FileUtils;
import com.ozmobi.coupons.base.utils.MediaUtil;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.PermissionListener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class PictureViewerActivity extends BaseActivity implements PictureViewerFragment.ClickCallback {

    private static final String TAG = "PictureViewerActivity";

    //存储
    private static final int REQUEST_CODE_PERMISSION_STORAGE = 100;

    private static final String EXTRA_KEY_IMAGE_PATHS = "extra_key_image_paths";

    private static final String EXTRA_KEY_IMAGE_URLS = "extra_key_image_urls";

    private static final String EXTRA_KEY_IMAGE_POSITION = "extra_key_image_position";

    private static final String EXTRA_KEY_REQUEST_CODE = "extra_key_request_code";

//    private static final String TRANSIT_PIC = "rl_picture";

    //预览本地图片
    private List<String> mListImagePath;

    //预览网络图片
    private List<String> mListImageUrl;

    private int mCurrentPosition;

    private int mRequestCode;

    private static final int CURRENT_POSITION_DEFAULT = 0;

    private static final int REQUEST_CODE_DEFAULT = -1;

    private List<PictureViewerFragment> mFragments;

    @Override
    protected int getLayoutId() {
        return R.layout.common_activity_picture_viewer;
    }

    @Override
    protected void initViews() {
        //全屏
        hideNavigationBar();
        hideAppbar();

        ViewPager viewPager = findViewById(R.id.viewpager_picture);

        Button btnSave = findViewById(R.id.btn_picture_save);

        try {
            mListImagePath = getIntent().getStringArrayListExtra(EXTRA_KEY_IMAGE_PATHS);
            mListImageUrl = getIntent().getStringArrayListExtra(EXTRA_KEY_IMAGE_URLS);

            mCurrentPosition = getIntent().getIntExtra(EXTRA_KEY_IMAGE_POSITION, CURRENT_POSITION_DEFAULT);
            mRequestCode = getIntent().getIntExtra(EXTRA_KEY_REQUEST_CODE, REQUEST_CODE_DEFAULT);

            mFragments = new ArrayList<>();
            if (mListImagePath != null && mListImagePath.size() > 0) {
                for (int i = 0; i < mListImagePath.size(); i++) {
                    PictureViewerFragment fragment = PictureViewerFragment.newInstance(mListImagePath.get(i), null);
                    mFragments.add(fragment);
                }
            } else if (mListImageUrl != null && mListImageUrl.size() > 0) {
                for (int i = 0; i < mListImageUrl.size(); i++) {
                    PictureViewerFragment fragment = PictureViewerFragment.newInstance(null, mListImageUrl.get(i));
                    mFragments.add(fragment);
                }
            }

            PictureViewerPagerAdapter adapter = new PictureViewerPagerAdapter(getSupportFragmentManager());
            viewPager.setAdapter(adapter);
            viewPager.setCurrentItem(mCurrentPosition);

            viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                }

                @Override
                public void onPageSelected(int position) {
                    LogUtil.d(TAG, "onPageSelected: position=" + position);
                    mCurrentPosition = position;
                }

                @Override
                public void onPageScrollStateChanged(int state) {

                }
            });

            btnSave.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    if (Build.VERSION.SDK_INT >= 23) {
                        if (ContextCompat.checkSelfPermission(PictureViewerActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            AndPermission.with(PictureViewerActivity.this)
                                    .requestCode(REQUEST_CODE_PERMISSION_STORAGE)
                                    .permission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                                    .callback(new PermissionListener() {
                                        @Override
                                        public void onSucceed(int requestCode, @NonNull List<String> grantPermissions) {
                                            if (requestCode == REQUEST_CODE_PERMISSION_STORAGE) {
                                                saveImageToAlbums();
                                            }
                                        }

                                        @Override
                                        public void onFailed(int requestCode, @NonNull List<String> deniedPermissions) {
                                            if (requestCode == REQUEST_CODE_PERMISSION_STORAGE) {
                                                toastMsg(getString(R.string.common_get_sd_permission_error));
                                            }
                                        }
                                    })
                                    .start();
                        } else {
                            saveImageToAlbums();
                        }
                    } else {
                        saveImageToAlbums();
                    }
                }
            });

//            ViewCompat.setTransitionName(mViewPager, TRANSIT_PIC);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 图片复制到另一sd卡目录存储，并同步到相册
     */
    private void saveImageToAlbums() {
        try {
            if (mListImagePath != null && mListImagePath.size() > 0) {
                String imagePath = mListImagePath.get(mCurrentPosition);
                if (!TextUtils.isEmpty(imagePath)) {
                    File srcFile = new File(imagePath);
                    String md5tr = FileDigestUtil.getFileMD5(srcFile);
                    if (!TextUtils.isEmpty(md5tr)) {
                        File dir = new File(Constants.EXTERNAL_DIR_PICTURES);
                        if (!dir.exists()) {
                            dir.mkdirs();
                        }
                        File destFile = new File(dir, md5tr + ".jpg");
                        FileUtils.copyFileUsingFileChannels(srcFile, destFile);
                        MediaUtil.saveImageToSystem(PictureViewerActivity.this, destFile);
                        toastMsg(getString(R.string.common_save_success));
                    }
                }
            } else if (mListImageUrl != null && mListImageUrl.size() > 0) {
                GlideUtils.loadIntoUseTarget(PictureViewerActivity.this, mListImageUrl.get(mCurrentPosition), new SimpleTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        String name = Constants.SHARE_FILE_NAME_PREFIX + mCurrentPosition;
                        String imagePath = BitmapUtil.saveBitmapExternalCache(PictureViewerActivity.this, resource, name);
                        if (!TextUtils.isEmpty(imagePath)) {
                            File srcFile = new File(imagePath);
                            String md5tr = FileDigestUtil.getFileMD5(srcFile);
                            File dir = new File(Constants.EXTERNAL_DIR_PICTURES);
                            if (!dir.exists()) {
                                dir.mkdirs();
                            }
                            File destFile = new File(dir, md5tr + ".jpg");
                            FileUtils.copyFileUsingFileChannels(srcFile, destFile);
                            MediaUtil.saveImageToSystem(PictureViewerActivity.this, destFile);
                            toastMsg(getString(R.string.common_save_success));
                        }
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void hideNavigationBar() {
        int uiFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
                | View.SYSTEM_UI_FLAG_FULLSCREEN; // hide status bar

        if (Build.VERSION.SDK_INT >= 19) {
            uiFlags |= View.SYSTEM_UI_FLAG_IMMERSIVE; //0x00001000; // SYSTEM_UI_FLAG_IMMERSIVE_STICKY: hide
        } else {
            uiFlags |= View.SYSTEM_UI_FLAG_LOW_PROFILE;
        }

        try {
            getWindow().getDecorView().setSystemUiVisibility(uiFlags);
        } catch (Exception e) {
            // TODO: handle exception
        }

    }

    @Override
    public void onImageClicked(View v) {
        if (mRequestCode != REQUEST_CODE_DEFAULT) {
            Intent intent = new Intent();
            intent.setData(Uri.parse(String.valueOf(mCurrentPosition)));
            setResult(RESULT_OK, intent);
        }
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public static void startPictureViewerActivity(Context context, ArrayList<String> listImagePath, int currentPosition) {
        if (context == null || listImagePath == null || listImagePath.size() == 0) {
            return;
        }

        Intent intent = new Intent(context, PictureViewerActivity.class);
        intent.putStringArrayListExtra(EXTRA_KEY_IMAGE_PATHS, listImagePath);
        intent.putExtra(EXTRA_KEY_IMAGE_POSITION, currentPosition);

        context.startActivity(intent);
        if (context instanceof Activity) {
            ((Activity) context).overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }
    }

    public static void startPictureViewerActivityForResult(Activity activity, ArrayList<String> listImagePath, int currentPosition, int requestCode) {
        if (activity == null || listImagePath == null || listImagePath.size() == 0) {
            return;
        }

        Intent intent = new Intent(activity, PictureViewerActivity.class);
        intent.putStringArrayListExtra(EXTRA_KEY_IMAGE_PATHS, listImagePath);
        intent.putExtra(EXTRA_KEY_IMAGE_POSITION, currentPosition);
        intent.putExtra(EXTRA_KEY_REQUEST_CODE, requestCode);

        activity.startActivityForResult(intent, requestCode);
        activity.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public static void startPictureViewerActivityUrl(Context context, ArrayList<String> listImageUrl, int currentPosition) {
        if (context == null || listImageUrl == null || listImageUrl.size() == 0) {
            return;
        }

        Intent intent = new Intent(context, PictureViewerActivity.class);

        intent.putStringArrayListExtra(EXTRA_KEY_IMAGE_URLS, listImageUrl);
        intent.putExtra(EXTRA_KEY_IMAGE_POSITION, currentPosition);

//        ActivityOptionsCompat optionsCompat = ActivityOptionsCompat.makeSceneTransitionAnimation(
//                (Activity) context, transitView, PictureViewerActivity.TRANSIT_PIC);
//        try {
//            ActivityCompat.startActivity(context, intent, optionsCompat.toBundle());
//        } catch (IllegalArgumentException e) {
//            e.printStackTrace();
//            context.startActivity(intent);
//        }

        context.startActivity(intent);
        if (context instanceof Activity) {
            ((Activity) context).overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }
    }

    public class PictureViewerPagerAdapter extends FragmentPagerAdapter {

        public PictureViewerPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragments != null ? mFragments.get(position) : null;
        }

        @Override
        public int getCount() {
            return mFragments != null ? mFragments.size() : 0;
        }
    }

}
