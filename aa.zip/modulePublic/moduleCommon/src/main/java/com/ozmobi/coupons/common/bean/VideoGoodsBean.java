package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/8/27.
 */

public class VideoGoodsBean {
    private int error;
    private String msg;
    private DataBean data;
    private int time;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public static class DataBean {

        private Object kind;
        private List<DouYinsBean> douYins;

        public Object getKind() {
            return kind;
        }

        public void setKind(Object kind) {
            this.kind = kind;
        }

        public List<DouYinsBean> getDouYins() {
            return douYins;
        }

        public void setDouYins(List<DouYinsBean> douYins) {
            this.douYins = douYins;
        }

        public static class DouYinsBean extends CommonProductsEntity {
            private String guide_article;
            private String videoid;
            private String dy_trill_id;
            private String dy_video_url;
            private String dy_video_like_count;
            private String dy_video_share_count;
            private String first_frame;
            private String itempic;
            private String itempic_copy;
            private String dy_video_title;
            private String itemdesc;

            public String getGuide_article() {
                return guide_article;
            }

            public void setGuide_article(String guide_article) {
                this.guide_article = guide_article;
            }

            public String getVideoid() {
                return videoid;
            }

            public void setVideoid(String videoid) {
                this.videoid = videoid;
            }

            public String getDy_trill_id() {
                return dy_trill_id;
            }

            public void setDy_trill_id(String dy_trill_id) {
                this.dy_trill_id = dy_trill_id;
            }

            public String getDy_video_url() {
                return dy_video_url;
            }

            public void setDy_video_url(String dy_video_url) {
                this.dy_video_url = dy_video_url;
            }

            public String getDy_video_like_count() {
                return dy_video_like_count;
            }

            public void setDy_video_like_count(String dy_video_like_count) {
                this.dy_video_like_count = dy_video_like_count;
            }

            public String getDy_video_share_count() {
                return dy_video_share_count;
            }

            public void setDy_video_share_count(String dy_video_share_count) {
                this.dy_video_share_count = dy_video_share_count;
            }

            public String getFirst_frame() {
                return first_frame;
            }

            public void setFirst_frame(String first_frame) {
                this.first_frame = first_frame;
            }

            public String getItempic() {
                return itempic;
            }

            public void setItempic(String itempic) {
                this.itempic = itempic;
            }

            public String getItempic_copy() {
                return itempic_copy;
            }

            public void setItempic_copy(String itempic_copy) {
                this.itempic_copy = itempic_copy;
            }

            public String getDy_video_title() {
                return dy_video_title;
            }

            public void setDy_video_title(String dy_video_title) {
                this.dy_video_title = dy_video_title;
            }

            public String getItemdesc() {
                return itemdesc;
            }

            public void setItemdesc(String itemdesc) {
                this.itemdesc = itemdesc;
            }
        }
    }
}
