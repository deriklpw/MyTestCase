package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.ozmobi.coupons.common.bean.BrandBean;
import com.ozmobi.coupons.common.bean.CateBannerBean;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.bean.NavCateDetailBean;
import com.ozmobi.coupons.common.bean.RecommendLimitHomeBean;
import com.ozmobi.coupons.common.bean.RecommendNavBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

public interface RecommendDataSource extends BaseDataSource {

    Disposable getRecommendNavData(@NonNull Consumer<? super RecommendNavBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getRecommendLimitHomeGoods(int pageSize, int page, @Nullable String start, @NonNull Consumer<? super RecommendLimitHomeBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getRecommendPromotionGoods(int pageSize, int page, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getRecommendHotHomeGoods(int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getRecommendNinePointHomeGoods(int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getRecommendChoiceHomeGoods(int pageSize, int page, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable requestRecommendBannerData(@NonNull Consumer<? super CateBannerBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable requestTodayOptimalGoods(@NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getBrandGoods(@NonNull Consumer<? super BrandBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getBrandDetailGoods(@NonNull String brandId, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getHomeCateDetail(@NonNull String id, String title, String cate, @NonNull Consumer<? super NavCateDetailBean> success, @NonNull Consumer<? super Throwable> error);

    Disposable getHomeCateDetailRecommend(@NonNull String id , String title, int pageSize, int page, @Nullable String sort, @NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error);
}
