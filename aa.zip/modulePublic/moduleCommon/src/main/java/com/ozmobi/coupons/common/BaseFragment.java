package com.ozmobi.coupons.common;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.base.utils.NetworkUtil;

public abstract class BaseFragment extends Fragment implements BaseView {

    private static final String TAG = "BaseFragment";

    private boolean isViewPrepared;

    private boolean hasFetchData;

    protected View mRootView;

    private Toast mToast;

    protected abstract
    @LayoutRes
    int getLayoutId();

    protected abstract void initViews();

    protected abstract void lazyFetchData();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mRootView = inflater.inflate(getLayoutId(), container, false);
        initViews();
        return mRootView;
    }

    private void lazyFetchDataIfPrepared() {
        if (getUserVisibleHint() && !hasFetchData && isViewPrepared) {
            hasFetchData = true;
            lazyFetchData();
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            lazyFetchDataIfPrepared();
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        isViewPrepared = true;
        lazyFetchDataIfPrepared();
    }

    protected <T extends View> T findView(@IdRes int id) {
        return (T) mRootView.findViewById(id);
    }

    @Override
    public void toastNetError() {
        toastLongBase(getString(R.string.common_network_error));
    }

    @Override
    public void toastGetDataFail() {
        toastShortBase(getString(R.string.common_get_data_error));
    }

    @Override
    public void toastServerBusiness() {
        toastLongBase(getString(R.string.common_server_business));
    }

    @Override
    public void toastMsg(String msg) {
        toastShortBase(msg);
    }

    @Override
    public boolean isLoading() {
        Activity activity = getActivity();
        return activity instanceof BaseActivity && ((BaseActivity) activity).isLoading();
    }

    @Override
    public void showLoading() {
        Activity activity = getActivity();
        if (activity instanceof BaseActivity) {
            ((BaseActivity) activity).showLoading();
        }
        LogUtil.d("base fragment", "showLoading: " + this.getClass().getSimpleName());
    }

    @Override
    public void hideLoading() {
        Activity activity = getActivity();
        if (activity instanceof BaseActivity) {
            ((BaseActivity) activity).hideLoading();
        }
        LogUtil.d("base fragment", "hideLoading: " + this.getClass().getSimpleName());
    }

    @Override
    public void showError() {
        if (NetworkUtil.isNetworkAvailable()) {
            toastGetDataFail();
        } else {
            toastNetError();
        }
    }

    private void toastShortBase(String msg) {
        if (getContext() == null || TextUtils.isEmpty(msg)) {
            return;
        }
        if (mToast != null) {
            mToast.cancel();
            mToast = null;
        }
        mToast = Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT);
        mToast.show();
    }

    private void toastLongBase(String msg) {
        if (getContext() == null || TextUtils.isEmpty(msg)) {
            return;
        }
        if (mToast != null) {
            mToast.cancel();
            mToast = null;
        }
        mToast = Toast.makeText(getContext(), msg, Toast.LENGTH_LONG);
        mToast.show();
    }

    protected void setBaseToolbarTitle(String title) {
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        if (activity instanceof BaseActivity) {
            ((BaseActivity) activity).setToolbarTitle(title);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mRootView = null;
        hasFetchData = false;
        isViewPrepared = false;
        if (mToast != null) {
            mToast.cancel();
            mToast = null;
        }
    }

}
