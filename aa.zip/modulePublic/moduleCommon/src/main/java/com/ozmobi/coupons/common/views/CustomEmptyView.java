package com.ozmobi.coupons.common.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.constraint.ConstraintLayout;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.ozmobi.coupons.common.R;

/**
 * Created by xhkj on 2019/7/11.
 */

public class CustomEmptyView extends ConstraintLayout {

    private static int[] ATTRS = new int[]{
            android.R.attr.src,
            android.R.attr.scaleType,
            android.R.attr.textSize,
            android.R.attr.textColor,
            android.R.attr.text
    };

    private static final ImageView.ScaleType[] sScaleTypeArray = {
            ImageView.ScaleType.MATRIX,
            ImageView.ScaleType.FIT_XY,
            ImageView.ScaleType.FIT_START,
            ImageView.ScaleType.FIT_CENTER,
            ImageView.ScaleType.FIT_END,
            ImageView.ScaleType.CENTER,
            ImageView.ScaleType.CENTER_CROP,
            ImageView.ScaleType.CENTER_INSIDE
    };

    private static final int INDEX_ATTR_SRC = 0;
    private static final int INDEX_ATTR_SCALE_TYPE = 1;
    private static final int INDEX_ATTR_TEXT_SIZE = 2;
    private static final int INDEX_ATTR_TEXT_COLOR = 3;
    private static final int INDEX_ATTR_TEXT = 4;

    private int mTextColor = Color.GRAY;
    private int mTextSize = sp2px(15);
    private String mText;
    private ImageView mIcon;
    private TextView mDesc;

    public CustomEmptyView(Context context) {
        this(context, null);
    }

    public CustomEmptyView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CustomEmptyView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        initViews(context, attrs);

    }

    private void initViews(Context context, AttributeSet attrs) {
        View view = inflate(getContext(), R.layout.common_layout_empty, this);
        mIcon = view.findViewById(R.id.iv_message_empty);
        mDesc = view.findViewById(R.id.tv_message_empty_desc);

        TypedArray ta = context.obtainStyledAttributes(attrs, ATTRS);

        Drawable drawable = ta.getDrawable(INDEX_ATTR_SRC);
        if (drawable != null) {
            mIcon.setImageDrawable(drawable);
        }
        final int index = ta.getInt(INDEX_ATTR_SCALE_TYPE, -1);

        if (index >= 0) {
            mIcon.setScaleType(sScaleTypeArray[index]);
        }

        mTextSize = ta.getDimensionPixelSize(INDEX_ATTR_TEXT_SIZE, mTextSize);
        mTextColor = ta.getColor(INDEX_ATTR_TEXT_COLOR, mTextColor);
        mText = ta.getString(INDEX_ATTR_TEXT);
        ta.recycle();
    }

    public void setSrc(int resId) {
        mIcon.setImageResource(resId);
    }

    public void setScaleType(ImageView.ScaleType scaleType) {
        if (scaleType != null) {
            mIcon.setScaleType(scaleType);
        }
    }

    public void setTextSize(float size) {
        mDesc.setTextSize(size);
    }

    public void setTextColor(int color) {
        mDesc.setTextColor(color);
    }

    public void setText(String text) {
        mDesc.setText(text);
    }

    public int sp2px(int spVal) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, spVal, getResources().getDisplayMetrics());
    }

    public int dp2px(int dpVal) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dpVal, getResources().getDisplayMetrics());

    }
}
