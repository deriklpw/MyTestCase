package com.ozmobi.coupons.common.ui.search.result;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.AbsMoreFragment;
import com.ozmobi.coupons.common.IMoreContract;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.adapter.GridGoodsAdapter;
import com.ozmobi.coupons.common.adapter.ListGoodsAdapter;
import com.ozmobi.coupons.common.adapter.LoadMoreWrapper;
import com.ozmobi.coupons.common.bean.CommonProductsEntity;
import com.ozmobi.coupons.common.ui.goodsdetails.GoodsDetailsActivity;
import com.ozmobi.coupons.common.ui.search.SearchActivity;
import com.ozmobi.coupons.common.utils.GoodsConvertUtil;
import com.ozmobi.coupons.common.utils.GridItemDivider;
import com.ozmobi.coupons.common.utils.LinearItemDivider;
import com.ozmobi.coupons.base.utils.OnClickUtils;
import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.common.utils.RecyclerViewHelper;
import com.ozmobi.coupons.common.views.CustomCheckImage;
import com.umeng.analytics.MobclickAgent;

import java.util.ArrayList;
import java.util.List;

/**
 * 品牌详情，url链接商品页，二级搜索，其他分类的热门品牌等相同UI的，均复用此页面
 * 搜索结果显示页
 * <p>
 * 一级目录，如女装，母婴，化妆等，皆为搜索的结果
 * 二级目录，如一级目录女装中的，大码女装，妈妈装等，亦皆为搜索结果
 */
public class SearchResultFragment extends AbsMoreFragment<CommonProductsEntity> implements SearchResultContract.View {

    private static final String TAG = "SearchResultFragment";

    private static final String SEARCH_NAME = "search_name";

    public static final String SORT_COMBINE = "";

    public static final String SORT_COUPON_ASC = "coupon_price_asc";

    public static final String SORT_COUPON_DESC = "coupon_price_des";

    public static final String SORT_REBATE_DESC = "income_des";

    private IMoreContract.AbsMorePresenter mPresenter;

    private SwipeRefreshLayout mRefreshView;

    private String[] mTabs;

    private String mSort = null;

    private List<CommonProductsEntity> mListGoods;

    private LoadMoreWrapper mAdapter;

    private String mParam = "";

    private static final int SPAN_COUNT = 2;

    private Context mContext;

    private RadioButton mRbtnSortCombine;
    private RadioButton mRbtnSortCouponAsc;
    private RadioButton mRbtnSortCouponDesc;
    private RadioButton mRbtnSortRebateDesc;
    private ViewGroup mSortViewRoot;
    private TabLayout.Tab mTab0;

    public SearchResultFragment() {
        // Required empty public constructor

    }

    @Override
    protected int getLayoutId() {
        return R.layout.common_fragment_search_result_detail;
    }

    public static SearchResultFragment newInstance(String searchName) {
        SearchResultFragment fragment = new SearchResultFragment();
        Bundle args = new Bundle();
        args.putString(SEARCH_NAME, searchName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void setPresenter(IMoreContract.AbsMorePresenter presenter) {
        mPresenter = presenter;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtil.d(TAG, "onCreate: ");

        mTabs = getResources().getStringArray(R.array.common_good_tab_browser);
        if (getArguments() != null) {
            mParam = getArguments().getString(SEARCH_NAME);
        }

        mListGoods = new ArrayList<>();
        setHasOptionsMenu(true);
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.d(TAG, "onResume: ");
        MobclickAgent.onPageStart(TAG + mParam);
    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.d(TAG, "onPause: ");
        MobclickAgent.onPageEnd(TAG + mParam);
    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtil.d(TAG, "onStop: ");
        mPresenter.cancel();
    }

    @Override
    protected void initViews() {
        mContext = getContext();

        mSortViewRoot = findView(R.id.fl_search_result_sort_root);

        mRefreshView = findView(R.id.swipe_refresh);
        mRefreshView.setOnRefreshListener(this);

        RecyclerView recyclerView = findView(R.id.recycler_view);

        FloatingActionButton fab = findView(R.id.fab_top_back);

        mRbtnSortCombine = findView(R.id.rb_search_result_combine);
        mRbtnSortCouponAsc = findView(R.id.rb_search_result_coupon_asc);
        mRbtnSortCouponDesc = findView(R.id.rb_search_result_coupon_desc);
        mRbtnSortRebateDesc = findView(R.id.rb_search_result_rebate_desc);

        GridGoodsAdapter gridGoodsAdapter = new GridGoodsAdapter(R.layout.common_adapter_item_common_goods_grid, mListGoods);

        ListGoodsAdapter listGoodsAdapter = new ListGoodsAdapter(R.layout.common_adapter_item_common_goods_list, mListGoods);
        listGoodsAdapter.setErrorResId(R.layout.common_layout_network_error, view -> {
            Button btnRefresh = view.findViewById(R.id.btn_network_error_refresh);
            btnRefresh.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    mPresenter.start();
                }
            });
        });
        listGoodsAdapter.setEmptyResId(R.layout.common_layout_search_result_empty);

        listGoodsAdapter.setOnItemClickListener((view, commonProductsEntity, position) -> {
            GoodsDetailsActivity.startForGoodDetail(mContext, GoodsConvertUtil.convertToGoodsBean(commonProductsEntity));
        });

        gridGoodsAdapter.setOnItemClickListener((view, commonProductsEntity, position) -> {
            GoodsDetailsActivity.startForGoodDetail(mContext, GoodsConvertUtil.convertToGoodsBean(commonProductsEntity));
        });

        gridGoodsAdapter.setErrorResId(R.layout.common_layout_network_error, view -> {
            Button btnRefresh = view.findViewById(R.id.btn_network_error_refresh);
            btnRefresh.setOnClickListener(new OnSingleClickListener() {
                @Override
                public void onSingleClick(View v) {
                    mPresenter.start();
                }
            });
        });
        gridGoodsAdapter.setEmptyResId(R.layout.common_layout_search_result_empty);

        setupTabLayout();

        CustomCheckImage icbDisplayWay = findView(R.id.cci_display_way);

        //默认列布局
        mAdapter = new LoadMoreWrapper(listGoodsAdapter);
        RecyclerViewHelper.setLayoutManager(recyclerView, new LinearLayoutManager(mContext));
        recyclerView.setAdapter(mAdapter);
        int dividerSize = getResources().getDimensionPixelSize(R.dimen.common_dimen_8d);
        LinearItemDivider linearItemDivider = new LinearItemDivider(dividerSize, Color.WHITE, true);
        linearItemDivider.setDividersWidth(dividerSize, dividerSize, dividerSize, dividerSize);
        recyclerView.addItemDecoration(linearItemDivider);

        //checked, Grid, unchecked, List
        GridItemDivider gridItemDivider = new GridItemDivider(getResources().getDimensionPixelSize(R.dimen.common_dimen_8d), getResources().getColor(R.color.common_color_layout_gray_bg));
        gridItemDivider.setDividersEnable(true, true, true, true);
        icbDisplayWay.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                mAdapter = new LoadMoreWrapper(gridGoodsAdapter);
                GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, SPAN_COUNT, OrientationHelper.VERTICAL, false);
                RecyclerViewHelper.setLayoutManager(recyclerView, gridLayoutManager);
                recyclerView.setAdapter(mAdapter);
                recyclerView.removeItemDecoration(linearItemDivider);
                recyclerView.addItemDecoration(gridItemDivider);
            } else {
                mAdapter = new LoadMoreWrapper(listGoodsAdapter);
                RecyclerViewHelper.setLayoutManager(recyclerView, new LinearLayoutManager(mContext));
                recyclerView.setAdapter(mAdapter);
                recyclerView.removeItemDecoration(gridItemDivider);
                recyclerView.addItemDecoration(linearItemDivider);
            }
            setMoreFragmentViewsAndData(mRefreshView, recyclerView, fab, mPresenter, mAdapter, mListGoods);
        });

        mRbtnSortCombine.setOnClickListener(v -> {
            hideSortViews();
            if (!SORT_COMBINE.equals(mSort)) {
                mSort = SORT_COMBINE;
                mPresenter.setSortAndReload(mSort);
            }
        });

        mRbtnSortCouponAsc.setOnClickListener(v -> {
            hideSortViews();
            if (!SORT_COUPON_ASC.equals(mSort)) {
                mSort = SORT_COUPON_ASC;
                mPresenter.setSortAndReload(mSort);
            }
        });

        mRbtnSortCouponDesc.setOnClickListener(v -> {
            hideSortViews();
            if (!SORT_COUPON_DESC.equals(mSort)) {
                mSort = SORT_COUPON_DESC;
                mPresenter.setSortAndReload(mSort);
            }
        });

        mRbtnSortRebateDesc.setOnClickListener(v -> {
            hideSortViews();
            if (!SORT_REBATE_DESC.equals(mSort)) {
                mSort = SORT_REBATE_DESC;
                mPresenter.setSortAndReload(mSort);
            }
        });

        mSortViewRoot.setOnClickListener(v -> hideSortViews());

        setMoreFragmentViewsAndData(mRefreshView, recyclerView, fab, mPresenter, mAdapter, mListGoods);
    }

    @Override
    protected void lazyFetchData() {
        mPresenter.start();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateView: ");
        return super.onCreateView(inflater, container, savedInstanceState);
    }


    private void setupTabLayout() {
        try {

            TabLayout tabLayout = findView(R.id.tab_show_by);

            for (int i = 0; i < mTabs.length; i++) {
                TabLayout.Tab tab = tabLayout.newTab();
                tab.setCustomView(R.layout.common_tab_item_show_by);

                if (i != 0 && i != mTabs.length - 1) {
                    RadioGroup radioGroup = tab.getCustomView().findViewById(R.id.rg_show_container_price);
                    radioGroup.setVisibility(View.GONE);
                }

                TextView tvTab = tab.getCustomView().findViewById(R.id.tv_show_by);
                tvTab.setText(mTabs[i]);
                tabLayout.addTab(tab);
            }

            //选中第一个
            mTab0 = tabLayout.getTabAt(0);
            if (mTab0 != null) {
                mTab0.select();
                if (mTab0.getCustomView() != null) {
                    TextView tvTab0 = mTab0.getCustomView().findViewById(R.id.tv_show_by);
                    RadioButton cbtnUpTab0 = mTab0.getCustomView().findViewById(R.id.cb_show_by_price_up);
                    RadioButton cbtnDownTab0 = mTab0.getCustomView().findViewById(R.id.cb_show_by_price_down);

                    tvTab0.setTextColor(getResources().getColor(R.color.common_color_red));
                    cbtnUpTab0.setVisibility(View.GONE);
                    cbtnDownTab0.setVisibility(View.VISIBLE);
                    cbtnDownTab0.setChecked(true);
                }
            }

            tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    if (tab.getCustomView() == null) {
                        return;
                    }
                    TextView tvTab = tab.getCustomView().findViewById(R.id.tv_show_by);

                    RadioButton cbtnUp = tab.getCustomView().findViewById(R.id.cb_show_by_price_up);
                    RadioButton cbtnDown = tab.getCustomView().findViewById(R.id.cb_show_by_price_down);

                    tvTab.setTextColor(getResources().getColor(R.color.common_color_red));

                    String tempSort = "";
                    if (tab.getPosition() == 0) {
                        tempSort = mSort;
                        cbtnUp.setVisibility(View.GONE);
                        cbtnDown.setVisibility(View.VISIBLE);
                        cbtnDown.setChecked(true);
                    } else if (tab.getPosition() == 1) {
                        tempSort = "total_sales_des";

                    } else if (tab.getPosition() == 2) {
                        tempSort = "price_asc";
                        cbtnUp.setChecked(true);
                    }
                    mPresenter.setSortAndReload(tempSort);
                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {
                    if (tab.getCustomView() == null) {
                        return;
                    }
                    //清除状态
                    TextView tvText = tab.getCustomView().findViewById(R.id.tv_show_by);
                    RadioGroup radioGroup = tab.getCustomView().findViewById(R.id.rg_show_container_price);
                    tvText.setTextColor(getResources().getColor(R.color.common_color_gray_deep));
                    radioGroup.clearCheck();
                }

                @Override
                public void onTabReselected(TabLayout.Tab tab) {
                    if (tab.getCustomView() == null) {
                        return;
                    }

                    RadioButton cbtnUp = tab.getCustomView().findViewById(R.id.cb_show_by_price_up);
                    RadioButton cbtnDown = tab.getCustomView().findViewById(R.id.cb_show_by_price_down);

                    if (tab.getPosition() == 0) {
                        if (mSortViewRoot.getVisibility() != View.VISIBLE) {
                            showSortViews(mSort);
                            cbtnUp.setVisibility(View.VISIBLE);
                            cbtnDown.setVisibility(View.GONE);
                            cbtnUp.setChecked(true);
                        } else {
                            cbtnUp.setVisibility(View.GONE);
                            cbtnDown.setVisibility(View.VISIBLE);
                            cbtnDown.setChecked(true);
                        }
                    }

                    if (tab.getPosition() == 2) {
                        String tempSort;
                        if (cbtnUp.isChecked()) {
                            LogUtil.d(TAG, "rbtnUp checked");
                            cbtnDown.setChecked(true);
                            tempSort = "price_des";

                        } else {
                            LogUtil.d(TAG, "rbtnUp unchecked");
                            cbtnUp.setChecked(true);
                            tempSort = "price_asc";
                        }
                        mPresenter.setSortAndReload(tempSort);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showSortViews(String sort) {
        sort = sort == null ? "" : sort;
        mSortViewRoot.setVisibility(View.VISIBLE);
        Animation anim = AnimationUtils.loadAnimation(mContext, R.anim.common_slide_up_in);
        anim.setFillAfter(true);
        mSortViewRoot.findViewById(R.id.rg_search_result_sort).startAnimation(anim);

        switch (sort) {
            case SORT_COUPON_ASC:
                mRbtnSortCouponAsc.setChecked(true);
                break;
            case SORT_COUPON_DESC:
                mRbtnSortCouponDesc.setChecked(true);
                break;
            case SORT_REBATE_DESC:
                mRbtnSortRebateDesc.setChecked(true);
                break;
            default:
                //综合
                mRbtnSortCombine.setChecked(true);
                break;
        }
    }

    private void hideSortViews() {
        if (mSortViewRoot.getVisibility() == View.VISIBLE) {
            mSortViewRoot.setVisibility(View.GONE);
        }

        if (mTab0 != null && mTab0.getCustomView() != null) {
            RadioButton cbtnUpTab0 = mTab0.getCustomView().findViewById(R.id.cb_show_by_price_up);
            RadioButton cbtnDownTab0 = mTab0.getCustomView().findViewById(R.id.cb_show_by_price_down);
            cbtnUpTab0.setVisibility(View.GONE);
            cbtnDownTab0.setVisibility(View.VISIBLE);
            cbtnDownTab0.setChecked(true);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        LogUtil.d(TAG, "onAttach: ");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        LogUtil.d(TAG, "onDetach: ");
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.common_menu_detail, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (OnClickUtils.isFastClick()) {
            return true;
        }
        if (item.getItemId() == R.id.menu_search) {
            LogUtil.d(TAG, "search clicked");
            startActivity(new Intent(mContext, SearchActivity.class));
        }
        return true;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mPresenter.detach();
        mContext = null;
        LogUtil.d(TAG, "onDestroyView: ");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtil.d(TAG, "onDestroy: ");
        mAdapter = null;

        if (mPresenter != null) {
            mPresenter.destroy();
            mPresenter = null;
        }

        if (mListGoods != null) {
            mListGoods.clear();
            mListGoods = null;
        }

        if (mRefreshView != null) {
            mRefreshView.setRefreshing(false);
            mRefreshView.clearAnimation();
            mRefreshView = null;
        }
    }
}
