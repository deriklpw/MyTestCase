package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/5/10.
 */

public class FavoriteListBean {
    private String msg;
    private DataEntity data;
    private int time;
    private int error;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(DataEntity data) {
        this.data = data;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public DataEntity getData() {
        return data;
    }

    public int getTime() {
        return time;
    }

    public int getError() {
        return error;
    }

    public class DataEntity {
        private List<String> favorite_list;

        public void setFavorite_list(List<String> favorite_list) {
            this.favorite_list = favorite_list;
        }

        public List<String> getFavorite_list() {
            return favorite_list;
        }
    }
}
