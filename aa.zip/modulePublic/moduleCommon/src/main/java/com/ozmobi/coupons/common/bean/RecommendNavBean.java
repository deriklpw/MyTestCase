package com.ozmobi.coupons.common.bean;

import java.util.List;

public class RecommendNavBean {
    private int error;
    private String msg;
    private DataBean data;
    private int time;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public static class DataBean {
        private String promotion;
        private List<BannerEntity> banner;
        private List<NavBean> nav;
        private List<HomeCateBean> homeCate;
        private List<String> hot_keywords;

        public String getPromotion() {
            return promotion;
        }

        public void setPromotion(String promotion) {
            this.promotion = promotion;
        }

        public List<BannerEntity> getBanner() {
            return banner;
        }

        public void setBanner(List<BannerEntity> banner) {
            this.banner = banner;
        }

        public List<NavBean> getNav() {
            return nav;
        }

        public void setNav(List<NavBean> nav) {
            this.nav = nav;
        }

        public List<HomeCateBean> getHomeCate() {
            return homeCate;
        }

        public void setHomeCate(List<HomeCateBean> homeCate) {
            this.homeCate = homeCate;
        }

        public List<String> getHot_keywords() {
            return hot_keywords;
        }

        public void setHot_keywords(List<String> hot_keywords) {
            this.hot_keywords = hot_keywords;
        }

        public static class NavBean {
            private String title;
            private String sub_title;
            private String type;
            private String image;
            private CommonProductsEntity product;
            private String url;
            private int tb;

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getSub_title() {
                return sub_title;
            }

            public void setSub_title(String sub_title) {
                this.sub_title = sub_title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getImage() {
                return image;
            }

            public void setImage(String image) {
                this.image = image;
            }

            public CommonProductsEntity getProduct() {
                return product;
            }

            public void setProduct(CommonProductsEntity product) {
                this.product = product;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public int getTb() {
                return tb;
            }

            public void setTb(int tb) {
                this.tb = tb;
            }

            public static class ProductBean {
            }
        }

        public static class HomeCateBean extends CommonPromoteBean {
            private String sub_title;
            private String keywords;

            public String getSub_title() {
                return sub_title;
            }

            public void setSub_title(String sub_title) {
                this.sub_title = sub_title;
            }

            public String getKeywords() {
                return keywords;
            }

            public void setKeywords(String keywords) {
                this.keywords = keywords;
            }
        }

        public class BannerEntity {
            private String image;
            private String click;

            public void setImage(String image) {
                this.image = image;
            }

            public void setClick(String click) {
                this.click = click;
            }

            public String getImage() {
                return image;
            }

            public String getClick() {
                return click;
            }
        }
    }
}

