package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.manager.UserInfoManager;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

/**
 * Created by xhkj on 2019/9/23.
 */

public interface BaseDataSource {
    String TAG = "BaseDataSource";

    MediaType MEDIA_TYPE_JSON = MediaType.parse("application/json;charset=utf-8");

    /**
     * 获取分享赚的淘宝授权接口
     * @param success
     * @param error
     * @return
     */
    default Disposable getTaobaoAuthUrl(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "getTaobaoAuthUrl post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().getTaobaoAuthUrl(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    /**
     * 绑定上一级的邀请码
     * @param parentInvite 邀请码或者手机号
     * @return
     */
    default Disposable bindParentInviteCode(@NonNull String parentInvite, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("invite", parentInvite);

            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "bindInviteCode post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getAccountController().bindParentInviteCode(requestBody)
                .subscribeOn(Schedulers.io())
                .doOnNext(jsonObject -> {
                    if (jsonObject.getIntValue("error") == 0) {
                        JSONObject dataObj = jsonObject.getJSONObject("data");
                        JSONObject userInfo = dataObj.getJSONObject("userinfo");
                        UserInfoManager.getInstance().saveUserInfo(userInfo.toString());
                    }
                })
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    /**
     * 通过商品ID获取商品信息
     * @param numIId
     * @param success
     * @param error
     * @return
     */
    default Disposable getGoodsWithId(@NonNull String numIId, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());
            JSONObject params = new JSONObject();
            params.put("num_iid", numIId);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getGoodsDetailWithId post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController()
                .getGoodsWithId(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

}
