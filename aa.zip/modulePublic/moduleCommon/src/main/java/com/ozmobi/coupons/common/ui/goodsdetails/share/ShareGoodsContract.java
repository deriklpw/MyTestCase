package com.ozmobi.coupons.common.ui.goodsdetails.share;

import com.ozmobi.coupons.common.AbsBasePresenter;
import com.ozmobi.coupons.common.BaseView;
import com.ozmobi.coupons.common.bean.ShareTextBean;
import com.ozmobi.coupons.common.data.source.GoodsDataSource;

/**
 * Created by xhkj on 2019/7/4.
 */

public interface ShareGoodsContract {
    interface View extends BaseView {
        void showShareText(ShareTextBean shareTextBean);
    }

    abstract class Presenter extends AbsBasePresenter<ShareGoodsContract.View, GoodsDataSource> {
        public Presenter(GoodsDataSource goodsDataSource) {
            super(goodsDataSource);
        }

        abstract void getShareText();
    }
}
