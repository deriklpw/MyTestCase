package com.ozmobi.coupons.common.ui.search.otherhotdetail;

import com.ozmobi.coupons.base.Constants;
import com.ozmobi.coupons.common.IMoreContract;
import com.ozmobi.coupons.common.data.source.OtherCategoryDataSource;
import com.ozmobi.coupons.common.data.source.remote.OtherCategoryRepository;
import com.ozmobi.coupons.common.ui.search.result.SearchResultContract;

public class OtherHotDetailPresenter extends IMoreContract.AbsMorePresenter<SearchResultContract.View, OtherCategoryDataSource> {

    private String mCategoryName;

    private String mSort;

    public OtherHotDetailPresenter(SearchResultContract.View view, String categoryName) {
        super(new OtherCategoryRepository());
        mCategoryName = categoryName;
        this.attach(view);
        view.setPresenter(this);
    }

    public void setSortAndReload(String sort) {
        mSort = sort;
        start();
    }

    @Override
    public void start() {
        if (getBaseView() != null) {
            getBaseView().showLoading();
        }
        loadData(1);
    }

    @Override
    protected void loadData(int page) {
        if (getBaseRepository() == null) {
            if (getBaseView() != null && getBaseView().isLoading()) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
            }
            return;
        }
        addOperatorDisposable(getBaseRepository().getOtherCategoryHotGoods(mCategoryName, Constants.PAGE_SIZE_LOAD_DEFAULT, page, mSort, commonGoodsBean -> {
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
                if (commonGoodsBean != null && commonGoodsBean.getData() != null) {
                    getBaseView().showData(commonGoodsBean.getData().getProducts());
                }
            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
                getBaseView().showGetDataError();
            }
        }));
    }

    @Override
    protected void loadMoreData(int page) {
        if (getBaseRepository() == null) {
            return;
        }
        addOperatorDisposable(getBaseRepository().getOtherCategoryHotGoods(mCategoryName, Constants.PAGE_SIZE_LOAD_MORE, page, mSort, commonGoodsBean -> {//回调热门商品
            if (getBaseView() != null) {
                if (commonGoodsBean != null && commonGoodsBean.getData() != null) {
                    getBaseView().showMoreData(commonGoodsBean.getData().getProducts());
                }
            }

        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }));
    }
}
