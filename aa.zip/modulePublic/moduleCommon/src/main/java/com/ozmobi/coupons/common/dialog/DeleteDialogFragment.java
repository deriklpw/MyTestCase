package com.ozmobi.coupons.common.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;

import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.base.utils.OnClickUtils;
import com.ozmobi.coupons.common.R;
import com.umeng.analytics.MobclickAgent;

/**
 * Created by xhkj on 2019/3/19.
 */

public class DeleteDialogFragment extends BaseDialogFragment implements View.OnClickListener {

    private static final String TAG = "DeleteDialogFragment";

    public static final String CONFIRM = "confirm";

    public static final String CANCEL = "cancel";

    public DeleteDialogFragment() {
        // Required empty public constructor
    }

    public static DeleteDialogFragment newInstance() {
        return new DeleteDialogFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtil.d(TAG, "onCreate: ");
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.d(TAG, "onResume: ");
        MobclickAgent.onPageStart(TAG);
    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.d(TAG, "onPause: ");
        MobclickAgent.onPageEnd(TAG);
    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtil.d(TAG, "onStop: ");
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateDialog: ");
        AlertDialog dialog = new AlertDialog.Builder(mContext, R.style.CommonMyTransparentDownInOut).create();
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.CENTER);
        window.setContentView(R.layout.common_dialog_fragment_delete);

        TextView tvMsg = window.findViewById(R.id.tv_dialog_msg);

        TextView tvCancel = window.findViewById(R.id.tv_dialog_cancel);
        TextView tvConfirm = window.findViewById(R.id.tv_dialog_confirm);

        tvCancel.setOnClickListener(this);
        tvConfirm.setOnClickListener(this);

        return dialog;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogUtil.d(TAG, "onCreateView: ");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        LogUtil.d(TAG, "onAttach: ");

    }

    @Override
    public void onClick(View v) {

        if (OnClickUtils.isFastClick()) {
            return;
        }
        Intent data = new Intent();
        int id = v.getId();

        if (id == R.id.tv_dialog_confirm) {
            if (getTargetFragment() != null) {
                data.setData(Uri.parse(CONFIRM));
                getTargetFragment().onActivityResult(getTargetRequestCode(), Activity.RESULT_OK, data);
            }
            getDialog().dismiss();
        } else if (id == R.id.tv_dialog_cancel) {
            if (getTargetFragment() != null) {
                data.setData(Uri.parse(CANCEL));
                getTargetFragment().onActivityResult(getTargetRequestCode(), Activity.RESULT_OK, data);
            }
            getDialog().cancel();
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        LogUtil.d(TAG, "onDetach: ");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtil.d(TAG, "onDestroy: ");
    }
}
