package com.ozmobi.coupons.common.data.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 此目录中的Bean均不避开混淆，敏感信息，手动解析使用
 */
public class InviteFansBean implements Parcelable {
    private String shareUrl;
    private String imageUrl;
    private String invite;
    private String kouling;

    public InviteFansBean() {

    }

    protected InviteFansBean(Parcel in) {
        shareUrl = in.readString();
        imageUrl = in.readString();
        invite = in.readString();
        kouling = in.readString();
    }

    public static final Creator<InviteFansBean> CREATOR = new Creator<InviteFansBean>() {
        @Override
        public InviteFansBean createFromParcel(Parcel in) {
            return new InviteFansBean(in);
        }

        @Override
        public InviteFansBean[] newArray(int size) {
            return new InviteFansBean[size];
        }
    };

    public String getShareUrl() {
        return shareUrl;
    }

    public void setShareUrl(String shareUrl) {
        this.shareUrl = shareUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getInvite() {
        return invite;
    }

    public void setInvite(String invite) {
        this.invite = invite;
    }

    public String getKouling() {
        return kouling;
    }

    public void setKouling(String kouling) {
        this.kouling = kouling;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(shareUrl);
        dest.writeString(imageUrl);
        dest.writeString(invite);
        dest.writeString(kouling);
    }
}
