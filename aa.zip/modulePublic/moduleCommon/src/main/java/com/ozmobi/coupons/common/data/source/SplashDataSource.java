package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;

import com.ozmobi.coupons.common.bean.FavoriteListBean;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

/**
 * Created by xhkj on 2019/5/10.
 */

public interface SplashDataSource extends BaseDataSource {
    Disposable requestFavoriteList(@NonNull Consumer<? super FavoriteListBean> success, @NonNull Consumer<? super Throwable> error);
}
