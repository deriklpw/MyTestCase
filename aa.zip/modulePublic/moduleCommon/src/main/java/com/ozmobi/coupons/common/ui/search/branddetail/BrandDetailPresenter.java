package com.ozmobi.coupons.common.ui.search.branddetail;

import com.alibaba.fastjson.JSON;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.IMoreContract;
import com.ozmobi.coupons.common.data.source.RecommendDataSource;
import com.ozmobi.coupons.common.data.source.remote.RecommendRepository;
import com.ozmobi.coupons.common.ui.search.result.SearchResultContract;
import com.ozmobi.coupons.base.Constants;

public class BrandDetailPresenter extends IMoreContract.AbsMorePresenter<SearchResultContract.View, RecommendDataSource> {
    private static final String TAG = "BrandDetailPresenter";

    private String mBrandId;

    private String mSort;

    public BrandDetailPresenter(SearchResultContract.View view, String brandId) {
        super(new RecommendRepository());
        mBrandId = brandId;
        this.attach(view);
        view.setPresenter(this);
    }

    public void setSortAndReload(String sort) {
        mSort = sort;
        start();
    }

    @Override
    public void start() {
        if (getBaseView() != null) {
            getBaseView().showLoading();
        }
        loadData(1);
    }

    @Override
    protected void loadData(int page) {
        if (getBaseRepository() == null) {
            if (getBaseView() != null && getBaseView().isLoading()) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
            }
            return;
        }
        addOperatorDisposable(getBaseRepository().getBrandDetailGoods(mBrandId, Constants.PAGE_SIZE_LOAD_DEFAULT, page, mSort, commonGoodsBean -> {
            //回调热门商品
            LogUtil.d(TAG, "reloadBrandDetailGoods: " + JSON.toJSONString(commonGoodsBean));
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
                if (commonGoodsBean != null && commonGoodsBean.getData() != null) {
                    getBaseView().showData(commonGoodsBean.getData().getProducts());
                }
            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
                getBaseView().showGetDataError();
            }
        }));
    }

    @Override
    protected void loadMoreData(int page) {
        if (getBaseRepository() == null) {
            return;
        }
        addOperatorDisposable(getBaseRepository().getBrandDetailGoods(mBrandId, Constants.PAGE_SIZE_LOAD_MORE, page, mSort, commonGoodsBean -> {
            LogUtil.d(TAG, "moreBrandDetailGoods: " + JSON.toJSONString(commonGoodsBean));
            if (getBaseView() != null) {
                if (commonGoodsBean != null && commonGoodsBean.getData() != null) {
                    getBaseView().showMoreData(commonGoodsBean.getData().getProducts());
                }
            }

        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }));
    }

}
