package com.ozmobi.coupons.common.utils;

import android.support.v4.content.FileProvider;

public class CommonFileProviders extends FileProvider {
}
