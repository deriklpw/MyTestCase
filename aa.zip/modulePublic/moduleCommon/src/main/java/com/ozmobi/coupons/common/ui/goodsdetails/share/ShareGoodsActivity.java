package com.ozmobi.coupons.common.ui.goodsdetails.share;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;

import com.ozmobi.coupons.base.listener.OnSingleClickListener;
import com.ozmobi.coupons.base.Constants;
import com.ozmobi.coupons.base.utils.AppUtils;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.base.utils.BitmapUtil;
import com.ozmobi.coupons.base.utils.NumberUtils;
import com.ozmobi.coupons.base.utils.PXTool;
import com.ozmobi.coupons.base.utils.SortUtil;

import com.ozmobi.coupons.common.BaseActivity;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.common.adapter.CustomBaseAdapter;
import com.ozmobi.coupons.common.bean.GoodsBean;
import com.ozmobi.coupons.common.bean.ShareTextBean;
import com.ozmobi.coupons.common.ui.imageviewer.PictureViewerActivity;
import com.ozmobi.coupons.common.utils.ClipBoardUtil;
import com.ozmobi.coupons.common.utils.GlideUtils;
import com.ozmobi.coupons.common.views.CustomShareImage;
import com.ozmobi.coupons.common.manager.UMShareManager;
import com.uuzuche.lib_zxing.activity.CodeUtils;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.PermissionListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class ShareGoodsActivity extends BaseActivity implements ShareGoodsContract.View {

    private static final String TAG = "ShareGoodsActivity";

    private static final String EXTRA_KEY_GOODS = "extra_key_goods";

    private static final int REQUEST_CODE_PERMISSION_STORAGE = 100;

    private GoodsBean mGoodsBean;

    private String mOriginShareText;

    private String mOriginTkl;

    private String mNoInvite;

    private String mNoInviteNoRegister;

    private String mNoRegister;

    private List<String> mShareImages;

    private TextView mTvShareText;

    private CheckBox mCbxInviteCode;

    private CheckBox mCbxRegisterAddress;

    private ShareGoodsContract.Presenter mPresenter;

    private ImageView mIvGoodsQrInfo;

    private Hashtable<String, String> mHashImagePath;

    private UMShareManager mUmShareManager;

    private CustomShareImage mCustomShareImage;

    private TextView mTvForecastEarn;

    private TextView mTvGoodsShareTitle;

    private RecyclerView mRecyclerView;

    private CompositeDisposable mCompositeDisposable = new CompositeDisposable();

    @Override
    protected int getLayoutId() {
        return R.layout.common_activity_share_goods;
    }

    @Override
    protected void initViews() {
        setToolbarTitle(getString(R.string.common_create_share));
        mGoodsBean = (GoodsBean) getIntent().getSerializableExtra(EXTRA_KEY_GOODS);

        mPresenter = new ShareGoodsPresenter(String.valueOf(mGoodsBean.getGoodsId()));
        mPresenter.attach(this);

        initShareLayout();

        checkPermission(REQUEST_CODE_PERMISSION_STORAGE);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        mPresenter.cancel();
    }

    private void initShareLayout() {

        mTvForecastEarn = findViewById(R.id.tv_share_goods_forecast_earn);
        mTvGoodsShareTitle = findViewById(R.id.tv_share_goods_text_area_goods_title);
        mTvShareText = findViewById(R.id.tv_share_goods_text_area_content);
        mCbxInviteCode = findViewById(R.id.cbx_goods_share_invite_code);
        mCbxRegisterAddress = findViewById(R.id.cbx_goods_share_register_address);
        TextView tvCopyTkl = findViewById(R.id.tv_goods_share_copy_tkl);
        mIvGoodsQrInfo = findViewById(R.id.iv_share_goods_share_image_qr);
        CheckBox cbxGoodsQrInfo = findViewById(R.id.cbx_goods_share_image_qr);
        mRecyclerView = findViewById(R.id.recycler_view_share_goods_images);
        TextView tvShareTextAction = findViewById(R.id.tv_share_goods_copy_share_text);
        TextView tvShareImagesAction = findViewById(R.id.tv_share_goods_share_images);

        TextView tvAppShareTag = findViewById(R.id.tv_share_goods_image_area_bottom_label);
        String appShareTag = String.format(getString(R.string.common_share_to_earn_money_format), AppUtils.getApplicationName(ShareGoodsActivity.this));
        tvAppShareTag.setText(appShareTag);

        //隐藏状态，用于分享布局生成图片
        mCustomShareImage = findViewById(R.id.csi_share_goods_image);

        //邀请码控制
        mCbxInviteCode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                mTvShareText.setText(mCbxRegisterAddress.isChecked() ? mOriginShareText : mNoRegister);
            } else {
                mTvShareText.setText(mCbxRegisterAddress.isChecked() ? mNoInvite : mNoInviteNoRegister);
            }
        });

        //注册地址控制
        mCbxRegisterAddress.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                mTvShareText.setText(mCbxInviteCode.isChecked() ? mOriginShareText : mNoInvite);
            } else {
                mTvShareText.setText(mCbxInviteCode.isChecked() ? mNoRegister : mNoInviteNoRegister);
            }
        });

        cbxGoodsQrInfo.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (mGoodsBean == null || mHashImagePath == null || mHashImagePath.size() == 0 || mShareImages == null) {
                return;
            }
            String imageUrl = mGoodsBean.getIconUrl();
            if (!TextUtils.isEmpty(imageUrl) && mHashImagePath.containsKey(imageUrl)) {
                if (isChecked) {
                    if (!mShareImages.contains(mHashImagePath.get(imageUrl))) {
                        mShareImages.add(mHashImagePath.get(imageUrl));
                    }
                } else {
                    mShareImages.remove(mHashImagePath.get(imageUrl));
                }
            }
        });

        //复制淘口令
        tvCopyTkl.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                if (!TextUtils.isEmpty(mOriginTkl)) {
                    if (ClipBoardUtil.copyTextWithAppLabel(ShareGoodsActivity.this, mOriginTkl)) {
                        toastMsg(getString(R.string.common_copy_success));
                    } else {
                        toastMsg(getString(R.string.common_copy_failed));
                    }
                }
            }
        });

        //文案分享
        tvShareTextAction.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                if (TextUtils.isEmpty(mTvGoodsShareTitle.getText()) || TextUtils.isEmpty(mTvShareText.getText())) {
                    return;
                }
                String resultShareText = mTvGoodsShareTitle.getText().toString() + "\n" + mTvShareText.getText().toString();

                if (ClipBoardUtil.copyTextWithAppLabel(ShareGoodsActivity.this, resultShareText)) {
                    toastMsg(getString(R.string.common_copy_success));
                } else {
                    toastMsg(getString(R.string.common_copy_failed));
                }
            }
        });

        //图片分享
        tvShareImagesAction.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                showShareDialog(mShareImages);
            }
        });

        //长按标题分享
        mTvGoodsShareTitle.setOnLongClickListener(v -> {
            if (mGoodsBean != null && !TextUtils.isEmpty(mGoodsBean.getTitle())) {
                if (ClipBoardUtil.copyTextWithAppLabel(ShareGoodsActivity.this, mGoodsBean.getTitle())) {
                    toastMsg(getString(R.string.common_copy_success));
                } else {
                    toastMsg(getString(R.string.common_copy_failed));
                }
            }
            return false;
        });

        mIvGoodsQrInfo.setOnClickListener(new OnSingleClickListener() {
            @Override
            public void onSingleClick(View v) {
                if (mHashImagePath != null && mHashImagePath.size() > 0 && mRecyclerView.getChildCount() + 1 == mHashImagePath.size()) {
                    ArrayList<String> list = SortUtil.sortImagePath(new ArrayList<>(mHashImagePath.values()));
                    PictureViewerActivity.startPictureViewerActivity(ShareGoodsActivity.this, list, 0);
                }
            }
        });
    }

    public void initDatas() {
        if (mGoodsBean != null && TextUtils.isEmpty(mOriginShareText)) {
            if (mHashImagePath == null) {
                mHashImagePath = new Hashtable<>();
            } else {
                mHashImagePath.clear();
            }

            if (mShareImages == null) {
                mShareImages = new ArrayList<>();
            } else {
                mShareImages.clear();
            }

            initLayoutData();
            initCustomImageData();
            //获取分享文案
            mPresenter.start();
        }
    }

    public void initLayoutData() {
        try {
            mTvForecastEarn.setText(String.format(Locale.getDefault(), getString(R.string.common_reward_estimated_earnings_format), mGoodsBean.getCommissionFee()));
            mTvGoodsShareTitle.setText(mGoodsBean.getTitle());

            if (mGoodsBean.getSmallImages() != null && mGoodsBean.getSmallImages().size() > 0) {
                mRecyclerView.setLayoutManager(new GridLayoutManager(this, 2, OrientationHelper.VERTICAL, false));

                //最多显示4个
                GoodsImageAdapter adapter = new GoodsImageAdapter(R.layout.common_adapter_item_share_goods_image_item,
                        mGoodsBean.getSmallImages().size() > 4 ? mGoodsBean.getSmallImages().subList(0, 4) : mGoodsBean.getSmallImages());

                adapter.setOnItemClickListener((view, s, position) -> {
                    //均加载完，预览
                    if (mRecyclerView.getChildCount() + 1 == mHashImagePath.size()) {
                        ArrayList<String> list = SortUtil.sortImagePath(new ArrayList<>(mHashImagePath.values()));
                        //0是带二维码的图片，后面需要+1
                        PictureViewerActivity.startPictureViewerActivity(ShareGoodsActivity.this, list, position + 1);
                    }
                });

                mRecyclerView.setAdapter(adapter);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void initCustomImageData() {
        try {
            if (mGoodsBean == null) {
                return;
            }

            //处理没有券时，隐藏
            if (!TextUtils.isEmpty(mGoodsBean.getCouponValue())) {
                float couponValue = Float.valueOf(mGoodsBean.getCouponValue());
                if (couponValue - 0.001 > 0) {
                    mCustomShareImage.setCouponsVisibility(View.VISIBLE);
                    //设置券额
                    mCustomShareImage.setCouponValue(mGoodsBean.getCouponValue());
                    //有券时，设置原价
                    double originPrice = Double.valueOf(mGoodsBean.getOriginPrice());
                    mCustomShareImage.setOriginPrice(String.format(Locale.getDefault(), getString(R.string.common_origin_price_format), NumberUtils.format(originPrice)));
                } else {
                    mCustomShareImage.setCouponsVisibility(View.GONE);
                }
            } else {
                mCustomShareImage.setCouponsVisibility(View.GONE);
            }

            mCustomShareImage.setShareGoodsTitle(mGoodsBean.getPlatType(), mGoodsBean.getTitle());

            double currentPrice = Double.valueOf(mGoodsBean.getCurrentPrice());
            mCustomShareImage.setCurrentPrice(NumberUtils.format(currentPrice));

            Bitmap codeBitmap = CodeUtils.createImage(mGoodsBean.getShare(), PXTool.dip2px(200), PXTool.dip2px(200), BitmapFactory.decodeResource(getResources(), R.drawable.common_ic_launcher));
            mCustomShareImage.setQrCodeImageBitmap(codeBitmap);

            mCustomShareImage.getGoodsImageView().post(new Runnable() {
                @Override
                public void run() {
                    if (ShareGoodsActivity.this.isDestroyed() || ShareGoodsActivity.this.isFinishing()) {
                        return;
                    }
                    GlideUtils.loadIntoUseTarget(ShareGoodsActivity.this, mGoodsBean.getIconUrl(),
                            new SimpleTarget<Bitmap>(mCustomShareImage.getGoodsImageView().getWidth(), mCustomShareImage.getGoodsImageView().getHeight()) {
                                @Override
                                public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                    try {
                                        mCustomShareImage.setGoodsImageBitmap(resource);

                                        //获取布局生成bitmap
                                        Bitmap layoutBitmap = BitmapUtil.getBitmap(mCustomShareImage);
                                        if (layoutBitmap != null) {
                                            mIvGoodsQrInfo.setImageBitmap(layoutBitmap);

                                            Disposable disposable = Observable.create(new ObservableOnSubscribe<String>() {
                                                @Override
                                                public void subscribe(ObservableEmitter<String> emitter) throws Exception {

                                                    String name = Constants.SHARE_FILE_NAME_PREFIX + "0";
                                                    String imagePath = BitmapUtil.saveBitmapExternalCache(ShareGoodsActivity.this, layoutBitmap, name);
                                                    LogUtil.d(TAG, "onResourceReady: imagepath=" + imagePath);
                                                    emitter.onNext(imagePath);
                                                }
                                            }).subscribeOn(Schedulers.newThread())
                                                    .observeOn(AndroidSchedulers.mainThread())
                                                    .subscribe(new Consumer<String>() {
                                                        @Override
                                                        public void accept(String s) throws Exception {

                                                            if (mHashImagePath != null) {
                                                                mHashImagePath.put(mGoodsBean.getIconUrl(), s);

                                                                //默认选中，添加到分享数组
                                                                mShareImages.add(s);
                                                            }
                                                        }
                                                    });

                                            mCompositeDisposable.add(disposable);
                                        }
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void startForShare(Context context, GoodsBean goodsBean) {
        if (context != null && goodsBean != null) {
            Intent intent = new Intent(context, ShareGoodsActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable(EXTRA_KEY_GOODS, goodsBean);
            intent.putExtras(bundle);
            context.startActivity(intent);
        }
    }

    @Override
    public void showShareText(ShareTextBean shareTextBean) {
        try {
            String[] shareLabels = shareTextBean.getData().getShare_label().split(",");
            mOriginShareText = shareTextBean.getData().getShare_text();
            mOriginTkl = shareTextBean.getData().getTkl_text();

            if (!TextUtils.isEmpty(mOriginShareText)) {
                String[] shareTexts = mOriginShareText.split("\n");

                List<String> listShareText = new ArrayList<>();
                listShareText.addAll(Arrays.asList(shareTexts));

                listShareText.remove(3);
                mNoInvite = convertShareText(listShareText);

                listShareText.remove(3);
                listShareText.remove(3);
                mNoInviteNoRegister = convertShareText(listShareText);

                listShareText.clear();
                listShareText.addAll(Arrays.asList(shareTexts));
                listShareText.remove(4);
                mNoRegister = convertShareText(listShareText);

                if (mCbxInviteCode.isChecked() && mCbxRegisterAddress.isChecked()) {
                    mTvShareText.setText(mOriginShareText);
                } else if (mCbxInviteCode.isChecked()) {
                    mTvShareText.setText(mNoRegister);
                } else if (mCbxRegisterAddress.isChecked()) {
                    mTvShareText.setText(mNoInvite);
                } else {
                    mTvShareText.setText(mNoInviteNoRegister);
                }
            }

            if (shareLabels.length > 0) {
                List<String> labelList = new ArrayList<>();
                for (String str : shareLabels) {
                    int startIndex = str.indexOf("【");
                    int endIndex = str.indexOf("】");
                    String label = str.substring(startIndex + 1, endIndex);
                    if (!TextUtils.isEmpty(label)) {
                        labelList.add(label);
                    }
                }
                mCbxInviteCode.setText(labelList.get(0));
                mCbxRegisterAddress.setText(labelList.get(1));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public class GoodsImageAdapter extends CustomBaseAdapter<String> {
        //R.layout.adapter_item_share_goods_image_item

        GoodsImageAdapter(int layoutId, List<String> list) {
            super(layoutId, list);
        }

        @Override
        public RecyclerView.ViewHolder onCreateCustomViewHolder(View view) {
            return new GoodsImagesHolder(view);
        }

        @Override
        public void onBindCustomViewHolder(RecyclerView.ViewHolder viewHolder, String url, int position) {
            try {
                if (viewHolder instanceof GoodsImagesHolder) {
                    GoodsImagesHolder holder = (GoodsImagesHolder) viewHolder;

                    GlideUtils.loadIntoUseTarget(ShareGoodsActivity.this, url, new SimpleTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            try {
                                holder.icon.setImageBitmap(resource);

                                Disposable disposable = Observable.create(new ObservableOnSubscribe<String>() {
                                    @Override
                                    public void subscribe(ObservableEmitter<String> emitter) throws Exception {

                                        String name = Constants.SHARE_FILE_NAME_PREFIX + (position + 1); //从1开始
                                        String imagePath = BitmapUtil.saveBitmapExternalCache(ShareGoodsActivity.this, resource, name);
                                        LogUtil.d(TAG, "onResourceReady: imagepath=" + imagePath);
                                        emitter.onNext(imagePath);
                                    }
                                }).subscribeOn(Schedulers.newThread())
                                        .observeOn(AndroidSchedulers.mainThread())
                                        .subscribe(s -> {
                                            if (mHashImagePath != null) {
                                                //不保证顺序
                                                mHashImagePath.put(url, s);
                                            }
                                        });
                                mCompositeDisposable.add(disposable);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        class GoodsImagesHolder extends CustomBaseAdapter.CustomBaseHolder {
            private ImageView icon;
            private CheckBox cbx;

            GoodsImagesHolder(@NonNull View itemView) {
                super(itemView);
                icon = itemView.findViewById(R.id.iv_share_goods_image);
                cbx = itemView.findViewById(R.id.cbx_share_goods_image);
                cbx.setOnCheckedChangeListener((buttonView, isChecked) -> {
                    if (mGoodsBean != null) {
                        String imageUrl = mGoodsBean.getSmallImages().get((this.getAdapterPosition()));
                        if (mHashImagePath.containsKey(imageUrl)) {
                            if (isChecked) {
                                if (!mShareImages.contains(mHashImagePath.get(imageUrl))) {
                                    mShareImages.add(mHashImagePath.get(imageUrl));
                                }
                            } else {
                                mShareImages.remove(mHashImagePath.get(imageUrl));
                            }
                        }
                    }

                });
            }
        }

    }

    /**
     * 检测权限
     */
    public void checkPermission(int permissionType) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (permissionType == REQUEST_CODE_PERMISSION_STORAGE) {
                //如果没有申请权限
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    AndPermission.with(this)
                            .requestCode(REQUEST_CODE_PERMISSION_STORAGE)
                            .permission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            .callback(permissionListener)
                            .start();
                } else {
                    initDatas();
                }
            }
        } else {
            initDatas();
        }
    }

    /**
     * 回调监听。
     */
    private PermissionListener permissionListener = new PermissionListener() {
        @Override
        public void onSucceed(int requestCode, @NonNull List<String> grantPermissions) {
            if (requestCode == REQUEST_CODE_PERMISSION_STORAGE) {
                try {
                    initDatas();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        public void onFailed(int requestCode, @NonNull List<String> deniedPermissions) {
            if (requestCode == REQUEST_CODE_PERMISSION_STORAGE) {
                toastMsg(getString(R.string.common_get_sd_permission_error));
            }
        }
    };

    private void showShareDialog(List<String> imageList) {
        if (imageList == null || imageList.size() == 0) {
            toastMsg(getString(R.string.common_please_select_images_to_share));
            return;
        }

        if (mUmShareManager == null) {
            mUmShareManager = new UMShareManager(this);
        }

        if (imageList.size() > 1) {
            mUmShareManager.shareImagesWithFiles(this, imageList, mGoodsBean.getTitle());

        } else if (imageList.size() == 1) {
            mUmShareManager.shareImageWithFile(this, imageList.get(0), null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        UMShareManager.onActivityResult(this, requestCode, resultCode, data);
    }

    private String convertShareText(List<String> shareList) {
        if (shareList == null || shareList.size() == 0) {
            return null;
        }

        StringBuilder result = new StringBuilder();

        for (String str : shareList) {
            result.append(str);
            result.append("\n");
        }
        LogUtil.d(TAG, "convertShareText: " + result.toString());
        return result.toString();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LogUtil.d(TAG, "onDestroy: ");
        if (mShareImages != null) {
            mShareImages.clear();
        }

        mGoodsBean = null;
        mUmShareManager = null;

        if (mPresenter != null) {
            mPresenter.detach();
            mPresenter.destroy();
            mPresenter = null;
        }

        mCompositeDisposable.clear();
        mCompositeDisposable = null;
        UMShareManager.release(this);
    }

}
