package com.ozmobi.coupons.common.network;

/**
 * Created by xhkj on 2019/6/5.
 */

public interface Urls {
    /**
     * H5链接，用户协议
     */
    String COUPONS_REGISTER_PROTOCOL_H5_URL = "http://tbk.free-eyepro.com/page.php?m=pages&p=registerprotocol&api=";

    /**
     * App下载地址
     */
    @Deprecated
    String APP_DOWNLOAD_URL = "http://tbk.free-eyepro.com/index.php?m=user&p=share";

    /**
     * H5链接，领券指南
     */
    String USE_HELP_H5_URL = "http://tbk.free-eyepro.com/page.php?m=pages&p=coupontips&api=";

    /**
     * H5链接，地推物料
     */
    @Deprecated
    String AD_MATERIAL_H5_URL = "http://tbk.free-eyepro.com/page.php?m=pages&p=material&api=";

    /**
     * H5链接，新手指引
     */
    String NEW_USER_GUIDE_H5_URL = "http://tbk.free-eyepro.com/page.php?m=pages&p=guide&api=";

    /**
     * H5链接，常见问题
     */
    String COMMON_QUESTIONS_H5_URL = "http://tbk.free-eyepro.com/page.php?m=pages&p=faq&api=";

    /**
     * H5链接，我的收益模块规则
     */
    String MY_INCOME_H5_URL = "http://tbk.free-eyepro.com/page.php?m=pages&p=income&api=";
}
