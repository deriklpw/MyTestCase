package com.ozmobi.coupons.common.data.source;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.alibaba.fastjson.JSONObject;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;

/**
 * Created by xhkj on 2019/5/23.
 */

public interface UserDataSource extends BaseDataSource {

    /**
     *
     * @param invite 邀请码或手机号
     * @return
     */
    Disposable queryInvitation(@NonNull String invite,
                               @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 检查是否被注册
     * @param mobile 手机号
     * @return
     */
    Disposable checkMobile(@NonNull String mobile,
                           @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取验证码
     * @param mobile 手机号
     * @return
     */
    Disposable requestMessageCode(@NonNull String mobile,
                                  @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 手机号注册
     * @param mobile 手机号
     * @param messageCode 验证码
     * @param invite 邀请码
     * @return
     */
    Disposable registerMobile(@NonNull String mobile, @NonNull String messageCode, @Nullable String invite,
                              @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 密码登录
     * @param mobile 手机号
     * @param pwd 密码
     * @return
     */
    Disposable loginWithPwd(@NonNull String mobile, @NonNull String pwd,
                            @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 验证码登录
     * @param mobile 手机号
     * @param messageCode 验证码
     * @return
     */
    Disposable loginWithCode(@NonNull String mobile, @NonNull String messageCode,
                             @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 重置密码
     * @param mobile 手机号
     * @param messageCode 验证码
     * @param newPwd 新密码
     * @return
     */
    Disposable resetPassword(@NonNull String mobile, @NonNull String messageCode, @NonNull String newPwd,
                             @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 使用微信账号注册
     * @param mobile 手机号
     * @param messageCode 验证码
     * @param invite 邀请码
     * @param openId 微信openid
     * @param name 微信昵称
     * @param iconUrl 微信头像
     * @param gender 性别
     * @return
     */
    Disposable registerWithWeChat(@NonNull String mobile, @NonNull String messageCode, @Nullable String invite, @NonNull String unionId, @NonNull String openId, @NonNull String name, @NonNull String iconUrl, int gender,
                                  @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 使用微信账号登录
     * @param openId 微信openid
     * @param name 微信昵称
     * @param iconUrl 微信头像
     * @param gender 性别
     * @return
     */
    Disposable loginWithWeChat(@NonNull String unionId, @NonNull String openId, @NonNull String name, @NonNull String iconUrl, int gender,
                               @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 更新用户昵称
     * @param nickName
     * @param success
     * @param error
     * @return
     */
    Disposable updateUserNickName(@NonNull String nickName, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 更新用户头像
     * @param gender
     * @param success
     * @param error
     * @return
     */
    Disposable updateUserGender(@NonNull String gender, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 更新用户头像
     * @param iconBase64
     * @param success
     * @param error
     * @return
     */
    Disposable updateUserIcon(@NonNull String iconBase64, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 解绑淘宝
     * @return
     */
    Disposable unbindTaoBaoAccount(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 绑定微信
     * @return
     */
    Disposable bindWeChatAccount(@NonNull String unionId, @NonNull String openId, @NonNull String name, @NonNull String iconUrl, int gender,
                                 @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);
    /**
     * 解绑微信
     * @return
     */
    Disposable unbindWeChatAccount(@NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 修改手机号
     * @return
     */
    Disposable modifyMobile(@NonNull String mobile, @NonNull String msgCode, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 校验验证码
     * @return
     */
    Disposable checkMessageCode(@NonNull String mobile, @NonNull String msgCode, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 获取用户消息
     * @param type
     * @param success
     * @param error
     * @return
     */
    Disposable getUserMessage(@NonNull String type, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

    /**
     * 一键登录
     * @param loginToken
     * @param success
     * @param error
     * @return
     */
    Disposable loginWithOneKeyMobile(@NonNull String loginToken, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error);

}
