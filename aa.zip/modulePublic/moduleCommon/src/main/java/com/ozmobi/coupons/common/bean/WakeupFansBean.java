package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/8/21.
 */

public class WakeupFansBean {

    private int error;
    private String msg;
    private DataBean data;
    private int time;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public static class DataBean {
        private String sms_money;
        private String sms_price;
        private List<SmsTemplateBean> sms_template;

        public String getSms_money() {
            return sms_money;
        }

        public void setSms_money(String sms_money) {
            this.sms_money = sms_money;
        }

        public String getSms_price() {
            return sms_price;
        }

        public void setSms_price(String sms_price) {
            this.sms_price = sms_price;
        }

        public List<SmsTemplateBean> getSms_template() {
            return sms_template;
        }

        public void setSms_template(List<SmsTemplateBean> sms_template) {
            this.sms_template = sms_template;
        }

        public static class SmsTemplateBean {
            private String id;
            private String content;
            private String recommend;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getRecommend() {
                return recommend;
            }

            public void setRecommend(String recommend) {
                this.recommend = recommend;
            }
        }
    }
}
