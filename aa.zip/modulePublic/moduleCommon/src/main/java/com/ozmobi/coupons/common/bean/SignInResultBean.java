package com.ozmobi.coupons.common.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/9/25.
 */

public class SignInResultBean {
    private int error;
    private String msg;
    private DataBean data;
    private int time;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public static class DataBean {
        private boolean check_success;
        private int check_integral;
        private int continue_days;
        private String reward_tips;
        private List<CheckDateBean> check_date;

        public boolean isCheck_success() {
            return check_success;
        }

        public void setCheck_success(boolean check_success) {
            this.check_success = check_success;
        }

        public int getCheck_integral() {
            return check_integral;
        }

        public void setCheck_integral(int check_integral) {
            this.check_integral = check_integral;
        }

        public int getContinue_days() {
            return continue_days;
        }

        public void setContinue_days(int continue_days) {
            this.continue_days = continue_days;
        }

        public String getReward_tips() {
            return reward_tips;
        }

        public void setReward_tips(String reward_tips) {
            this.reward_tips = reward_tips;
        }

        public List<CheckDateBean> getCheck_date() {
            return check_date;
        }

        public void setCheck_date(List<CheckDateBean> check_date) {
            this.check_date = check_date;
        }

        public static class CheckDateBean {
            private String date;
            private boolean checkin;
            private boolean today;

            public String getDate() {
                return date;
            }

            public void setDate(String date) {
                this.date = date;
            }

            public boolean isCheckin() {
                return checkin;
            }

            public void setCheckin(boolean checkin) {
                this.checkin = checkin;
            }

            public boolean isToday() {
                return today;
            }

            public void setToday(boolean today) {
                this.today = today;
            }
        }
    }
}
