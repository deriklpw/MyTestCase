package com.ozmobi.coupons.common.ui.search.result;

import com.alibaba.fastjson.JSON;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.IMoreContract;
import com.ozmobi.coupons.common.data.source.SearchDataSource;
import com.ozmobi.coupons.common.data.source.remote.SearchRepository;
import com.ozmobi.coupons.base.Constants;

public class SearchResultPresenter extends IMoreContract.AbsMorePresenter<SearchResultContract.View, SearchDataSource> {

    private static final String TAG = "SearchResultPresenter";

    private String mSubCateName;

    private String mSort;

    public SearchResultPresenter(SearchResultContract.View view, String subCateName) {
        super(new SearchRepository());
        mSubCateName = subCateName;
        this.attach(view);
        view.setPresenter(this);
    }

    @Override
    public void start() {
        if (getBaseView() != null) {
            getBaseView().showLoading();
        }
        loadData(1);
    }

    @Override
    public void setSortAndReload(String sort) {
        mSort = sort;
        start();
    }

    @Override
    protected void loadData(int page) {
        if (getBaseRepository() == null) {
            if (getBaseView() != null && getBaseView().isLoading()) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
            }
            return;
        }
        addOperatorDisposable(getBaseRepository().getSearchGoods(mSubCateName, Constants.PAGE_SIZE_LOAD_DEFAULT, page, mSort, commonGoodsBean -> {
            LogUtil.d(TAG, "reLoadSearchResultGoods: size=" + commonGoodsBean.getData().getProducts().size());
            LogUtil.d(TAG, "reLoadSearchResultGoods: json=" + JSON.toJSONString(commonGoodsBean));
            //回调热门商品
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
                if (commonGoodsBean.getData() != null) {
                    getBaseView().showData(commonGoodsBean.getData().getProducts());
                }
            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().hideLoading();
                getBaseView().setRefresh(false);
                getBaseView().showGetDataError();
            }
        }));
    }

    @Override
    protected void loadMoreData(int page) {
        if (getBaseRepository() == null) {
            return;
        }
        addOperatorDisposable(getBaseRepository().getSearchGoods(mSubCateName, Constants.PAGE_SIZE_LOAD_MORE, page, mSort, commonGoodsBean -> {
            LogUtil.d(TAG, "moreSearchResultGoods: size=" + commonGoodsBean.getData().getProducts().size());
            //回调热门商品
            if (getBaseView() != null) {
                if (commonGoodsBean.getData() != null) {
                    getBaseView().showMoreData(commonGoodsBean.getData().getProducts());
                }
            }
        }, throwable -> {
            if (getBaseView() != null) {
                getBaseView().showError();
            }
        }));
    }

}
