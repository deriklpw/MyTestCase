package com.ozmobi.coupons.common.utils;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.ozmobi.coupons.common.greendao.DaoMaster;
import com.ozmobi.coupons.common.greendao.GoodsBeanDao;

import org.greenrobot.greendao.database.Database;

public class CouponDevOpenHelper extends DaoMaster.DevOpenHelper {
    public CouponDevOpenHelper(Context context, String name) {
        super(context, name);
    }

    public CouponDevOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory) {
        super(context, name, factory);
    }

    @Override
    public void onUpgrade(Database db, int oldVersion, int newVersion) {
        try {
            if (oldVersion == 1) {
                String[] sqls = {"alter table " + GoodsBeanDao.TABLENAME + " add column " + GoodsBeanDao.Properties.CommissionRate.columnName + " DOUBLE ",
                        "alter table " + GoodsBeanDao.TABLENAME + " add column " + GoodsBeanDao.Properties.CommissionFee.columnName + " TEXT ",
                        "alter table " + GoodsBeanDao.TABLENAME + " add column " + GoodsBeanDao.Properties.UpCommissionFee.columnName + " TEXT ",
                        "alter table " + GoodsBeanDao.TABLENAME + " add column " + GoodsBeanDao.Properties.Share.columnName + " TEXT ",
                        "alter table " + GoodsBeanDao.TABLENAME + " add column " + GoodsBeanDao.Properties.ShareFree.columnName + " TEXT "};
                for (String sql : sqls) {
                    db.execSQL(sql);
                }
            }

            //db.execSQL后等于是oldVersion升一级
            oldVersion++;
            //升级后还是比最新版低级的话，继续升级
            if (oldVersion < newVersion) {
                //递归
                onUpgrade(db, oldVersion, newVersion);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
