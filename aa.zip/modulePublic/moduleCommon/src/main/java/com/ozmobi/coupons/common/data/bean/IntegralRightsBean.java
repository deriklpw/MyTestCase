package com.ozmobi.coupons.common.data.bean;

import android.os.Parcel;
import android.os.Parcelable;

public class IntegralRightsBean implements Parcelable {
    private int iconResId;
    private String title;
    private String desc;

    public IntegralRightsBean(int iconResId, String title, String desc) {
        this.iconResId = iconResId;
        this.title = title;
        this.desc = desc;
    }

    protected IntegralRightsBean(Parcel in) {
        iconResId = in.readInt();
        title = in.readString();
        desc = in.readString();
    }

    public static final Creator<IntegralRightsBean> CREATOR = new Creator<IntegralRightsBean>() {
        @Override
        public IntegralRightsBean createFromParcel(Parcel in) {
            return new IntegralRightsBean(in);
        }

        @Override
        public IntegralRightsBean[] newArray(int size) {
            return new IntegralRightsBean[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(iconResId);
        dest.writeString(title);
        dest.writeString(desc);
    }

    public int getIconResId() {
        return iconResId;
    }

    public void setIconResId(int iconResId) {
        this.iconResId = iconResId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
