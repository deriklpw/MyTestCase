package com.ozmobi.coupons.common.events;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by xhkj on 2019/10/26.
 */

public class EventAppBar implements Parcelable {
    private int[] bgColors;
    private int tabTextSelectColor;
    private int tabTextUnSelectColor;
    private int tabIndicatorColor;
    private int iconColor;
    private int searchBarBgColor;
    private int searchBarIconColor;
    private int searchBarTextColor;

    public EventAppBar() {
    }

    protected EventAppBar(Parcel in) {
        bgColors = in.createIntArray();
        tabTextSelectColor = in.readInt();
        tabTextUnSelectColor = in.readInt();
        tabIndicatorColor = in.readInt();
        iconColor = in.readInt();
        searchBarBgColor = in.readInt();
        searchBarIconColor = in.readInt();
        searchBarTextColor = in.readInt();
    }

    public static final Creator<EventAppBar> CREATOR = new Creator<EventAppBar>() {
        @Override
        public EventAppBar createFromParcel(Parcel in) {
            return new EventAppBar(in);
        }

        @Override
        public EventAppBar[] newArray(int size) {
            return new EventAppBar[size];
        }
    };

    public int[] getBgColors() {
        return bgColors;
    }

    public void setBgColors(int[] bgColors) {
        this.bgColors = bgColors;
    }

    public int getTabTextSelectColor() {
        return tabTextSelectColor;
    }

    public void setTabTextSelectColor(int tabTextSelectColor) {
        this.tabTextSelectColor = tabTextSelectColor;
    }

    public int getTabTextUnSelectColor() {
        return tabTextUnSelectColor;
    }

    public void setTabTextUnSelectColor(int tabTextUnSelectColor) {
        this.tabTextUnSelectColor = tabTextUnSelectColor;
    }

    public int getTabIndicatorColor() {
        return tabIndicatorColor;
    }

    public void setTabIndicatorColor(int tabIndicatorColor) {
        this.tabIndicatorColor = tabIndicatorColor;
    }

    public int getIconColor() {
        return iconColor;
    }

    public void setIconColor(int iconColor) {
        this.iconColor = iconColor;
    }

    public int getSearchBarBgColor() {
        return searchBarBgColor;
    }

    public void setSearchBarBgColor(int searchBarBgColor) {
        this.searchBarBgColor = searchBarBgColor;
    }

    public int getSearchBarIconColor() {
        return searchBarIconColor;
    }

    public void setSearchBarIconColor(int searchBarIconColor) {
        this.searchBarIconColor = searchBarIconColor;
    }

    public int getSearchBarTextColor() {
        return searchBarTextColor;
    }

    public void setSearchBarTextColor(int searchBarTextColor) {
        this.searchBarTextColor = searchBarTextColor;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeIntArray(bgColors);
        dest.writeInt(tabTextSelectColor);
        dest.writeInt(tabTextUnSelectColor);
        dest.writeInt(tabIndicatorColor);
        dest.writeInt(iconColor);
        dest.writeInt(searchBarBgColor);
        dest.writeInt(searchBarIconColor);
        dest.writeInt(searchBarTextColor);
    }
}
