package com.ozmobi.coupons.common.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.ozmobi.coupons.base.utils.AppUtils;
import com.ozmobi.coupons.common.R;
import com.ozmobi.coupons.base.utils.IconTextUtil;

/**
 * Created by xhkj on 2019/7/4.
 */

public class CustomShareImage extends ConstraintLayout {

    private TextView mTvShareQrGoodsTitle;
    private TextView mTvShareQrCurrentPriceLabel;
    private View mCouponContainerView;
    private TextView mTvShareQrCurrentPrice;
    private TextView mTvShareQrCouponValue;
    private CustomLineTextView mClvOriginPrice;
    private ImageView mIvGoodsImage;
    private TextView mTvShareQrCurrentPrice2;
    private ImageView mIvShareQrLink;

    private Context mContext;

    public CustomShareImage(@NonNull Context context) {
        this(context, null);
    }

    public CustomShareImage(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        View view = inflate(getContext(), R.layout.common_layout_share_goods_info_with_qr_image, this);

//        mLayoutQrInfo = view.findViewById(R.id.layout_share_goods_info_with_qr_image);
        mTvShareQrGoodsTitle = view.findViewById(R.id.tv_share_qr_info_title);
        mTvShareQrCurrentPriceLabel = view.findViewById(R.id.tv_share_qr_info_after_coupon_price);
        mCouponContainerView = view.findViewById(R.id.ll_share_qr_info_coupon);
        mTvShareQrCurrentPrice = view.findViewById(R.id.tv_share_qr_info_after_coupon_price_value);
        mTvShareQrCouponValue = view.findViewById(R.id.tv_share_qr_info_coupon_value);
        mClvOriginPrice = view.findViewById(R.id.clv_share_qr_info_origin_price);
        mIvGoodsImage = view.findViewById(R.id.iv_share_qr_info_goods_image);
        mTvShareQrCurrentPrice2 = view.findViewById(R.id.tv_share_qr_info_goods_price_value);
        mIvShareQrLink = view.findViewById(R.id.iv_share_qr_info_qr);
        TextView tvAppShareTag = view.findViewById(R.id.tv_share_goods_app_tag);
        tvAppShareTag.setText(AppUtils.getApplicationName(context));
    }

    public void setShareGoodsTitle(String type, String title) {
        if (!TextUtils.isEmpty(type)) {
            if ("tmall".equals(type)) {
                //设置天猫图标
                IconTextUtil.setIconAndTextInTextView(mContext, mTvShareQrGoodsTitle, R.mipmap.common_ic_tianmao_logo, title);
            } else if ("taobao".equals(type)) {
                //设置淘宝图标
                IconTextUtil.setIconAndTextInTextView(mContext, mTvShareQrGoodsTitle, R.mipmap.common_ic_taobao_logo, title);
            } else {
                mTvShareQrGoodsTitle.setText(title);
            }
        } else {
            mTvShareQrGoodsTitle.setText(title);
        }
    }

    public void setCouponsVisibility(int visibility) {
        if (visibility == View.VISIBLE) {
            mTvShareQrCurrentPriceLabel.setText(mContext.getResources().getString(R.string.common_price_after_coupon_label));
        } else {
            mTvShareQrCurrentPriceLabel.setText(mContext.getResources().getString(R.string.common_money_symbol));
        }

        mCouponContainerView.setVisibility(visibility);
        //没有券，也就没有原价
        mClvOriginPrice.setVisibility(visibility);
    }

    public void setCurrentPrice(String price) {
        mTvShareQrCurrentPrice.setText(price);
        mTvShareQrCurrentPrice2.setText(price);
    }

    public void setCouponValue(String couponValue) {
        mTvShareQrCouponValue.setText(couponValue);
    }

    public void setOriginPrice(String price) {
        mClvOriginPrice.setText(price);
    }

    public void setQrCodeImageBitmap(Bitmap bitmap) {
        mIvShareQrLink.setImageBitmap(bitmap);
    }

    public void setGoodsImageBitmap(Bitmap bitmap) {
        mIvGoodsImage.setImageBitmap(bitmap);
    }

    public ImageView getGoodsImageView() {
        return mIvGoodsImage;
    }
}
