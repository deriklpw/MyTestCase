package com.ozmobi.coupons.common.events;

public class EventMessage {
    public static final int OPEN_TAB = 0;
    public static final int OPEN_DIALOG_CONFIRM = 1;
    public static final int OPEN_DIALOG_CONFIRM_CANCEL = 2;
    public static final int OPEN_DIALOG_FOR_IMAGE = 3;

    private int cmd;
    private String title;
    private String desc;
    private String ext;

    public EventMessage() {

    }

    public EventMessage(int cmd, String ext) {
        this.cmd = cmd;
        this.ext = ext;
    }

    public EventMessage(int cmd, String title, String ext) {
        this.cmd = cmd;
        this.title = title;
        this.ext = ext;
    }

    public EventMessage(int cmd, String title, String ext, String desc) {
        this.cmd = cmd;
        this.title = title;
        this.ext = ext;
        this.desc = desc;
    }

    public int getCmd() {
        return cmd;
    }

    public void setCmd(int cmd) {
        this.cmd = cmd;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getExt() {
        return ext;
    }

    public void setExt(String ext) {
        this.ext = ext;
    }
}
