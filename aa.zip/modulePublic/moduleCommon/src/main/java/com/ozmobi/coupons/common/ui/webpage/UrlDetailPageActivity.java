package com.ozmobi.coupons.common.ui.webpage;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.IntDef;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.ozmobi.coupons.baichuan.AlibaichManager;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.BaseActivity;
import com.ozmobi.coupons.common.R;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

public class UrlDetailPageActivity extends BaseActivity {

    private static final String TAG = "UrlDetailPageActivity";
    private static final String EXTRA_KEY_TITLE = "page-title";
    private static final String EXTRA_KEY_URL = "page-url";
    private static final String EXTRA_KEY_URL_TYPE = "url-type";

    public static final int URL_TB_PUSH = 2;
    public static final int URL_TB_AUTH = 1;
    public static final int URL_COMMON = 0;

    private WebView mWebView;
    private ProgressBar mLoadingProgress;
    private String mUrl;

    private WebChromeClient mWebChromeClient;
    private WebViewClient mWebViewClient;

    @Documented
    @IntDef({
            URL_TB_PUSH,
            URL_TB_AUTH,
            URL_COMMON
    })
    @Target({ElementType.PARAMETER})
    @Retention(RetentionPolicy.SOURCE)
    @interface UrlType {
    }

    @Override
    protected int getLayoutId() {
        return R.layout.common_activity_web_page_detail;
    }

    @Override
    protected void initViews() {
        mWebView = findViewById(R.id.webview_detail_url);
        mLoadingProgress = findViewById(R.id.pb_loading);
        initWebView();

        initDatas();
    }

    private void initWebView() {
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setDomStorageEnabled(true);
        webSettings.setJavaScriptEnabled(true);
        webSettings.setBlockNetworkImage(false);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setLoadsImagesAutomatically(true);
        webSettings.setDefaultTextEncodingName("utf-8");
        mWebView.addJavascriptInterface(new JavaScriptAndroidSDK(), "AndroidSDK");

        mWebChromeClient = new WebChromeClient() {

            public void onProgressChanged(WebView view, int newProgress) {
                LogUtil.d(TAG, "onProgressChanged: " + newProgress);
                if (newProgress == 100) {
                    mLoadingProgress.setVisibility(View.GONE);
                } else {
                    if (mLoadingProgress.getVisibility() != View.VISIBLE) {
                        mLoadingProgress.setVisibility(View.VISIBLE);
                    }
                    mLoadingProgress.setProgress(newProgress);
                }
            }
        };

        mWebViewClient = new WebViewClient() {

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                LogUtil.d(TAG, "shouldOverrideUrlLoading: " + url);

                if (url == null) {
                    return false;
                }

                //拦截deeplink
                if (url.startsWith("http")) {
                    //26以下返回false，不会重定向，需要view.loadUrl，true拦截
                    //26以上返回false，会重定向，不需要view.loadUrl
                    if (Build.VERSION.SDK_INT < 26) {
                        view.loadUrl(url);
                        return true;
                    }
                } else {
                    try {
                        //指定可以打开的deeplink
                        if (url.startsWith("weixin://") //微信
                                || url.startsWith("alipays://") //支付宝
                                || url.startsWith("mailto://") //邮件
                                || url.startsWith("tel://")//电话
                                ) {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                            startActivity(intent);
                            return true;
                        }
                    } catch (Exception e) { //防止crash (如果手机上没有安装处理某个scheme开头的url的APP, 会导致crash)
                        return true;//没有安装该app时，返回true，表示拦截自定义链接，但不跳转，避免弹出上面的错误页面
                    }
                    //其他，拦截
                    return true;
                }
                return false;
            }
        };

        //处理WebView返回
        mWebView.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                LogUtil.d(TAG, "initWebView: " + mWebView.canGoBack());
                if (keyCode == KeyEvent.KEYCODE_BACK && mWebView.canGoBack()) {  //表示按返回键时的操作
                    mWebView.goBack();   //后退
                    return true;    //已处理
                }
            }
            return false;
        });
    }

    private void initDatas() {
        String title = getIntent().getStringExtra(EXTRA_KEY_TITLE);
        mUrl = getIntent().getStringExtra(EXTRA_KEY_URL);
        if (!TextUtils.isEmpty(title)) {
            setToolbarTitle(title);
        }

        int urlType = getIntent().getIntExtra(EXTRA_KEY_URL_TYPE, 0);
        if (urlType == URL_TB_AUTH) {
            //授权需带自定义webview，js控制退出
            AlibaichManager.showUrlPage(this, mWebView, mWebViewClient, mWebChromeClient, mUrl);
        } else if (urlType == URL_TB_PUSH) {
            //推送淘宝链接，使用当前Activity承载
            AlibaichManager.showUrlPage(this, mUrl);
        } else {
            mWebView.setWebChromeClient(mWebChromeClient);
            mWebView.setWebViewClient(mWebViewClient);

            mWebView.loadUrl(mUrl);
        }
    }

    /**
     * 自定义Activity处理url
     *
     * @param context
     * @param title
     * @param url
     */
    public static void startForUrlDetail(Context context, String title, String url, @UrlType int urlType) {
        if (context != null && !TextUtils.isEmpty(url)) {
            LogUtil.d(TAG, "startForUrlDetail: ");

            Intent intent = new Intent(context, UrlDetailPageActivity.class);
            intent.putExtra(EXTRA_KEY_TITLE, title);
            intent.putExtra(EXTRA_KEY_URL, url);
            intent.putExtra(EXTRA_KEY_URL_TYPE, urlType);
            context.startActivity(intent);
        }
    }

    /**
     * 网页授权成功后，js调用关闭Activity
     */
    public class JavaScriptAndroidSDK {
        @JavascriptInterface
        public void navback(String json) {
            LogUtil.d(TAG, "get json from js: json");
            finish();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        LogUtil.d(TAG, "onCreateOptionsMenu: ");
        getMenuInflater().inflate(R.menu.common_menu_url_refresh, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        LogUtil.d(TAG, "onOptionsItemSelected: id= " + id);
        if (id == android.R.id.home) {
            LogUtil.d(TAG, "initWebView: can back=" + mWebView.canGoBack());
            if (mWebView != null && mWebView.canGoBack()) { //表示按返回键时的操作
                mWebView.goBack();   //后退
                return true;    //已处理
            }
        } else if (id == R.id.menu_url_refresh) {
            mWebView.loadUrl(mUrl);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ViewParent parent = mWebView.getParent();
        if (parent != null) {
            ((ViewGroup) parent).removeView(mWebView);
        }

        mWebView.stopLoading();
        mWebView.getSettings().setJavaScriptEnabled(false);
        mWebView.clearHistory();
        mWebView.removeAllViews();
        mWebView.destroy();
    }
}
