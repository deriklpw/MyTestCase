package com.ozmobi.coupons.common.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatTextView;
import android.util.AttributeSet;

import com.ozmobi.coupons.common.R;


/**
 * Created by xhkj on 2019/5/15.
 */

public class CustomLineTextView extends AppCompatTextView {
    private static final String TAG = "CustomLineTextView";

    private Paint mPaint;

    private int mLineColor;

    public CustomLineTextView(Context context) {
        this(context, null);
    }

    public CustomLineTextView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CustomLineTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.CustomLineTextView, defStyleAttr, 0);
        mLineColor = typedArray.getColor(R.styleable.CustomLineTextView_middleLineColor, Color.GRAY);
        typedArray.recycle();
        initPaint();
    }

    public void setMiddleLineColor(int lineColor) {
        this.mLineColor = lineColor;
    }

    private void initPaint() {
        mPaint = new Paint();
        mPaint.setColor(mLineColor);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getMeasuredWidth();
        int height = getMeasuredHeight();
        canvas.drawRect(0, (height / 2), width, (height / 2) + 2, mPaint);
    }
}
