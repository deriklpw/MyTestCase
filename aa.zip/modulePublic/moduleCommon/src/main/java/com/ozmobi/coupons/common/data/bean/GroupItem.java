package com.ozmobi.coupons.common.data.bean;

import java.util.List;

/**
 * Created by xhkj on 2019/7/24.
 */

public class GroupItem<T> {
    private String groupName;
    private List<T> items;

    public GroupItem(String groupName, List<T> items) {
        this.groupName = groupName;
        this.items = items;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public List<T> getItems() {
        return items;
    }

    public void setItems(List<T> items) {
        this.items = items;
    }
}
