package com.ozmobi.coupons.common.ui.goodsdetails.shop;

import com.ozmobi.coupons.common.AbsBasePresenter;
import com.ozmobi.coupons.common.BaseView;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.data.source.GoodsDataSource;

/**
 * Created by xhkj on 2019/6/15.
 */

public interface ShopCouponsContract {
    interface View extends BaseView {

        void setRefresh(boolean enable);

        void setShopCouponsGoods(CommonGoodsBean commonGoodsBean);
    }

    abstract class Presenter extends AbsBasePresenter<ShopCouponsContract.View, GoodsDataSource> {
        public Presenter(GoodsDataSource goodsDataSource) {
            super(goodsDataSource);
        }

        abstract void getShopCouponsGoods();
    }
}
