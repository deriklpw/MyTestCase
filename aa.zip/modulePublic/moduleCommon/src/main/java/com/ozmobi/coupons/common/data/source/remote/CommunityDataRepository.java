package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;

import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.CommunityKindBean;
import com.ozmobi.coupons.common.data.source.CommunityDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;


/**
 * Created by xhkj on 2019/6/15.
 */

public class CommunityDataRepository implements CommunityDataSource {

    private static final String TAG = "CommunityDataRepository";

    @Override
    public Disposable getCommunityKind(@NonNull Consumer<? super CommunityKindBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG, "getCommunityKind post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<CommunityKindBean> observable = ApiFactory.getYjlController().getCommunityKind(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable getCommunity(@NonNull String kind, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());

            JSONObject params = new JSONObject();
            params.put("kind", kind);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getCommunity post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController().getCommunity(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }

    @Override
    public Disposable shareCommunityContent(@NonNull String id, @NonNull Consumer<? super JSONObject> success, @NonNull Consumer<? super Throwable> error) {
        String json = "";
        try {
            JSONObject rootJson = JSONObject.parseObject(DeviceUtil.getJsonDeviceInfo());

            JSONObject params = new JSONObject();
            params.put("id", id);
            rootJson.put("param", params);

            json = rootJson.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        LogUtil.d(TAG, "getCommunity post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        Observable<JSONObject> observable = ApiFactory.getYjlController().shareCommunityContent(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        return observable.subscribe(success, error);
    }
}
