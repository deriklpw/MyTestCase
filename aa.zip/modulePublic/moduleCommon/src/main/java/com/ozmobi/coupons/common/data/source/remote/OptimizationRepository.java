package com.ozmobi.coupons.common.data.source.remote;

import android.support.annotation.NonNull;

import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.common.bean.CommonGoodsBean;
import com.ozmobi.coupons.common.data.source.OptimizationDataSource;
import com.ozmobi.coupons.common.network.ApiFactory;
import com.ozmobi.coupons.common.utils.DeviceUtil;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.RequestBody;

public class OptimizationRepository implements OptimizationDataSource {

    private static final String TAG = "OptimizationRepository";

    @Override
    public Disposable getGuessLikeGoods(@NonNull Consumer<? super CommonGoodsBean> success, @NonNull Consumer<? super Throwable> error) {
        String json = DeviceUtil.getJsonDeviceInfo();

        LogUtil.d(TAG,"guess like post json=" + json);

        RequestBody requestBody = RequestBody.create(MEDIA_TYPE_JSON, json);

        return ApiFactory.getYjlController().getGuessLikeGoods(requestBody)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(success, error);
    }
}
