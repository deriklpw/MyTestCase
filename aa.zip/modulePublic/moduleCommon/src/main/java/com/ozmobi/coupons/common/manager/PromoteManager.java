package com.ozmobi.coupons.common.manager;

import android.app.Activity;
import android.content.Intent;
import android.text.TextUtils;

import com.ozmobi.coupons.baichuan.AlibaichManager;
import com.ozmobi.coupons.base.CustomIntents;
import com.ozmobi.coupons.common.ui.goodsdetails.GoodsDetailsActivity;
import com.ozmobi.coupons.common.bean.CommonProductsEntity;
import com.ozmobi.coupons.common.bean.CommonPromoteBean;
//import com.ozmobi.coupons.home.HomeContainerActivity;
import com.ozmobi.coupons.common.ui.webpage.UrlDetailPageActivity;
import com.ozmobi.coupons.common.ui.search.result.SearchResultActivity;
import com.ozmobi.coupons.common.utils.GoodsConvertUtil;

/**
 * Created by xhkj on 2019/10/28.
 */

public class PromoteManager {
    private static final String TYPE_LINK = "link";
    private static final String TYPE_PRODUCT = "product";
    private static final String TYPE_LIST = "list";
    private static final String TYPE_NATIVE = "native";

    public static void routerPromote(Activity activity, CommonPromoteBean commonPromoteBean) {
        try {
            String type = commonPromoteBean.getType();

            if (TYPE_LINK.equals(type)) {
                String url = commonPromoteBean.getUrl();
                if (!TextUtils.isEmpty(url)) {
                    if (commonPromoteBean.getTb() == 1) {
                        //淘宝链接
                        AlibaichManager.showUrlPage(activity, url);
                    } else {
                        //非淘宝链接
                        UrlDetailPageActivity.startForUrlDetail(activity.getApplicationContext(), commonPromoteBean.getTitle(), url, UrlDetailPageActivity.URL_COMMON);
                    }
                }
            } else if (TYPE_PRODUCT.equals(type)) {
                //商品信息
                CommonProductsEntity product = commonPromoteBean.getProduct();
                if (product != null) {
                    GoodsDetailsActivity.startForGoodDetail(activity.getApplicationContext(), GoodsConvertUtil.convertToGoodsBean(product));
                }

            } else if (TYPE_LIST.equals(type)) {
                String title = commonPromoteBean.getTitle();
                String url = commonPromoteBean.getUrl();
                SearchResultActivity.startActivityForUrlGoods(activity.getApplicationContext(), title, url);
            } else if (TYPE_NATIVE.equals(type)) {
                String id = String.valueOf(commonPromoteBean.getId());
                String title = commonPromoteBean.getTitle();
                String cate = commonPromoteBean.getCate();

                Intent intent = new Intent();
                String action = activity.getPackageName() + CustomIntents.INTENT_ACTION_START_HOME_CONTAINER_SUFFIX;
                intent.setAction(action);

//              和HomeContainerActivity对应
                intent.putExtra("key_fragment_name", "target_recommend_nav_fragment");
                intent.putExtra("key_recommend_nav_id", id);
                intent.putExtra("key_recommend_nav_title", title);
                intent.putExtra("key_recommend_nav_cate", cate);
                if (intent.resolveActivity(activity.getPackageManager()) != null) {
                    activity.startActivity(intent);
                }

//              HomeContainerActivity.startActivityForRecommendNavCate(activity.getApplicationContext(), id, title, cate);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
