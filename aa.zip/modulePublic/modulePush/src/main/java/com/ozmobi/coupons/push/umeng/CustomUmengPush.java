package com.ozmobi.coupons.push.umeng;//package com.ozmobi.coupons.push.umeng;
//
//import android.content.Context;
//import android.os.Handler;
//import android.text.TextUtils;
//
//import com.ozmobi.coupons.CouponsApplication;
//import com.ozmobi.coupons.base.utils.LogUtil;
//import com.ozmobi.coupons.utils.NotificationCouponsHandler;
//import com.umeng.message.IUmengRegisterCallback;
//import com.umeng.message.PushAgent;
//import com.umeng.message.UmengMessageHandler;
//import com.umeng.message.UmengNotificationClickHandler;
//import com.umeng.message.entity.UMessage;
//
///**
// * Created by xhkj on 2019/7/27.
// */
//
//public class CustomUmengPush {
//    private static final String TAG = "CustomUmengPush";
//
//    public static void initUmengPush(Context context) {
//        //获取消息推送
//        PushAgent pushAgent = PushAgent.getInstance(context.getApplicationContext());
//
//        //自定义消息不是通知，默认不会被SDK展示到通知栏上
//        //20190612自定义消息
//        UmengMessageHandler messageHandler = new UmengMessageHandler() {
//            @Override
//            public void dealWithCustomMessage(final Context context, final UMessage msg) {
//                new Handler(context.getMainLooper()).post(new Runnable() {
//                    @Override
//                    public void run() {
//                        String custom = msg.custom;
//                        if (!TextUtils.isEmpty(custom)) {
//                            NotificationCouponsHandler.handle(context, custom);
//                        }
//                    }
//                });
//            }
//        };
//        pushAgent.setMessageHandler(messageHandler);
//
//        //注册推送服务，每次调用register方法都会回调该接口
//        pushAgent.register(new IUmengRegisterCallback() {
//            @Override
//            public void onSuccess(String deviceToken) {
//                //注册成功会返回deviceToken deviceToken是推送消息的唯一标志
//                CouponsApplication.getInstance().setDeviceToken(deviceToken);
//                LogUtil.i(TAG, "注册成功：deviceToken：-------->  " + deviceToken);
//            }
//
//            @Override
//            public void onFailure(String s, String s1) {
//                LogUtil.e(TAG, "注册失败：-------->  " + "s:" + s + ",s1:" + s1);
//            }
//        });
//
//        //2019-06-12自定义通知打开动作
//        UmengNotificationClickHandler notificationClickHandler = new UmengNotificationClickHandler() {
//            @Override
//            public void dealWithCustomAction(Context context, UMessage msg) {
//                String custom = msg.custom;
//                if (!TextUtils.isEmpty(custom)) {
//                    NotificationCouponsHandler.handle(context, custom);
//                }
//            }
//        };
//        pushAgent.setNotificationClickHandler(notificationClickHandler);
//    }
//}
