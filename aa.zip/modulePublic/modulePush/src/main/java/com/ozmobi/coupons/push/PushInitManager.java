package com.ozmobi.coupons.push;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.os.Build;

import com.heytap.mcssdk.PushManager;
import com.heytap.mcssdk.callback.PushCallback;
import com.heytap.mcssdk.mode.SubscribeResult;
import com.ozmobi.coupons.base.GlobalAppInfo;
import com.ozmobi.coupons.base.manager.UserInfoManager;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.base.utils.MarketUtil;
import com.ozmobi.coupons.base.utils.PrefUtils;
import com.ozmobi.coupons.push.huawei.HMSAgent;
import com.vivo.push.PushClient;
import com.xiaomi.mipush.sdk.MiPushClient;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PushInitManager {
    private static final String TAG = "PushInitManager";

    /**
     * 小米
     */
    private static final String MIUI_PUSH_TAG_ALL_DEVICE = "MIUI_ALL_DEVICE";

    private static final String MIUI_PUSH_TAG_ALL_DEVICE_OTHER_PHONE = "OTHER_PHONE_ALL_DEVICE";

    /**
     * OPPO
     */
    private static final String OPPO_PUSH_TAG_ALL_DEVICE = "OPPO_ALL_DEVICE";

    /**
     * MEIZU
     */
    private static final String MEIZU_PUSH_ALL_DEVICE = "MEIZU_ALL_DEVICE";

    /**
     * VIVO
     * @param application
     */
    private static final String VIVO_PUSH_ALL_DEVICE = "VIVO_ALL_DEVICE";

    public static void initPushSdk(Application application) {
        String brand = Build.BRAND.toLowerCase();
        switch (brand) {
            case MarketUtil.PHONE_TYPE_HUAWEI:
                //fall through
            case MarketUtil.PHONE_TYPE_HONOR:
                HMSAgent.init(application);
                break;
            case MarketUtil.PHONE_TYPE_OPPO:
                initOppoPush(application.getApplicationContext());
                break;
            case MarketUtil.PHONE_TYPE_MEIZU:
                com.meizu.cloud.pushsdk.PushManager.register(application, BuildConfig.MEIZU_APPID, BuildConfig.MEIZU_APP_KEY);
                break;
            case MarketUtil.PHONE_TYPE_VIVO:
                if (PushClient.getInstance(application).isSupport()) {
                    PushClient.getInstance(application).initialize();
                    GlobalAppInfo.deviceToken = PrefUtils.readString(PrefUtils.KEY_VIVO_PUSH_TOKEN);
                    return;
                }
                //fall through
            case MarketUtil.PHONE_TYPE_XIAOMI:
                //fall through
            default:
                initXiaoMiPush(application);
                break;
        }
    }

    public static void setPushInfo(Activity activity) {
        String brand = Build.BRAND.toLowerCase();
        switch (brand) {
            case MarketUtil.PHONE_TYPE_HUAWEI:
                //fall through
            case MarketUtil.PHONE_TYPE_HONOR:
                setHuaWeiPush(activity);
                break;
            case MarketUtil.PHONE_TYPE_OPPO:
                //OPPO在初始化后的回调中设置
                break;
            case MarketUtil.PHONE_TYPE_MEIZU:
                //魅族初始化成功后，在广播接收器中设置
                break;
            case MarketUtil.PHONE_TYPE_XIAOMI:
                setXiaoMiPush(activity.getApplicationContext());
                break;
            case MarketUtil.PHONE_TYPE_VIVO:
                if (PushClient.getInstance(activity.getApplicationContext()).isSupport()) {
                    setVivoPush(activity.getApplicationContext());
                    return;
                }
                //fall through
            default:
                setXiaoMiPushOtherPhone(activity.getApplicationContext());
                break;
        }

    }

    /**
     * 注册小米推送
     */
    private static void initXiaoMiPush(Context context) {
        if (shouldInit(context)) {
            MiPushClient.registerPush(context, BuildConfig.MIUI_PUSH_APPID, BuildConfig.MIUI_PUSH_APP_KEY);
        }
    }

    private static boolean shouldInit(Context context) {
        if (context == null) {
            return false;
        }
        ActivityManager am = ((ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE));
        List<ActivityManager.RunningAppProcessInfo> processInfos = am.getRunningAppProcesses();
        String mainProcessName = context.getPackageName();
        int myPid = android.os.Process.myPid();
        for (ActivityManager.RunningAppProcessInfo info : processInfos) {
            if (info.pid == myPid && mainProcessName.equals(info.processName)) {
                return true;
            }
        }
        return false;
    }

    public static void reInitPush(Context ctx) {
        MiPushClient.registerPush(ctx.getApplicationContext(), BuildConfig.MIUI_PUSH_APPID, BuildConfig.MIUI_PUSH_APP_KEY);
    }

    /**
     * 设置小米推送，主页启动后调用
     *
     * @param context
     */
    private static void setXiaoMiPush(Context context) {
        //设置通用标签
        MiPushClient.subscribe(context, MIUI_PUSH_TAG_ALL_DEVICE, null);
        //设置别名
        if (UserInfoManager.getInstance().isLogin()) {
            String uid = UserInfoManager.getInstance().getUserInfo().getUid();
            MiPushClient.setAlias(context, uid, null);
        }
    }

    /**
     * 其他非主流机型
     * 设置小米推送，主页启动后调用
     *
     * @param context
     */
    private static void setXiaoMiPushOtherPhone(Context context) {
        //设置通用标签
        MiPushClient.subscribe(context, MIUI_PUSH_TAG_ALL_DEVICE_OTHER_PHONE, null);

        //设置别名
        if (UserInfoManager.getInstance().isLogin()) {
            String uid = UserInfoManager.getInstance().getUserInfo().getUid();
            MiPushClient.setAlias(context, uid, null);
        }
    }

    /**
     * 设置华为推送，主页启动后调用
     *
     * @param activity
     */
    private static void setHuaWeiPush(Activity activity) {
        HMSAgent.connect(activity, rst -> {
            LogUtil.d(TAG, "HMS connect end:" + rst);
            HMSAgent.Push.getToken(rtnCode -> LogUtil.d(TAG, "get token: end code=" + rtnCode));
        });
    }

    /**
     * 初始化OPPO推送
     */
    private static void initOppoPush(Context context) {
        if (PushManager.isSupportPush(context)) {
            PushManager.getInstance().register(context, BuildConfig.OPPO_PUSH_APP_KEY, BuildConfig.OPPO_PUSH_APP_SECRET, new PushCallback() {
                @Override
                public void onRegister(int code, String s) {
                    if (code == 0) {
                        LogUtil.d(TAG, "注册成功" + ",code=" + code + ",regId=" + s);
                        GlobalAppInfo.deviceToken = s;
                        setOppoPush();
                    } else {
                        LogUtil.d(TAG, "注册失败" + ",code=" + code + ",msg=" + s);
                    }
                }

                @Override
                public void onUnRegister(int code) {
                    if (code == 0) {
                        GlobalAppInfo.deviceToken = "";
                    } else {
                        LogUtil.d(TAG, "注销失败" + ",code=" + code);
                    }
                }

                @Override
                public void onGetAliases(int code, List<SubscribeResult> list) {
                    if (code == 0) {
                        LogUtil.d(TAG, "获取别名成功" + ",code=" + code + ",msg=" + Arrays.toString(list.toArray()));
                    } else {
                        LogUtil.d(TAG, "获取别名失败" + ",code=" + code);
                    }
                }

                @Override
                public void onSetAliases(int code, List<SubscribeResult> list) {
                    if (code == 0) {
                        LogUtil.d(TAG, "设置别名成功" + ",code=" + code + ",msg=" + Arrays.toString(list.toArray()));
                    } else {
                        LogUtil.d(TAG, "设置别名失败" + ",code=" + code);
                    }
                }

                @Override
                public void onUnsetAliases(int code, List<SubscribeResult> list) {
                    if (code == 0) {
                        LogUtil.d(TAG, "取消别名成功" + ",code=" + code + ",msg=" + Arrays.toString(list.toArray()));
                    } else {
                        LogUtil.d(TAG, "取消别名失败" + ",code=" + code);
                    }
                }

                @Override
                public void onSetUserAccounts(int i, List<SubscribeResult> list) {

                }

                @Override
                public void onUnsetUserAccounts(int i, List<SubscribeResult> list) {

                }

                @Override
                public void onGetUserAccounts(int i, List<SubscribeResult> list) {

                }

                @Override
                public void onSetTags(int code, List<SubscribeResult> list) {
                    if (code == 0) {
                        LogUtil.d(TAG, "设置标签成功" + ",code=" + code + ",msg=" + Arrays.toString(list.toArray()));
                    } else {
                        LogUtil.d(TAG, "设置标签失败" + ",code=" + code);
                    }
                }

                @Override
                public void onUnsetTags(int code, List<SubscribeResult> list) {
                    if (code == 0) {
                        LogUtil.d(TAG, "取消标签成功" + ",code=" + code + ",msg=" + Arrays.toString(list.toArray()));
                    } else {
                        LogUtil.d(TAG, "取消标签失败" + ",code=" + code);
                    }
                }

                @Override
                public void onGetTags(int code, List<SubscribeResult> list) {
                    if (code == 0) {
                        LogUtil.d(TAG, "获取标签成功" + ",code=" + code + ",msg=" + Arrays.toString(list.toArray()));
                    } else {
                        LogUtil.d(TAG, "获取标签失败" + ",code=" + code);
                    }
                }


                @Override
                public void onGetPushStatus(final int code, int status) {
                    if (code == 0 && status == 0) {
                        LogUtil.d(TAG, "Push状态正常" + ",code=" + code + ",status=" + status);
                    } else {
                        LogUtil.d(TAG, "Push状态错误" + ",code=" + code + ",status=" + status);
                    }
                }

                @Override
                public void onGetNotificationStatus(final int code, final int status) {
                    if (code == 0 && status == 0) {
                        LogUtil.d(TAG, "通知状态正常" + ",code=" + code + ",status=" + status);
                    } else {
                        LogUtil.d(TAG, "通知状态错误" + ",code=" + code + ",status=" + status);
                    }
                }

                @Override
                public void onSetPushTime(final int code, final String s) {
                    LogUtil.d(TAG, "SetPushTime" + ", code=" + code + ",result:" + s);
                }

            });
        }
    }

    /**
     * 设置Oppo推送，在initPush中调用
     */
    private static void setOppoPush() {
        //设置通用标签
        List<String> tags = new ArrayList<>();
        tags.add(OPPO_PUSH_TAG_ALL_DEVICE);
        PushManager.getInstance().setTags(tags);

        //设置别名
        if (UserInfoManager.getInstance().isLogin()) {
            String uid = UserInfoManager.getInstance().getUserInfo().getUid();
            List<String> alias = new ArrayList<>();
            alias.add(uid);
            PushManager.getInstance().setAliases(alias);
        }
    }

    /**
     * MEIZU，在广播中调用
     */
    public static void setMeizuPush(Context context, String pushId) {
        //设置通用标签
        com.meizu.cloud.pushsdk.PushManager.subScribeTags(context, BuildConfig.MEIZU_APPID, BuildConfig.MEIZU_APP_KEY, pushId, MEIZU_PUSH_ALL_DEVICE);

        //用账号设置别名
        if (UserInfoManager.getInstance().isLogin()) {
            String uid = UserInfoManager.getInstance().getUserInfo().getUid();
            com.meizu.cloud.pushsdk.PushManager.subScribeAlias(context, BuildConfig.MEIZU_APPID, BuildConfig.MEIZU_APP_KEY, pushId, uid);
        }
    }

    /**
     * VIVO，标签可用，别名推送暂时不支持
     * @param context
     */
    public static void setVivoPush(Context context) {
        PushClient.getInstance(context).turnOnPush(code -> {
            if (code == 0) {
                //设置通用标签
                PushClient.getInstance(context).setTopic(VIVO_PUSH_ALL_DEVICE, state -> {
                    if (state != 0) {
                        LogUtil.d(TAG, "设置标签异常[" + state + "]");
                    } else {
                        LogUtil.d(TAG, "设置标签成功");
                    }
                });

                //用账号设置别名
                if (UserInfoManager.getInstance().isLogin()) {
                    String uid = UserInfoManager.getInstance().getUserInfo().getUid();
                    PushClient.getInstance(context).bindAlias(uid, state -> {
                        if (state != 0) {
                            LogUtil.d(TAG, "设置别名异常[" + state + "]");
                        } else {
                            LogUtil.d(TAG, "设置别名成功");
                        }
                    });
                }
            }
        });
    }

}
