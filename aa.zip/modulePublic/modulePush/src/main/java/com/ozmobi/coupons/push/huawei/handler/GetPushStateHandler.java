package com.ozmobi.coupons.push.huawei.handler;


import com.ozmobi.coupons.push.huawei.common.handler.ICallbackCode;

/**
 * getPushState 回调
 */
public interface GetPushStateHandler extends ICallbackCode {
}
