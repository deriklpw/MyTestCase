package com.ozmobi.coupons.push.huawei.common.handler;

/**
 * 应用自升级回调
 */
public interface CheckUpdateHandler extends ICallbackCode {
}
