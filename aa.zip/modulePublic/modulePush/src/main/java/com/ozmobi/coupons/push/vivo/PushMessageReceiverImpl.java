package com.ozmobi.coupons.push.vivo;

import android.content.Context;
import android.util.Log;

import com.ozmobi.coupons.base.GlobalAppInfo;
import com.ozmobi.coupons.base.utils.PrefUtils;
import com.vivo.push.model.UPSNotificationMessage;
import com.vivo.push.sdk.OpenClientPushMessageReceiver;


public class PushMessageReceiverImpl extends OpenClientPushMessageReceiver {
    /**
     * TAG to LogUtil
     */
    public static final String TAG = PushMessageReceiverImpl.class.getSimpleName();

    @Override
    public void onNotificationMessageClicked(Context context, UPSNotificationMessage msg) {
        String customContentString = msg.getSkipContent();
        String notifyString = "通知点击 msgId " + msg.getMsgId() + " ;customContent=" + customContentString;
        Log.d(TAG, notifyString);
        //不通过此处调起，使用intent uri
    }

    @Override
    public void onReceiveRegId(Context context, String regId) {
        String responseString = "onReceiveRegId regId = " + regId;
        Log.d(TAG, responseString);
        GlobalAppInfo.deviceToken = regId;
        PrefUtils.writeString(PrefUtils.KEY_VIVO_PUSH_TOKEN, regId);
    }
}