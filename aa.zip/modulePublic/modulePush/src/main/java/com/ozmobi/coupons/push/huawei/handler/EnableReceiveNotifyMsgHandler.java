package com.ozmobi.coupons.push.huawei.handler;

import com.ozmobi.coupons.push.huawei.common.handler.ICallbackCode;

/**
 * enableReceiveNotifyMsg 回调
 */
public interface EnableReceiveNotifyMsgHandler extends ICallbackCode {
}
