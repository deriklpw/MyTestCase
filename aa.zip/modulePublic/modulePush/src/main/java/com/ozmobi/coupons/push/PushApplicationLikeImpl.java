package com.ozmobi.coupons.push;

import android.app.Application;

import com.ozmobi.coupons.base.BaseApplicationLike;

public class PushApplicationLikeImpl implements BaseApplicationLike {

    @Override
    public void onCreate(Application application) {
        //初始化推送
        PushInitManager.initPushSdk(application);
    }

    @Override
    public void onLowMemory() {

    }
}
