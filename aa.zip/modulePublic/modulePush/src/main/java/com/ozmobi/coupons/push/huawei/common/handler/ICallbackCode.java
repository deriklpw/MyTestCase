package com.ozmobi.coupons.push.huawei.common.handler;

/**
 * 回调接口
 */
public interface ICallbackCode {
    /**
     * 回调接口
     * @param rst 结果码
     */
    void onResult(int rst);
}
