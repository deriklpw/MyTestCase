package com.ozmobi.coupons.push.huawei.handler;


import com.ozmobi.coupons.push.huawei.common.handler.ICallbackCode;

/**
 * queryAgreement 回调
 */
public interface QueryAgreementHandler extends ICallbackCode {
}
