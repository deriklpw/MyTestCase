package com.ozmobi.coupons.push.huawei.handler;

import com.ozmobi.coupons.push.huawei.common.handler.ICallbackCode;

/**
 * deleteToken 回调
 */
public interface DeleteTokenHandler extends ICallbackCode {
}
