package com.ozmobi.coupons.base;

import android.app.Application;

/**
 * Created by xhkj on 2019/11/6.
 */

public interface BaseApplicationLike {

    void onCreate(Application application);

    void onLowMemory();
}
