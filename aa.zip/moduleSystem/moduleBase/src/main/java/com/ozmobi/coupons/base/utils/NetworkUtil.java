package com.ozmobi.coupons.base.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.ozmobi.coupons.base.BaseApplicationLikeImpl;

/**
 * Created by xhkj on 2019/4/2.
 */

public class NetworkUtil {

    /**
     * 判断网路状态
     * @return true，可用。false，不可用
     */
    public static boolean isNetworkAvailable() {
        Context context = BaseApplicationLikeImpl.context.getApplicationContext();
        ConnectivityManager connectivity = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null) {
            NetworkInfo info = connectivity.getActiveNetworkInfo();
            if (info != null && info.isConnected()) {
                // 当前网络是连接的
                return info.getState() == NetworkInfo.State.CONNECTED;
            }
        }
        return false;
    }

    public static boolean isWiFiConnected() {
        Context context = BaseApplicationLikeImpl.context.getApplicationContext();
        ConnectivityManager connMgr = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connMgr != null) {
            NetworkInfo activeInfo = connMgr.getActiveNetworkInfo();
            if (activeInfo != null && activeInfo.isConnected()) {
                return activeInfo.getType() == ConnectivityManager.TYPE_WIFI;
            }
        }

        return false;
    }
}
