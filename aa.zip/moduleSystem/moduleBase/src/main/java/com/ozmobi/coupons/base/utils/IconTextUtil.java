package com.ozmobi.coupons.base.utils;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.widget.TextView;

/**
 * Created by xhkj on 2019/7/12.
 */

public class IconTextUtil {

    public static void setIconAndTextInTextView(Context context, TextView textView, int resIcon, String text) {
        String logo = "logo ";
        SpannableString spanText = new SpannableString(logo + text);
        Drawable d = context.getResources().getDrawable(resIcon);

        // 左上右下 控制图片大小
        d.setBounds(0, 0, d.getIntrinsicWidth() - PXTool.dip2px(3), d.getIntrinsicHeight() - PXTool.dip2px(1));

        // 替换0,4的字符
        spanText.setSpan(new ImageSpan(d, ImageSpan.ALIGN_BOTTOM), 0, logo.length() - 1, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        textView.setText(spanText);

    }
}
