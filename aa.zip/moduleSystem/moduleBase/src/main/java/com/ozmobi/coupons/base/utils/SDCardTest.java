package com.ozmobi.coupons.base.utils;

import android.os.Environment;

public class SDCardTest {

    /**
     * 判断SD是否可读写
     *
     * @return int, 1可用，0不可用
     */
    public static int sdcardState() {
        // TODO Auto-generated method stub
        int state = 0;
        switch (Environment.getExternalStorageState()) {
            case Environment.MEDIA_MOUNTED:
                state = 1;
                break;
            case Environment.MEDIA_MOUNTED_READ_ONLY:
                state = 0;
                break;
            case Environment.MEDIA_NOFS:
                state = 0;
                break;
            case Environment.MEDIA_SHARED:
                state = 0;
                break;
            case Environment.MEDIA_CHECKING:
                state = 0;
                break;
            case Environment.MEDIA_BAD_REMOVAL:
                state = 0;
                break;
            case Environment.MEDIA_UNMOUNTABLE:
                state = 0;
                break;
            case Environment.MEDIA_UNMOUNTED:
                state = 0;
                break;
            case Environment.MEDIA_REMOVED:
                state = 0;
                break;
        }
        return state;
    }
}
