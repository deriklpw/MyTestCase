package com.ozmobi.coupons.base.utils;

import com.ozmobi.coupons.base.Constants;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xhkj on 2019/7/31.
 */

public class SortUtil {

    /**
     * 用于分享商品和社区中，对生成的临时图片排序
     *
     * @param list
     * @return
     */
    public static ArrayList<String> sortImagePath(ArrayList<String> list) {
        if (list == null || list.size() == 0) {
            return null;
        }
        for (int i = 0; i < list.size() - 1; i++) {
            int flag = 0;
            for (int j = 0; j < list.size() - i - 1; j++) {
                String numStr1 = list.get(j).substring(list.get(j).indexOf(Constants.SHARE_FILE_NAME_SPILT) + Constants.SHARE_FILE_NAME_SPILT.length(), list.get(j).indexOf(".jpg"));
                String numStr2 = list.get(j + 1).substring(list.get(j + 1).indexOf(Constants.SHARE_FILE_NAME_SPILT) + Constants.SHARE_FILE_NAME_SPILT.length(), list.get(j + 1).indexOf(".jpg"));
                int num1 = Integer.valueOf(numStr1);
                int num2 = Integer.valueOf(numStr2);

                if (num1 > num2) {
                    swap(list, j, j + 1);
                    flag = 1;
                }
            }

            if (flag == 0) {
                break;
            }
        }
        return list;
    }

    public static void swap(List<?> list, int i, int j) {
        final List l = list;
        l.set(i, l.set(j, l.get(i)));
    }

    /**
     * 外循环优化：添加flag，标记是否发生交换
     * 从小到大排序
     *
     * @param datas
     * @return
     */
    public static int[] maoPaoSortExt(int[] datas) {
        for (int i = 0; i < datas.length - 1; i++) {
            int flag = 0;
            for (int j = 0; j < datas.length - i - 1; j++) {
                if (datas[j] > datas[j + 1]) {
                    int temp;
                    temp = datas[j];
                    datas[j] = datas[j + 1];
                    datas[j + 1] = temp;
                    flag = 1;
                }
            }

            if (flag == 0) {
                break;
            }
        }
        return datas;
    }

}
