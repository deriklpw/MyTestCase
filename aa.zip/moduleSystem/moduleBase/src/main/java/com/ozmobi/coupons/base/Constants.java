package com.ozmobi.coupons.base;

import android.os.Environment;

/**
 * Created by xhkj on 2019/4/3.
 */

public interface Constants {

    /**
     * 点击事件最小时间间隔
     */
    int CLICK_EVENT_TIME = 800; //ms

    /**
     * 加载的默认商品数，用于首次加载数据
     */
    int PAGE_SIZE_LOAD_DEFAULT = 10;

    /**
     * 分页加载，单页商品数
     */
    int PAGE_SIZE_LOAD_MORE = PAGE_SIZE_LOAD_DEFAULT;  //不一致时，请求的数据统计不正确

    /**
     * 应用退出时间间隔
     */
    int EXIT_INTERVAL_TIME = 2200; //ms

    /**
     * 搜索历史存储最大值
     */
    int SEARCH_HISTORY_SAVE_MAX = 10;

    /**
     * 验证码发送倒计时时间
     */
    int MSG_CODE_TIME_DELAY = 120; //s

    /**
     * 智能搜索，最小检索长度
     */
    int CLIP_DATA_LENGTH_MIN = 14;

    /**
     * 缓存图片名称分隔符
     */
    String SHARE_FILE_NAME_SPILT = "__"; // 末尾"__"两个字符，用于截取后面数字使用，须唯一

    /**
     * 生成商品的本地临时图片名称，后接数字，防止生成过多临时文件
     */
    String SHARE_FILE_NAME_PREFIX = "image_temp" + SHARE_FILE_NAME_SPILT; // 末尾"__"两个字符，用于截取后面数字使用，需唯一

    /**
     * sd卡，存储根目录
     */
    String APP_NAME = "qdj";

    /**
     * sd卡，缓存目录
     */
    String DIRS_CACHE = "cache";

    /**
     * sd卡，图片存储目录
     */
    String DIRS_PICTURES = "pictures";

    /**
     * sd卡，视频存储目录
     */
    String DIRS_VIDEOS = "videos";

    /**
     * sd卡，缓存目录，可清理，分享功能使用
     */
    String EXTERNAL_DIR_CACHE = Environment.getExternalStorageDirectory() + "/" + APP_NAME + "/" + DIRS_CACHE;

    /**
     * sd卡，图片存储目录，同步至相册使用，不清理，不覆盖
     */
    String EXTERNAL_DIR_PICTURES = Environment.getExternalStorageDirectory() + "/" + APP_NAME + "/" + DIRS_PICTURES;

    /**
     * sd卡，视频存储目录，同步至相册使用，不清理，不覆盖
     */
    String EXTERNAL_DIR_VIDEOS = Environment.getExternalStorageDirectory() + "/" + APP_NAME + "/" + DIRS_VIDEOS;

    String DEBUG_FILE_NAME = "debug";
}
