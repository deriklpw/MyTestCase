package com.ozmobi.coupons.base.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.alibaba.fastjson.JSON;


/**
 * This class helps to store class object in the shared preferences
 */

public class ComplexPreferences {

    private SharedPreferences preferences;

    private ComplexPreferences(Context context, String namePreferences, int mode) {
//        this.context = context;
        if (namePreferences == null || "".equals(namePreferences)) {
            namePreferences = "complex_preferences";
        }
        preferences = context.getSharedPreferences(namePreferences, mode);
    }

    public static ComplexPreferences getComplexPreferences(Context context,
                                                           String namePreferences, int mode) {
        return new ComplexPreferences(context.getApplicationContext(), namePreferences, mode);
    }

    public void putObject(String key, Object object) {
        if (object == null) {
            throw new IllegalArgumentException("object is null");
        }

        if ("".equals(key)) {
            throw new IllegalArgumentException("key is empty or null");
        }

        preferences.edit().putString(key, JSON.toJSONString(object)).apply();
    }


    public void clearObject() {
        preferences.edit().clear().apply();
    }

    public <T> T getObject(String key, Class<T> a) {

        String gson = preferences.getString(key, null);
        if (gson == null) {
            return null;
        } else {
            try {
                return JSON.parseObject(gson, a);
            } catch (Exception e) {
                throw new IllegalArgumentException("Object storaged with key " + key + " is instanceof other class");
            }
        }
    }

}
