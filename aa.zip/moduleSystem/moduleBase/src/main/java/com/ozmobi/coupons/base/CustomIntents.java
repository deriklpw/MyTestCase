package com.ozmobi.coupons.base;

/**
 * Created by xhkj on 2019/11/14.
 */

public interface CustomIntents {
    String INTENT_ACTION_START_MAIN_SUFFIX = "_intent_action_MAIN";
    String INTENT_ACTION_START_LOGIN_SUFFIX = "_intent_action_LOGIN";
    String INTENT_ACTION_START_HOME_CONTAINER_SUFFIX = "_intent_action_HOME_CONTAINER";
    String INTENT_ACTION_START_MSG = "_intent_action_MSG";
    String INTENT_ACTION_START_FANS_MSG = "_intent_action_FANS_MSG";
    String INTENT_ACTION_START_INCOME_MSG = "_intent_action_INCOME_MSG";
    String INTENT_ACTION_START_INVITATION_REGISTER = "_intent_action_INVITATION_REGISTER";
}