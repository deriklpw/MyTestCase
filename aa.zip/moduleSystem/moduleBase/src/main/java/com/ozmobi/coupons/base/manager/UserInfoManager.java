package com.ozmobi.coupons.base.manager;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ozmobi.coupons.base.bean.UserInfo;
import com.ozmobi.coupons.base.utils.DesUtil;
import com.ozmobi.coupons.base.utils.LogUtil;
import com.ozmobi.coupons.base.utils.PrefUtils;

/**
 * Created by xhkj on 2019/6/10.
 */

/**
 * 单实例管理UserInfo，避免每次从存储中读取
 */
public class UserInfoManager {

    private static final String TAG = "UserInfoManager";

    private static volatile UserInfoManager instance;

    private UserInfo userInfo;

    /**
     * 初始化时，从文件中获取UserInfo信息
     */
    private UserInfoManager() {
        try {
            String infoEncode = PrefUtils.readString(PrefUtils.KEY_USER_INFO);
            if (!TextUtils.isEmpty(infoEncode)) {
                String infoStr = DesUtil.decode(infoEncode);
                LogUtil.d(TAG, "getUserInfo: " + infoStr);
                if (!TextUtils.isEmpty(infoStr)) {
                    userInfo = parseUserInfo(infoStr);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static UserInfoManager getInstance() {
        if (instance == null) {
            synchronized (UserInfoManager.class) {
                if (instance == null) {
                    instance = new UserInfoManager();
                }
            }
        }
        return instance;
    }

    public boolean isLogin() {
        return userInfo != null;
    }

    /**
     * 获取UserInfo对象
     *
     * @return
     */
    public UserInfo getUserInfo() {
        return userInfo;
    }

    /**
     * 保存UserInfo的Json，部分接口变更UserInfo时，需要同步保存
     * 保存到全局和文件中
     *
     * @param json
     */
    public synchronized void saveUserInfo(String json) {
        LogUtil.d(TAG, "saveUserInfo: " + json);
        if (TextUtils.isEmpty(json)) {
            return;
        }

        UserInfo tempUser = parseUserInfo(json);
        //解析无异常，保存
        if (tempUser != null) {
            //保存到全局
            userInfo = tempUser;
            //保存到文件
            String infoEncode = DesUtil.encode(json);
            PrefUtils.writeString(PrefUtils.KEY_USER_INFO, infoEncode);
        }
    }

    /**
     * 解析UserInfo的json
     *
     * @param json
     * @return
     */
    public UserInfo parseUserInfo(String json) {
        UserInfo userInfo;
        try {
            JSONObject userInfoObj = JSON.parseObject(json);
            userInfo = new UserInfo();
            userInfo.setUid(userInfoObj.getString("uid"));
            userInfo.setSid(userInfoObj.getString("sid"));
            userInfo.setSite_id(userInfoObj.getString("site_id"));
            userInfo.setInvite(userInfoObj.getString("invite"));
            userInfo.setNick(userInfoObj.getString("nick"));
            userInfo.setIcon(userInfoObj.getString("icon"));
            userInfo.setGender(userInfoObj.getString("gender"));
            userInfo.setMobile(userInfoObj.getString("mobile"));
            userInfo.setLevel(userInfoObj.getString("level"));
            userInfo.setFans(userInfoObj.getString("fans"));
            userInfo.setMoney(userInfoObj.getString("money"));
            userInfo.setEarn_money(userInfoObj.getString("earn_money"));
            userInfo.setAlipay(userInfoObj.getString("alipay"));
            userInfo.setAlipay_name(userInfoObj.getString("alipay_name"));
            userInfo.setActivetime(userInfoObj.getString("activetime"));
            userInfo.setAddtime(userInfoObj.getString("addtime"));
            userInfo.setLevel_desc(userInfoObj.getString("level_desc"));

            //新加参数
            userInfo.setOpenId(userInfoObj.getString("openId"));
            userInfo.setRelation_id(userInfoObj.getString("relation_id"));
            userInfo.setSpecial_id(userInfoObj.getString("special_id"));
            userInfo.setTaobao_open_uid(userInfoObj.getString("taobao_open_uid"));
            userInfo.setParent_invite(userInfoObj.getString("parent_invite"));
            userInfo.setIntegral(userInfoObj.getString("integral"));
            userInfo.setLevel_icon(userInfoObj.getString("level_icon"));

        } catch (Exception e) {
            e.printStackTrace();
            //异常，将userinfo返回空
            userInfo = null;
        }

        return userInfo;
    }

    /**
     * 清空UerInfo
     */
    public void clearUserInfo() {
        userInfo = null;
        PrefUtils.remove(PrefUtils.KEY_USER_INFO);
    }

    /**
     * 销毁
     */
    public void destroy() {
        userInfo = null;
        instance = null;
    }

}
