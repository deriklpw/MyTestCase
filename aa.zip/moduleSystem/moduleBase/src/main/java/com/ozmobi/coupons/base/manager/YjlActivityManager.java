package com.ozmobi.coupons.base.manager;

import android.app.Activity;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class YjlActivityManager {

    private static YjlActivityManager INSTANCE;

    private Map<String, String> mWeChatInfo;

    private List<Activity> mList;


    private YjlActivityManager() {
        mWeChatInfo = new HashMap<>();
        mList = new LinkedList<>();
    }

    public static YjlActivityManager getInstance() {
        if (INSTANCE == null) {
            synchronized (YjlActivityManager.class) {
                if (INSTANCE == null) {
                    INSTANCE = new YjlActivityManager();
                }
            }
        }
        return INSTANCE;
    }

    /**
     * 微信注册时使用
     *
     * @return
     */
    public Map<String, String> getWeChatInfo() {
        return mWeChatInfo;
    }

    public void setWeChatInfo(Map<String, String> wechatInfo) {
        this.mWeChatInfo.clear();
        this.mWeChatInfo.putAll(wechatInfo);
    }

    /**
     * 登录注册流程中保存Activity数组
     *
     * @return
     */
    public List<Activity> getActivities() {
        return mList;
    }

    // add Activity
    public void addActivity(Activity activity) {
        mList.add(activity);
    }

    //关闭list内的activity
    public void clearActivities() {
        try {
            for (Activity activity : mList) {
                if (activity != null) {
                    activity.finish();
                }
            }
            mList.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
