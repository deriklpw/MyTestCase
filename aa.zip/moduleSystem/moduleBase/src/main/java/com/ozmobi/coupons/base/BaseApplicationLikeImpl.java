package com.ozmobi.coupons.base;

import android.app.Application;
import android.content.Context;

public class BaseApplicationLikeImpl implements BaseApplicationLike {

    public static Context context;

    @Override
    public void onCreate(Application application) {
        this.context = application.getApplicationContext();
    }

    @Override
    public void onLowMemory() {

    }
}
