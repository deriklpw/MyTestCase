package com.ozmobi.coupons.base.utils;

import java.util.regex.Pattern;

/**
 * Created by xhkj on 2019/5/24.
 */

public class RegularUtil {

//    private static final String REGEX_PASSWORD = "^[a-zA-Z0-9]{6,16}$";

//    private static final String REGEX_MOBILE = "^((13[0-9])|(15[^4])|(18[0-9])|(17[0-8])|(147,145))\\d{8}$";

    private static final String REGEX_PASSWORD = "^.{6,23}$";
    private static final String REGEX_MOBILE = "^1[0-9]{10}";

    public static boolean isMobile(String text) {
        return Pattern.matches(REGEX_MOBILE, text);
    }

    public static boolean isPassword(String password) {
        return Pattern.matches(REGEX_PASSWORD, password);
    }

    public static String formatMobile(String mobile) {
        return mobile.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
    }
}
