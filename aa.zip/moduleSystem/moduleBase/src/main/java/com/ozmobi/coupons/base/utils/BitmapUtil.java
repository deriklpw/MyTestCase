package com.ozmobi.coupons.base.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.media.ThumbnailUtils;
import android.view.View;

import com.ozmobi.coupons.base.Constants;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by xhkj on 2019/6/19.
 */

public class BitmapUtil {

    public static Bitmap convertViewToBitmap(View view, int bitmapWidth, int bitmapHeight){
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.RGB_565);
        view.draw(new Canvas(bitmap));
        return bitmap;
    }

    public static Bitmap getBitmap(View rootLayout) {
        // 获取某布局图片
        rootLayout.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        rootLayout.layout(0, 0, rootLayout.getMeasuredWidth(), rootLayout.getMeasuredHeight());
        rootLayout.setDrawingCacheEnabled(true);
        rootLayout.buildDrawingCache();
        return rootLayout.getDrawingCache();
    }

    public static String saveBitmapInternalCache(Context context, Bitmap bitmap, String fileName) {
        File dir = new File(context.getCacheDir(), Constants.DIRS_PICTURES);
        return saveBitmap(bitmap, dir, fileName);
    }

    public static String saveBitmapExternalCache(Context context, Bitmap bitmap, String fileName) {
        File dir = new File(Constants.EXTERNAL_DIR_CACHE);
        return saveBitmap(bitmap, dir, fileName);
    }

    private static String saveBitmap(Bitmap bitmap, File dir, String fileName) {
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File myCaptureFile = new File(dir, fileName + ".jpg");
        BufferedOutputStream bos = null;
        try {
            if (myCaptureFile.exists()) {
                myCaptureFile.delete();
            }

            if (myCaptureFile.createNewFile()) {
                bos = new BufferedOutputStream(new FileOutputStream(myCaptureFile));
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, bos);
                bos.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (bos != null) {
                try {
                    bos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return myCaptureFile.getAbsolutePath();
    }

    public static Bitmap bitmapCrop(Bitmap bitmap, int x, int y, int width, int height) {
        try {
            if (bitmap != null) {
                return Bitmap.createBitmap(bitmap, x, y, width, height, null, false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static Bitmap extractThumbnail(Bitmap source, int width, int height) {
        // 指定较小，则缩小；较大则放大。其实质结合了BitmapFactory和Matrix
        return ThumbnailUtils.extractThumbnail(source, width, height);
    }

    /**
     * 使Bitmap缩小为原来的inSampleSize分之一，降低使用内存
     *
     * @param context   上下文
     * @param is        图片的数据流
     * @param config 对应的配置
     * @param reqWidth  设定的宽度
     * @param reqHeight 设定的高度
     * @return Bitmap 返回一个bitmap实例
     */
    public static Bitmap inSampleSize(Context context, InputStream is, Bitmap.Config config, int reqWidth, int reqHeight) {
        Bitmap bmp = null;
        BitmapFactory.Options options = new BitmapFactory.Options();

        options.inJustDecodeBounds = false; // 默认false

        if (config != null) {
            options.inPreferredConfig = Bitmap.Config.RGB_565; //降低像素使用内存
            options.inPurgeable = true; //允许系统在必要时清除，避免在UI响应要求快的地方使用
            options.inInputShareable = true; //允许保存输入数据的引用，以重建bitmap
        }

        if (reqHeight != 0 && reqWidth != 0) {
            options.inSampleSize = calculateInSampleSize(is, reqWidth, reqHeight);
        }

        try {
            //解析并分配内存给bitmap对象
            bmp = BitmapFactory.decodeStream(is, null, options);
        } catch (OutOfMemoryError error) {
            error.printStackTrace();
        }

        return bmp;
    }

    /**
     * 图片缩小技术处理之一：先依据组件宽高，计算出缩小比例
     *
     * @param is        图片的数据流
     * @param reqWidth  指定宽度
     * @param reqHeight 指定高度
     * @return int 缩小的比例
     */
    public static int calculateInSampleSize(InputStream is, int reqWidth, int reqHeight) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        // 将这个参数的inJustDecodeBounds属性设置为true就可以让解析方法禁止为bitmap分配内存，
        // 返回值也不再是一个Bitmap对象，而是null。虽然Bitmap是null了，但是
        // BitmapFactory.Options类对象的outWidth、outHeight和outMimeType属性都会被赋值
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(is, null, options);
        int imageWidth = options.outWidth;
        int imageHeight = options.outHeight;

        int inSampleSize = 1;
        if (imageHeight > reqHeight || imageWidth > reqWidth) {
            // 计算出实际宽高和目标宽高的比率
            final int heightRatio = Math.round((float) imageHeight / (float) reqHeight);
            final int widthRatio = Math.round((float) imageWidth / (float) reqWidth);
            // 选择宽和高中最小的比率作为inSampleSize的值，这样可以保证最终图片的宽和高
            // 一定都会大于等于目标的宽和高。
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        return inSampleSize;
    }
}
