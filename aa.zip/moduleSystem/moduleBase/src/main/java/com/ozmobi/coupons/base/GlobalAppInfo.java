package com.ozmobi.coupons.base;

/**
 * Created by xhkj on 2019/11/13.
 */

public class GlobalAppInfo {
    //是否时测试环境
    public static boolean isDebug = false;
    //应用市场渠道号
    public static String channel = "yjl"; //默认"yjl"，测试渠道号
    //状态栏高度
    public static int statusHeight = 0;
    //推送token
    public static String deviceToken;
    //是否正显示弹窗
    public static boolean isDialogShowing = false;
    //后台自定义渠道号
    public static String yjlApi = "101"; //默认使用101（券当家Android）
}
