package com.ozmobi.coupons.base.listener;

/**
 * Created by xhkj on 2019/4/11.
 */

public interface OnActivityCallback {
    void onFinishActivity();
}
