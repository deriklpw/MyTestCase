package com.ozmobi.coupons.base.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.ozmobi.coupons.base.BaseApplicationLikeImpl;

public class PrefUtils {

    // SP文件名 search_history
    public  static final String SEARCH_HISTORY = "search_history";

    // SP文件名 search_hot_words
    public static final String SEARCH_HOT_WORDS = "search_hot_words";

    // SP文件名 user_config
    public static final String USER_CONFIG = "user_config";

    // 存于user_config中，一级商品分类
    public static final String KEY_GOODS_CATEGORY = "key_goods_category";

    // 存于user_config中，推送设置
    public static final String KEY_USER_CONFIG_PUSH = "key_user_config_push"; //value, bool

    // 存于user_config中，性别设置
    public static final String KEY_USER_CONFIG_GENDER = "key_user_config_gender"; //value, 女0, 男1, 2未知

    // 存于user_config中，设备信息
    public static final String KEY_USER_CONFIG_DEVICE_INFO = "key_user_config_device_info"; //value, json串

    public static final String KEY_IS_FIRST_START = "key_is_first_start";

    // 存于user_config中，用户偏好标签
    public static final String KEY_USER_FAVORITES = "key_user_favorites";

    // 存于user_config中，用户信息
    public static final String KEY_USER_INFO = "key_u_info";

    // 存于user_config中，首次显示欢迎对话框
    public static final String KEY_IS_FIRST_SHOW_WELCOME_DIALOG = "key_is_first_show_welcome_dialog";

    // 存于user_config中，vivo机型推送，安装后首次初始化拿到token，并保存
    public static final String KEY_VIVO_PUSH_TOKEN = "key_vivo_push_token";

    public static void setCurrentObject(Context ctx, String spName, Object object) {
        ComplexPreferences complexPreferences = ComplexPreferences.getComplexPreferences(ctx.getApplicationContext(), spName, 0);
        complexPreferences.putObject(spName, object);
    }

    public static <T> T getCurrentObject(Context ctx, String spName, Class<T> a) {
        ComplexPreferences complexPreferences = ComplexPreferences.getComplexPreferences(ctx.getApplicationContext(), spName, 0);
        return complexPreferences.getObject(spName, a);
    }

    public static void clearCurrentObject(Context ctx, String spName) {
        ComplexPreferences complexPreferences = ComplexPreferences.getComplexPreferences(ctx.getApplicationContext(), spName, 0);
        complexPreferences.clearObject();
    }


    public static String readString(String key) {
        return getSharedPreferences().getString(key, "");
    }

    public static void writeString(String key, String value) {
        getSharedPreferences().edit().putString(key, value).apply();
    }

    public static boolean readBoolean(String key) {
        return getSharedPreferences().getBoolean(key, false);
    }

    public static boolean readBoolean(String key, boolean defValue) {
        return getSharedPreferences().getBoolean(key, defValue);
    }

    public static void writeBoolean(String key, boolean value) {
        getSharedPreferences().edit().putBoolean(key, value).apply();
    }

    public static int readInt(String key) {
        return getSharedPreferences().getInt(key, 0);
    }

    public static int readInt(String key, int defValue) {
        return getSharedPreferences().getInt(key, defValue);
    }

    public static void writeInt(String key, int value) {
        getSharedPreferences().edit().putInt(key, value).apply();
    }

    public static long readLong(String key) {
        return getSharedPreferences().getLong(key, 0);
    }

    public static void writeLong(String key, long value) {
        getSharedPreferences().edit().putLong(key, value).apply();
    }

    public static void remove(String key) {
        getSharedPreferences().edit().remove(key).apply();
    }

    public static void removeAll() {
        getSharedPreferences().edit().clear().apply();
    }

    public static SharedPreferences getSharedPreferences() {

        return BaseApplicationLikeImpl.context
                .getSharedPreferences(USER_CONFIG, Context.MODE_PRIVATE);
    }

}
