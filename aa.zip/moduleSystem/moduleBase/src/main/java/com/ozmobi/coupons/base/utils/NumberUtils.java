package com.ozmobi.coupons.base.utils;

import android.text.TextUtils;

import java.text.DecimalFormat;

/**
 * Created by xhkj on 2019/7/1.
 */

public class NumberUtils {
    private static DecimalFormat decimalFormat = new DecimalFormat();

    //no zero at the end of float
    public static String format(int num) {
        decimalFormat.applyPattern("0.##");
        return decimalFormat.format(num);
    }

    public static String format(float num) {
        decimalFormat.applyPattern("0.##");
        return decimalFormat.format(num);
    }

    public static String format(double num) {
        decimalFormat.applyPattern("0.##");
        return decimalFormat.format(num);
    }

    public static String formatWithTwoFloat(int num) {
        decimalFormat.applyPattern("0.00");
        return decimalFormat.format(num);
    }

    public static String formatWithTwoFloat(float num) {
        decimalFormat.applyPattern("0.00");
        return decimalFormat.format(num);
    }

    public static String formatWithTwoFloat(double num) {
        decimalFormat.applyPattern("0.00");
        return decimalFormat.format(num);
    }

    public static boolean isNumString(String str) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        for (int i = str.length(); --i >= 0; ) {

            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }

        return true;

    }

}
