package com.ozmobi.coupons.base.bean;

public class UserInfo {
    private String alipay;
    private String gender;
    private String level;
    private String special_id;
    private String openId;
    private String icon;
    private String mobile;
    private String sid;
    private String fans;
    private String relation_id;
    private String nick;
    private String taobao_open_uid;
    private String uid;
    private String activetime;
    private String earn_money;
    private String money;
    private String addtime;
    private String site_id;
    private String invite;
    private String parent_invite;
    private String level_desc;
    private String alipay_name;
    private String integral;
    private String level_icon;

    public void setAlipay(String alipay) {
        this.alipay = alipay;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public void setSpecial_id(String special_id) {
        this.special_id = special_id;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public void setFans(String fans) {
        this.fans = fans;
    }

    public void setRelation_id(String relation_id) {
        this.relation_id = relation_id;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public void setTaobao_open_uid(String taobao_open_uid) {
        this.taobao_open_uid = taobao_open_uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setActivetime(String activetime) {
        this.activetime = activetime;
    }

    public void setEarn_money(String earn_money) {
        this.earn_money = earn_money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }

    public void setSite_id(String site_id) {
        this.site_id = site_id;
    }

    public void setInvite(String invite) {
        this.invite = invite;
    }

    public void setParent_invite(String parent_invite) {
        this.parent_invite = parent_invite;
    }

    public void setLevel_desc(String level_desc) {
        this.level_desc = level_desc;
    }

    public void setAlipay_name(String alipay_name) {
        this.alipay_name = alipay_name;
    }

    public String getAlipay() {
        return alipay;
    }

    public String getGender() {
        return gender;
    }

    public String getLevel() {
        return level;
    }

    public String getSpecial_id() {
        return special_id;
    }

    public String getOpenId() {
        return openId;
    }

    public String getIcon() {
        return icon;
    }

    public String getMobile() {
        return mobile;
    }

    public String getSid() {
        return sid;
    }

    public String getFans() {
        return fans;
    }

    public String getRelation_id() {
        return relation_id;
    }

    public String getNick() {
        return nick;
    }

    public String getTaobao_open_uid() {
        return taobao_open_uid;
    }

    public String getUid() {
        return uid;
    }

    public String getActivetime() {
        return activetime;
    }

    public String getEarn_money() {
        return earn_money;
    }

    public String getMoney() {
        return money;
    }

    public String getAddtime() {
        return addtime;
    }

    public String getSite_id() {
        return site_id;
    }

    public String getInvite() {
        return invite;
    }

    public String getParent_invite() {
        return parent_invite;
    }

    public String getLevel_desc() {
        return level_desc;
    }

    public String getAlipay_name() {
        return alipay_name;
    }

    public String getIntegral() {
        return integral;
    }

    public void setIntegral(String integral) {
        this.integral = integral;
    }

    public String getLevel_icon() {
        return level_icon;
    }

    public void setLevel_icon(String level_icon) {
        this.level_icon = level_icon;
    }
}
