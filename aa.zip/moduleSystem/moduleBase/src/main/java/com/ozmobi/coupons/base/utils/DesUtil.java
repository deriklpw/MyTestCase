package com.ozmobi.coupons.base.utils;

import android.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class DesUtil {

    private static final String secretKey = "iwn#@!$%";
    private static final String KEY = "DES";
    private static final byte[] iv = {'a', 'b', 'c', 'd', 'e', 'g', '@', '*'};

    public static String encode(String content) {
        try {
            IvParameterSpec zeroIv = new IvParameterSpec(iv);
            SecretKeySpec key = new SecretKeySpec(secretKey.getBytes(), KEY);
            Cipher cipher = Cipher.getInstance(KEY);
            cipher.init(Cipher.ENCRYPT_MODE, key, zeroIv);
            byte[] encryptedData = cipher.doFinal(content.getBytes());
            return Base64.encodeToString(encryptedData, 1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String decode(String encryptText) {
        String rest = "";
        try {
            IvParameterSpec zeroIv = new IvParameterSpec(iv);
            SecretKeySpec key = new SecretKeySpec(secretKey.getBytes(), KEY);
            Cipher cipher = Cipher.getInstance(KEY);
            cipher.init(Cipher.DECRYPT_MODE, key, zeroIv);
            byte[] decryptData = cipher.doFinal(Base64.decode(encryptText, 1));
            rest = new String(decryptData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rest;
    }

}
