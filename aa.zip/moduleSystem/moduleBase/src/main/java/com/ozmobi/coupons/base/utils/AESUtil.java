package com.ozmobi.coupons.base.utils;

import android.util.Base64;

import java.io.UnsupportedEncodingException;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AESUtil {

	// private static final String CipherMode =
	private static final String CipherMode = "AES/CFB/NoPadding";

	private static SecretKeySpec createKey(String password) {
		byte[] data = null;
		if (password == null) {
			password = "";
		}
		StringBuilder sb = new StringBuilder(32);
		sb.append(password);
		while (sb.length() < 32) {
			sb.append("0");
		}
		if (sb.length() > 32) {
			sb.setLength(32);
		}

		try {
			data = sb.toString().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
		}
		return new SecretKeySpec(data, "AES");
	}

	private static byte[] encrypt(byte[] content, String password) {
		try {
			SecretKeySpec key = createKey(password);
			System.out.println(key);
			Cipher cipher = Cipher.getInstance(CipherMode);
			cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(
					new byte[cipher.getBlockSize()]));
			return cipher.doFinal(content);
		} catch (Exception e) {
//			e.printStackTrace();
		}
		return null;
	}

	public static String encrypt(String password, String content) {

		byte[] data = null;
		try {
			data = content.getBytes("UTF-8");
		} catch (Exception e) {
//			e.printStackTrace();
		}
		data = encrypt(data, password);
		String result = byte2hex(data);

		return result;
	}

	private static byte[] decrypt(byte[] content, String password) {

		try {
			SecretKeySpec key = createKey(password);
			Cipher cipher = Cipher.getInstance(CipherMode);
			cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(
					new byte[cipher.getBlockSize()]));

			return cipher.doFinal(content);
		} catch (Exception e) {
//			e.printStackTrace();
		}
		return null;
	}

	public static String decrypt(String password, String content) {

		byte[] data = null;
		try {
			data = hex2byte(content);
		} catch (Exception e) {
//			e.printStackTrace();
		}
		data = decrypt(data, password);
		if (data == null)
			return null;
		String result = null;
		try {
			result = new String(data, "UTF-8");
		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
		}
		return result;
	}

	private static String byte2hex(byte[] b) {
		StringBuilder sb = new StringBuilder(b.length * 2);
		String tmp = "";
		for (byte aB : b) {

			tmp = (Integer.toHexString(aB & 0XFF));
			if (tmp.length() == 1) {
				sb.append("0");
			}
			sb.append(tmp);
		}
		return sb.toString().toUpperCase();
	}


	private static byte[] hex2byte(String inputString) {
		if (inputString == null || inputString.length() < 2) {
			return new byte[0];
		}
		inputString = inputString.toLowerCase();
		int l = inputString.length() / 2;
		byte[] result = new byte[l];
		for (int i = 0; i < l; ++i) {
			String tmp = inputString.substring(2 * i, 2 * i + 2);
			result[i] = (byte) (Integer.parseInt(tmp, 16) & 0xFF);
		}
		return result;
	}

	public static String decodeString(String str) {
		byte[] arrayOfByte = Base64.decode(str, 0);
		char[] arrayOfChar = new char[arrayOfByte.length];
		arrayOfChar = new char[arrayOfByte.length];
		for (int n = 0; n < arrayOfChar.length; n++) {
			arrayOfChar[n] = ((char) (arrayOfByte[n] ^ (byte) 0x27));
		}
		String strMethodName = new String(arrayOfChar);
		return strMethodName;
	}

}
