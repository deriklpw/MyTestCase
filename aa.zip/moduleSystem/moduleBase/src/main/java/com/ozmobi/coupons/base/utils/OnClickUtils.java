package com.ozmobi.coupons.base.utils;

import com.ozmobi.coupons.base.Constants;

/**
 * Created by xhkj on 2019/3/30.
 */

/**
 * 此方法在页面切换中，会保留上一页的点击时间，不适合所有场景
 */
public class OnClickUtils {

    private static long lastClickTime;

    public static boolean isFastClick() {
        boolean flag = true;
        long currentClickTime = System.currentTimeMillis();
        if ((currentClickTime - lastClickTime) >= Constants.CLICK_EVENT_TIME) {
            flag = false;
        }
        lastClickTime = currentClickTime;
        return flag;
    }
}
