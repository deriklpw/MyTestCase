package com.ozmobi.coupons.base.listener;

import android.view.View;

import com.ozmobi.coupons.base.Constants;

public abstract class OnSingleClickListener implements View.OnClickListener {

    private long lastClickTime = 0;

    @Override
    public void onClick(View v) {
        Long currentClickTime = System.currentTimeMillis();

        if ((currentClickTime - lastClickTime) >= Constants.CLICK_EVENT_TIME) {
            onSingleClick(v);
        }

        lastClickTime = currentClickTime;
    }

    public abstract void onSingleClick(View v);
}
