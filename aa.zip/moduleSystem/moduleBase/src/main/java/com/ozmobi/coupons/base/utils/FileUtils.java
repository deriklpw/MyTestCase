package com.ozmobi.coupons.base.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

public class FileUtils {

    public static File createDir(String path) {
        File dir = new File(path);
        if (!dir.exists()) {
            if (dir.mkdirs()) {
                return dir;
            }
        } else {
            return dir;
        }

        return null;
    }

    public static File createFile(String path, String name) throws IOException {
        File dir = createDir(path);
        File file;
        if (dir != null) {
            file = new File(dir, name);
            if (file.exists()) {
                if (file.delete() && file.createNewFile()) {
                    return file;
                }
            } else {
                if (file.createNewFile()) {
                    return file;
                }
            }

        }
        return null;
    }

    public static void copyFileUsingFileChannels(File source, File dest) {
        try (FileChannel inputChannel = new FileInputStream(source).getChannel(); FileChannel outputChannel = new FileOutputStream(dest).getChannel()) {
            outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
