package com.ozmobi.coupons.base.utils;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import java.util.HashMap;
import java.util.Map;

public class MarketUtil {

    public static final String PHONE_TYPE_XIAOMI = "xiaomi";
    public static final String PHONE_TYPE_HUAWEI = "huawei";
    public static final String PHONE_TYPE_HONOR = "honor";
    public static final String PHONE_TYPE_OPPO = "oppo";
    public static final String PHONE_TYPE_MEIZU = "meizu";
    public static final String PHONE_TYPE_VIVO = "vivo";
    public static final String PHONE_TYPE_SAMSUNG = "samsung";

    private Map<String, String> markets;

    public MarketUtil() {
        markets = new HashMap<>();
        markets.put("yingyongbao", "com.tencent.android.qqdownloader");
        markets.put("qh360", "com.qihoo.appstore");
        markets.put("baidu", "com.baidu.appsearch");
        markets.put(PHONE_TYPE_XIAOMI, "com.xiaomi.market");
        markets.put(PHONE_TYPE_HUAWEI, "com.huawei.appmarket");
        markets.put(PHONE_TYPE_HONOR, "com.huawei.appmarket");
        markets.put(PHONE_TYPE_OPPO, "com.oppo.market");
        markets.put(PHONE_TYPE_MEIZU, "com.meizu.mstore");
        markets.put(PHONE_TYPE_VIVO, "com.bbk.appstore");
        markets.put(PHONE_TYPE_SAMSUNG, "com.sec.android.app.samsungapps");
        markets.put("alibaba", "com.wandoujia.phoenix2"); //豌豆荚
        markets.put("sogou", "com.sogou.androidtool");
        markets.put("lenovo", "com.lenovo.leos.appstore");
    }

    public String getMarketPackage(String flavor) {
        if (TextUtils.isEmpty(flavor)) {
            return null;
        }
        return markets.get(flavor);
    }

    public void launchMarket(Context context, String appPkg, String marketPkg) {
        try {
            if (TextUtils.isEmpty(appPkg) || !AppUtils.checkAppInstalled(context, marketPkg)) {
                return;
            }
            Uri uri = Uri.parse("market://details?id=" + appPkg);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            if (!TextUtils.isEmpty(marketPkg)) {
                intent.setPackage(marketPkg);
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (intent.resolveActivity(context.getPackageManager()) != null) {
                context.startActivity(intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
