package com.ozmobi.coupons.base.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by xhkj on 2019/3/28.
 */

public class TimeUtil {
    public static long getCurTimeLong() {
        return System.currentTimeMillis();
    }

    public static String stampToDate(long timeMillis) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date date = new Date(timeMillis);
        return simpleDateFormat.format(date);
    }

    public static String getCurrentHour() {
//      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");// HH:mm:ss
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH", Locale.getDefault());
        //获取当前时间
        Date date = new Date(getCurTimeLong());
        return simpleDateFormat.format(date);
    }

    public static String getCurrentTimeMinutes() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        //获取当前时间
        Date date = new Date(getCurTimeLong());
        return simpleDateFormat.format(date);
    }

    public static String getFustureDate(int index) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH) + index);
        Date today = calendar.getTime();
        SimpleDateFormat format = new SimpleDateFormat("MM.dd", Locale.getDefault());
        return format.format(today);
    }

    public static ArrayList<String> getFustureDateList(int daysNum) {
        ArrayList<String> futureDaysList = new ArrayList<>();
        for (int i = 0; i < daysNum; i++) {
            futureDaysList.add(getFustureDate(i));
        }
        return futureDaysList;
    }
}
